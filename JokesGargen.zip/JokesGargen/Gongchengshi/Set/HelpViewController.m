//
//  HelpViewController.m
//  Gongchengshi
//
//  Created by lanouhn on 14-11-7.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "HelpViewController.h"

@interface HelpViewController ()

@end

@implementation HelpViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    // Do any additional setup after loading the view.
    UILabel *shareLabel = [[[UILabel alloc] initWithFrame:CGRectMake(5, 5, 310, 30)] autorelease];
    shareLabel.backgroundColor = [UIColor lightGrayColor];
    shareLabel.text = @"  如何分享内容到微博、qzone、微信？";
    
    shareLabel.adjustsFontSizeToFitWidth = YES;
    [self.view addSubview:shareLabel];
    UILabel *shareText = [[[UILabel alloc] initWithFrame:CGRectMake(5, 35, 310, 90)] autorelease];
    shareText.text = @"登陆后，点击段子左下角的转发按钮，选择你绑定过的平台，也可以在设置中开启“收藏时转发”。";
    shareText.numberOfLines = 0;
    shareText.font = [UIFont systemFontOfSize:18];
    [self.view addSubview:shareText];
    
    
    
    UILabel *marenLabel = [[[UILabel alloc] initWithFrame:CGRectMake(5, 125, 310, 30)]autorelease];
    marenLabel.backgroundColor = [UIColor lightGrayColor];
    marenLabel.text = @"  关于骂人或者违规";
    
    marenLabel.adjustsFontSizeToFitWidth = YES;
    [self.view addSubview:marenLabel];
    UILabel *marenText = [[[UILabel alloc] initWithFrame:CGRectMake(5, 155, 310, 90)] autorelease];
    marenText.text = @"1.禁止发骂人的或包含政治、广告的内容    2.如果帖子或评论被多次举报，发布者可能会封账号处理";
    marenText.numberOfLines = 0;
//    shareText.font = [UIFont systemFontOfSize:18];
    [self.view addSubview:marenText];
    
    UILabel *tieziLabel = [[[UILabel alloc] initWithFrame:CGRectMake(5, 245, 310, 30)] autorelease];
    tieziLabel.backgroundColor = [UIColor lightGrayColor];
    tieziLabel.text = @"  关于帖子";
    
    tieziLabel.adjustsFontSizeToFitWidth = YES;
    [self.view addSubview:tieziLabel];
    UILabel *tieziText = [[[UILabel alloc] initWithFrame:CGRectMake(5, 275, 310, 60)] autorelease];
    tieziText.text = @"1.精华列表是广大盆友挑选出的最搞笑帖子";
    tieziText.numberOfLines = 0;
    //    shareText.font = [UIFont systemFontOfSize:18];
    [self.view addSubview:tieziText];
    
    UILabel *tieziText1 = [[[UILabel alloc] initWithFrame:CGRectMake(5, 325, 310, 30)] autorelease];
    tieziText1.text = @"2.最新列表下是新鲜出炉,抢沙发";
    tieziText1.numberOfLines = 0;
    //    shareText.font = [UIFont systemFontOfSize:18];
    [self.view addSubview:tieziText1];
    UILabel *tieziText2 = [[[UILabel alloc] initWithFrame:CGRectMake(5, 350, 310, 30)] autorelease];
    tieziText2.text = @"3.穿越列表,看看以前的段子也是不错的享受";
    tieziText2.numberOfLines = 0;
    //    shareText.font = [UIFont systemFontOfSize:18];
    [self.view addSubview:tieziText2];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
