//
//  SetTableViewController.m
//  Gongchengshi
//
//  Created by lanouhn on 14-11-6.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "SetTableViewController.h"
#import "UMSocial.h"
#import "BaseVideoTableViewCell.h"
#import "HelpViewController.h"
@interface SetTableViewController ()<UITableViewDataSource,UITableViewDelegate>

@property(nonatomic, retain)NSMutableArray *array; // 数据源数组
@property(nonatomic, retain)UITableView *tabelView;
@end

@implementation SetTableViewController

- (NSMutableArray *)array{

    if (!_array) {
        self.array = [NSMutableArray array];
    }
    return _array;
}
- (UITableView *)tableView{

    if (!_tabelView) {
        self.tableView = [[[UITableView alloc] initWithFrame:self.view.frame style:UITableViewStylePlain] autorelease];
        _tabelView.delegate = self;
        _tabelView.dataSource = self;
    }
    return _tabelView;
}
- (void)dealloc{

    [_tabelView release];
    [_array release];
    [super dealloc];
}
- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.title = @"设置";
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    self.tableView.separatorColor = [UIColor lightGrayColor];
    [self.array addObject:@"清除缓存"];
    [self.array addObject:@"推荐给朋友"];
    [self.array addObject:@"帮助"];
    [self.array addObject:@"当前版本"];
    [self.array addObject:@"关于我们"];
    [self.view addSubview:self.tableView];

    self.tableView.tableFooterView = [[[UIView alloc]init] autorelease];

}
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    return YES;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    // Return the number of sections.
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section

{
    if (section == 0) {
        return self.array.count;

    }
    return 1;

    // Return the number of rows in the section.
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath

{
    static NSString *cellIdentifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableHeaderFooterViewWithIdentifier:cellIdentifier];
    static NSString *cellIdentifier1 = @"cell1";
    BaseVideoTableViewCell *cell1 = [tableView dequeueReusableHeaderFooterViewWithIdentifier:cellIdentifier1];
    if (indexPath.section == 0) {
        if (!cell) {
            cell = [[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier]autorelease];
            
        }
        // 数组的count根表示图的行数一致，所以数组的下表根indextPath.row相同，可以通过indexPath.row获取到对应的要显示的数据
        cell.textLabel.text = self.array[indexPath.row];
    }else{
        cell1 = [[[BaseVideoTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier1]autorelease];
        cell1.userInteractionEnabled = NO;
        
        return cell1;
    }
    
    
    
    return cell;
    

}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        return 50;
    }
    return 260;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    if (indexPath.row == 0) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"已清除所有缓存" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alert show];
        [alert release];
    }else if (indexPath.row == 1){
    
        [UMSocialSnsService presentSnsIconSheetView:self
                                             appKey:@"507fcab25270157b37000010"
                                          shareText:@"你要分享的文字"
                                         shareImage:[UIImage imageNamed:@"icon.png"]
                                    shareToSnsNames:[NSArray arrayWithObjects:UMShareToSina,UMShareToTencent,UMShareToQQ,UMShareToQzone,UMShareToRenren,nil]
                                           delegate:nil];
    }else if (indexPath.row == 2){
    
        HelpViewController *help = [[[HelpViewController alloc] init] autorelease];
        [self.navigationController pushViewController:help animated:YES];
       
    }else if (indexPath.row == 3){
    
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"当前已是最新版本：3.0" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alert show];
        [alert release];
    }else{
    
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"关于我们" message:@"公司名字：蓝欧科技                           联系电话：18039677639                 联系电话：1182548575@qq.com                       联系地址 ：河南省郑州市高新区莲花街一号4号楼B座4楼" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alert show];
        [alert release];
    }
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
