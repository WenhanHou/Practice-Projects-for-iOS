//
//  MyMainPageTableViewController.m
//  Gongchengshi
//
//  Created by dqb on 14-11-3.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "MyMainPageTableViewController.h"
#import "myMainPageTableViewCell.h"
#import "UIImageView+WebCache.h"

@interface MyMainPageTableViewController ()
@property (nonatomic, retain) UIImageView *accessView;

@end

@implementation MyMainPageTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (UIImageView *)accessView{
    if (!_accessView) {
        self.accessView = [[[UIImageView alloc] initWithFrame:CGRectMake(300, 0, 20, 20)] autorelease];
        [_accessView setIsAccessibilityElement:YES];
        _accessView.image = [UIImage imageNamed:@"aliAvatar"];
    }
    return _accessView;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
//     self.navigationItem.rightBarButtonItem = self.editButtonItem;
    UIButton * sunButton = [UIButton buttonWithType:UIButtonTypeCustom];
    sunButton.bounds = CGRectMake(0, 0, 40.0, 40.0);
    [sunButton setImage:[UIImage imageNamed:@"sun.png"]
               forState:UIControlStateNormal];
    [sunButton addTarget:self
                  action:@selector(handlenightButtonAction:)
        forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *fooBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:sunButton];
    self.navigationItem.rightBarButtonItem = fooBarButtonItem;
    [fooBarButtonItem release];
    [self.tableView registerClass:[myMainPageTableViewCell class] forCellReuseIdentifier:@"myPage"];
    
    
    
}

- (void)handlenightButtonAction:(UIBarButtonItem *)nightButton{
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    switch (indexPath.section) {
        case 0:
            return 70;
            break;
            case 1:
            return 180;
            break;
            
        default:
            break;
    }
    return 200;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    myMainPageTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"myPage" forIndexPath:indexPath];
//    cell.backgroundColor = [UIColor lightGrayColor];
    // Configure the cell...
    switch (indexPath.section) {
        case 0:
             [cell.MyAvatar setImage:[UIImage imageNamed:@"head.png"]];
            cell.loginorRegister.text = @"登录/注册";
            cell.accessoryView = self.accessView;

            break;
            case 1:
            cell.spaceViewy = [[[UIView alloc] initWithFrame:CGRectMake(160, 0, 2, 180)] autorelease];
            cell.spaceViewy.backgroundColor = [UIColor lightGrayColor];
            cell.spaceViewy.alpha = 0.2;
            [cell.contentView addSubview:cell.spaceViewy];
            cell.selfPhoto = [UIButton buttonWithType:UIButtonTypeCustom];
            cell.selfPhoto.frame = CGRectMake(0, 10, 159, 40);
            [cell.selfPhoto setTitle:@"#自拍#" forState:UIControlStateNormal];
            [cell.selfPhoto setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            cell.selfPhoto.showsTouchWhenHighlighted = YES;
            [cell.selfPhoto addTarget:self action:@selector(handleSelfPhotoAction:) forControlEvents:UIControlEventTouchUpInside];
            [cell.contentView addSubview:cell.selfPhoto];
            
            cell.spaceViewx = [[[UIView alloc] initWithFrame:CGRectMake(0, 60, 320, 2)] autorelease];
            cell.spaceViewx.backgroundColor = [UIColor lightGrayColor];
            cell.spaceViewx.alpha = 0.2;
            [cell.contentView addSubview:cell.spaceViewx];
            cell.gifButton = [UIButton buttonWithType:UIButtonTypeCustom];
            cell.gifButton.frame = CGRectMake(161, 10, 159, 40);
            [cell.gifButton setTitle:@"#动态图#" forState:UIControlStateNormal];
            [cell.gifButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            cell.gifButton.showsTouchWhenHighlighted = YES;
            [cell.gifButton addTarget:self action:@selector(handlegifButtonAction:) forControlEvents:UIControlEventTouchUpInside];
            [cell.contentView addSubview:cell.gifButton];
            cell.spaceViewx = [[[UIView alloc] initWithFrame:CGRectMake(0, 120, 320, 2)] autorelease];
            cell.spaceViewx.backgroundColor = [UIColor lightGrayColor];
            cell.spaceViewx.alpha = 0.2;
            [cell.contentView addSubview:cell.spaceViewx];
            
            cell.suggestButton = [UIButton buttonWithType:UIButtonTypeCustom];
            cell.suggestButton.frame = CGRectMake(0, 70, 159, 40);
            [cell.suggestButton setTitle:@"#集思广益#" forState:UIControlStateNormal];
            [cell.suggestButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            cell.suggestButton.showsTouchWhenHighlighted = YES;
            [cell.suggestButton addTarget:self action:@selector(handleSelfPhotoAction:) forControlEvents:UIControlEventTouchUpInside];
            [cell.contentView addSubview:cell.suggestButton];
            
            cell.meaningButton = [UIButton buttonWithType:UIButtonTypeCustom];
            cell.meaningButton.frame = CGRectMake(0, 140, 159, 40);
            [cell.meaningButton setTitle:@"#你懂得#" forState:UIControlStateNormal];
            [cell.meaningButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            cell.meaningButton.showsTouchWhenHighlighted = YES;
            [cell.meaningButton addTarget:self action:@selector(handleSelfPhotoAction:) forControlEvents:UIControlEventTouchUpInside];
            [cell.contentView addSubview:cell.meaningButton];
            
            cell.singButton = [UIButton buttonWithType:UIButtonTypeCustom];
            cell.singButton.frame = CGRectMake(161, 70, 159, 40);
            [cell.singButton setTitle:@"#一展歌喉#" forState:UIControlStateNormal];
            [cell.singButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            cell.singButton.showsTouchWhenHighlighted = YES;
            [cell.singButton addTarget:self action:@selector(handleSingButtonAction:) forControlEvents:UIControlEventTouchUpInside];
            [cell.contentView addSubview:cell.singButton];
            
            break;
            case 2:
            cell.checkname.text = @"审帖";
            cell.checkButton.showsTouchWhenHighlighted = YES;
            
            break;
        default:
            break;
    }
   
    
    
    return cell;
}

- (void)handleSelfPhotoAction:(UIButton *)selfPhoto{
    NSLog(@"photo");
}

- (void)handlegifButtonAction:(UIButton *)gifButton{
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 15;
}



- (BOOL)tableView:(UITableView *)tableView shouldHighlightRowAtIndexPath:(NSIndexPath *)indexPath{
    return YES;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        
    }
    
    
}




/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
