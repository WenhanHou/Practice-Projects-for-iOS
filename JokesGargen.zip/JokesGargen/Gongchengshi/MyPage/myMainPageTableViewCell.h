//
//  myMainPageTableViewCell.h
//  Gongchengshi
//
//  Created by dqb on 14-11-3.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface myMainPageTableViewCell : UITableViewCell
@property(nonatomic, retain) UIImageView *MyAvatar;
@property(nonatomic, retain) UILabel *loginorRegister;
@property(nonatomic, retain) UILabel *Mythemename;
@property(nonatomic, retain) UIView *spaceViewx;
@property(nonatomic, retain) UIView *spaceViewy;
@property(nonatomic, retain) UIImageView *checkImageView;
@property(nonatomic, retain) UILabel *checkname;
@property(nonatomic, retain) UIButton *selfPhoto;
@property(nonatomic, retain) UIButton *gifButton;
@property(nonatomic, retain) UIButton *suggestButton;
@property(nonatomic, retain) UIButton *meaningButton;
@property(nonatomic, retain) UIButton *singButton;
@property(nonatomic, retain) UIButton *checkButton;
@end
