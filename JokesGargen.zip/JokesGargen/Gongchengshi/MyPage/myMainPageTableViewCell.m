//
//  myMainPageTableViewCell.m
//  Gongchengshi
//
//  Created by dqb on 14-11-3.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "myMainPageTableViewCell.h"

@implementation myMainPageTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (UIImageView *)MyAvatar{
    if (!_MyAvatar) {
        self.MyAvatar = [[[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 50, 50)] autorelease];
        _MyAvatar.backgroundColor = [UIColor redColor];
        [self.contentView addSubview:_MyAvatar];
    }
    return _MyAvatar;
}

- (UILabel *)loginorRegister{
    if (!_loginorRegister) {
        self.loginorRegister = [[[UILabel alloc] initWithFrame:CGRectMake(70, 20, 200, 30)] autorelease];
        _loginorRegister.textAlignment = NSTextAlignmentLeft;
        _loginorRegister.font = [UIFont boldSystemFontOfSize:20];
        _loginorRegister.textColor = [UIColor greenColor];
        [self.contentView addSubview:_loginorRegister];
    }
    return _loginorRegister;
}


- (UILabel *)Mythemename{
    if (!_Mythemename) {
        self.Mythemename = [[[UILabel alloc] initWithFrame:CGRectMake(0, 10, 40, 320)] autorelease];
        _Mythemename.backgroundColor = [UIColor whiteColor];
        _Mythemename.textAlignment = NSTextAlignmentCenter;
        _Mythemename.font = [UIFont systemFontOfSize:15];
        [self.contentView addSubview:_Mythemename];
        
    }
    return _Mythemename;
}

- (UIButton *)checkButton{
    if (!_checkButton) {
        self.checkButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _checkButton.frame = CGRectMake(20, 10, 50, 50);
        [_checkButton setImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
        
        [self.contentView addSubview:_checkButton];
        
    }
    return _checkButton;
}


- (UILabel *)checkname{
    if (!_checkname) {
        self.checkname = [[[UILabel alloc] initWithFrame:CGRectMake(20, 65, 40, 20)] autorelease];
        _checkname.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_checkname];
    }
    return _checkname;
}
- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
