//
//  Micro.h
//  Gongchengshi
//
//  Created by dqb on 14-10-27.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#define  UIColor(r,g,b) [UIColor colorWithRed: r / 255.0 green: b / 255.0 blue: g / 255.0 alpha:1]

#define kVideoBestUrl @"http://api.budejie.com/api/api_open.php?a=list&appname=baisibudejie&c=video&jbk=0&page=0&per=20&type=41&udid=&ver=3.0"
#define kVideoCreamURL @"http://api.budejie.com/api/api_open.php?a=newlist&appname=baisibudejie&asid=8FE33EB2-39D7-4572-8D44-8F7DC91FFB0C&c=video&jbk=0&openudid=8d759955a0af863ed9510d782ff53bb62cd0a126&page=0&per=20&type=41&udid=&ver=3.0"
#define kVideoThough @"http://api.budejie.com/api/api_open.php?a=list&appname=baisibudejie&asid=8FE33EB2-39D7-4572-8D44-8F7DC91FFB0C&c=video&jbk=0&openudid=8d759955a0af863ed9510d782ff53bb62cd0a126&order=timewarp&page=0&per=20&type=41&udid=&ver=3.0"