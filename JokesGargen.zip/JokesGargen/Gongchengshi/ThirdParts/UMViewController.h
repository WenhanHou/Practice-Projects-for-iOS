//
//  UMViewController.h
//  BigDragon
//
//  Created by 田傲 on 14-11-5.
//  Copyright (c) 2014年 www.lanou3g.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UMSocial.h"
@interface UMViewController : UIViewController<UMSocialUIDelegate>

@end
