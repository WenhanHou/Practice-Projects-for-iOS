//
//  YScrollViewController.h
//  ScrollerView
//
//  Created by yao on 14-10-27.
//  Copyright (c) 2014年 BigDrion. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YScrollViewController : UIViewController
@property (nonatomic, assign)NSInteger selectedTag;
@property (nonatomic, retain)UIScrollView *scroll;
@property (nonatomic, retain)NSMutableArray *viewArray;
@end
