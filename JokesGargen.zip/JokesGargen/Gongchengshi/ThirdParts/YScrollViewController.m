//
//  YScrollViewController.m
//  ScrollerView
//
//  Created by yao on 14-10-27.
//  Copyright (c) 2014年 BigDrion. All rights reserved.
//

#import "YScrollViewController.h"
#import "PictureBestTableViewController.h"
#import "CHTumblrMenuView.h"
#import "GifPictureTableViewController.h"
#import "SelfPhotoTableViewController.h"
#import "LogInViewController.h"
#import "SetTableViewController.h"


@interface YScrollViewController ()<UIScrollViewDelegate>

@end

@implementation YScrollViewController


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
    }
    return self;
}
- (void)dealloc{
    [_scroll release];
    [super dealloc];
}
- (NSMutableArray *)viewArray{
    if (!_viewArray) {
        self.viewArray = [NSMutableArray array];
    }
    return _viewArray;
}
- (UIScrollView *)scroll{
    if (!_scroll) {
        CGRect frame = self.view.bounds;
//        frame.origin.y += 64;
//        frame.size.height -= 64;
        self.scroll = [[[UIScrollView alloc] initWithFrame:frame]autorelease];
        self.scroll.delegate = self;
    
        
        self.scroll.contentSize = CGSizeMake(self.scroll.bounds.size.width * 3, self.scroll.bounds.size.height - 64);
        self.scroll.directionalLockEnabled = YES;
        self.scroll.bounces = NO;
        self.scroll.alwaysBounceHorizontal = YES;
        self.scroll.showsHorizontalScrollIndicator = NO;
        self.scroll.showsVerticalScrollIndicator = NO;
        
        self.scroll.pagingEnabled = YES;
    }
    return _scroll;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
  
    self.selectedTag = 100;
   
    [self.viewArray makeObjectsPerformSelector:@selector(setScrollViewController:) withObject:self];
    for (int i = 0; i < self.viewArray.count; i++) {
        CGRect frame = CGRectMake(self.scroll.bounds.size.width * i, 0, self.scroll.bounds.size.width, self.scroll.bounds.size.height - 64);
        UITableViewController *essenceTable = (UITableViewController *)self.viewArray[i];
        essenceTable.tableView.frame = frame;
        [self.scroll addSubview:essenceTable.tableView];
        
    }
    

   
    
    [self.view addSubview:self.scroll];
    UIView * view = [[[UIView alloc] initWithFrame:CGRectMake(0, 7, 180, 30)] autorelease];
    NSArray *buttonNameArray = @[@"精华", @"最新", @"穿越"];
    for (int i = 0; i < buttonNameArray.count; i++) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        button.frame = CGRectMake(60 * i, 0, 60, 30);
        [button setTag:i + 100];
        if (i == 0) {
            button.selected = YES;
        }
        [button setTitle:[NSString stringWithFormat:@"%@", buttonNameArray[i]] forState:UIControlStateNormal];
        button.titleLabel.font = [UIFont systemFontOfSize:18];
        [button setTitleColor:[UIColor blueColor] forState:UIControlStateSelected];
        [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(handleButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        [view addSubview:button];
    }
    self.navigationItem.titleView = view;
    UIBarButtonItem *rightBtn = [[UIBarButtonItem alloc]
                                 
                                 initWithTitle:@"我"
                                 
                                 style:UIBarButtonItemStyleBordered
                                 
                                 target:self
                                 
                                 action:@selector(showMenu)];
    
    
    self.navigationItem.rightBarButtonItem = rightBtn;
   [rightBtn setTintColor:[UIColor blueColor]];
    [rightBtn release];

    
}

- (void)showMenu
{
    CHTumblrMenuView *menuView = [[CHTumblrMenuView alloc] init];
    [menuView addMenuItemWithTitle:@"登录" andIcon:[UIImage imageNamed:@"post_type_bubble_text.png"] andSelectedBlock:^{
        LogInViewController *loginVC = [[[LogInViewController alloc] init] autorelease];
        loginVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:loginVC animated:YES];
                 }];
    [menuView addMenuItemWithTitle:@"自拍" andIcon:[UIImage imageNamed:@"post_type_bubble_photo.png"] andSelectedBlock:^{
        NSLog(@"Photo selected");
    
        SelfPhotoTableViewController *selfPhotoVC = [[[SelfPhotoTableViewController alloc]init] autorelease];
        selfPhotoVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:selfPhotoVC animated:NO];
    }];
    [menuView addMenuItemWithTitle:@"动态图" andIcon:[UIImage imageNamed:@"post_type_bubble_quote.png"] andSelectedBlock:^{
        GifPictureTableViewController *GifPicVC = [[[GifPictureTableViewController alloc] init] autorelease];
        GifPicVC.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:GifPicVC animated:YES];

        
    }];
    [menuView addMenuItemWithTitle:@"设置" andIcon:[UIImage imageNamed:@"post_type_bubble_link.png"] andSelectedBlock:^{
        SetTableViewController *setVC = [[[SetTableViewController alloc] init] autorelease];
        [self.navigationController pushViewController:setVC animated:YES];
        
    }];
//    [menuView addMenuItemWithTitle:@"Chat" andIcon:[UIImage imageNamed:@"post_type_bubble_chat.png"] andSelectedBlock:^{
//        NSLog(@"Chat selected");
//        
//    }];
//    [menuView addMenuItemWithTitle:@"Video" andIcon:[UIImage imageNamed:@"post_type_bubble_video.png"] andSelectedBlock:^{
//        NSLog(@"Video selected");
//        
//    }];
    
    
    
    [menuView show];
}




- (void)handleButtonAction:(UIButton *)sender{
    if (sender.tag != self.selectedTag) {
        UIButton *lastButton = (UIButton *)[self.navigationController.navigationBar viewWithTag:self.selectedTag];
        lastButton.selected = NO;
        
        self.selectedTag = sender.tag;
         NSLog(@"%ld", self.selectedTag);
        sender.selected = YES;
        
        self.scroll.contentOffset = CGPointMake(self.scroll.bounds.size.width * (self.selectedTag - 100), 0);
       
    }
    
    
    
    
   
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
  
    CGPoint offset = self.scroll.contentOffset;
    int currentoff = offset.x / self.scroll.bounds.size.width;
   
            
            UIButton *button = (UIButton *)[self.navigationController.navigationBar viewWithTag:self.selectedTag];
            button.selected = NO;
       
            self.selectedTag = 100 + currentoff;
            UIButton *currentButton = (UIButton *)[self.navigationController.navigationBar viewWithTag:self.selectedTag];
            currentButton.selected = YES;
     
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
