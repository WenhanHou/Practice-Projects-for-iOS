//
//  MainViewController.m
//  Gongchengshi
//
//  Created by dqb on 14-10-28.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "MainViewController.h"
#import "PictureBestTableViewController.h"
#import "VideoBestTableViewController.h"
#import "TextBestTableViewController.h"
#import "VoiceBestTableViewController.h"

#import "PictureCurrentTableViewController.h"
#import "VideoCreamTableViewController.h"
#import "TextCreamTableViewController.h"
#import "VoiceCreamTableViewController.h"

#import "PictureThoughTableViewController.h"
#import "VoiceThoughTableViewController.h"
#import "VideoThroughTableViewController.h"
#import "TextThoughTableViewController.h"

#import "YScrollViewController.h"
#import "Micro.h"


@interface MainViewController ()


- (UINavigationController *)navigationControllerWithRootView:(UITableViewController *)rootView;

@end

@implementation MainViewController

- (UINavigationController *)navigationControllerWithRootView:(UITableViewController *)rootView{
    
    UINavigationController *nav = [[[UINavigationController alloc] initWithRootViewController:rootView] autorelease];
    return nav;
    
    
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
//    self.tabBar.barTintColor = UIColor(100, 100, 10);
    self.tabBar.barTintColor = [UIColor whiteColor];
    // Do any additional setup after loading the view.
    
    YScrollViewController *first = [[[YScrollViewController alloc] init] autorelease];
    YScrollViewController *second = [[[YScrollViewController alloc] init] autorelease];

    YScrollViewController *third = [[[YScrollViewController alloc] init] autorelease];

    YScrollViewController *fourth = [[[YScrollViewController alloc] init] autorelease];

    
    
    
    
    PictureBestTableViewController *pictureVC = [[PictureBestTableViewController alloc] initWithStyle:UITableViewStylePlain];
    PictureCurrentTableViewController *pictureCurrent = [[[PictureCurrentTableViewController alloc] initWithStyle:UITableViewStylePlain] autorelease];
    PictureThoughTableViewController *pictureThough = [[[PictureThoughTableViewController alloc] initWithStyle:UITableViewStylePlain] autorelease];
    
    TextBestTableViewController *textVC = [[TextBestTableViewController alloc] initWithStyle:UITableViewStylePlain];
    TextCreamTableViewController *textCream = [[[TextCreamTableViewController alloc] initWithStyle:UITableViewStylePlain] autorelease];
    TextThoughTableViewController *textThough = [[[TextThoughTableViewController alloc] initWithStyle:UITableViewStylePlain] autorelease];
    
    VoiceBestTableViewController *voiceVC = [[VoiceBestTableViewController alloc] initWithStyle:UITableViewStylePlain];//声音最新
    VoiceCreamTableViewController *voiceCream = [[[VoiceCreamTableViewController alloc] initWithStyle:UITableViewStylePlain] autorelease];//声音精华
    VoiceThoughTableViewController *voiceThough = [[[VoiceThoughTableViewController alloc] initWithStyle:UITableViewStylePlain] autorelease];//声音穿越
    
    VideoBestTableViewController *videoVC = [[VideoBestTableViewController alloc] initWithStyle:UITableViewStylePlain];
    VideoCreamTableViewController *videoCream = [[[VideoCreamTableViewController alloc] initWithStyle:UITableViewStylePlain] autorelease];
    VideoThroughTableViewController *videoThough = [[[VideoThroughTableViewController alloc] initWithStyle:UITableViewStylePlain] autorelease]
    ;
    
    
    UINavigationController *navi1 = [[UINavigationController alloc] initWithRootViewController:first];
    UINavigationController *navi2 = [[UINavigationController alloc] initWithRootViewController:second];
    UINavigationController *navi3 = [[UINavigationController alloc] initWithRootViewController:third];
    UINavigationController *navi4 = [[UINavigationController alloc] initWithRootViewController:fourth];
    
    navi1.navigationBar.translucent = NO;
    navi2.navigationBar.translucent = NO;
    navi3.navigationBar.translucent = NO;
    navi4.navigationBar.translucent = NO;

    
    first.tabBarItem = [[[UITabBarItem alloc] initWithTitle:@"图" image:[UIImage imageNamed:@"tabbarQuotation.png"] selectedImage:[UIImage imageNamed:@"tabbarQuotationClick.png"]] autorelease];
    [first.viewArray addObject:pictureVC];
    [first.viewArray addObject:pictureCurrent];
    [first.viewArray addObject:pictureThough];
    
    
    second.tabBarItem = [[[UITabBarItem alloc] initWithTitle:@"文" image:[UIImage imageNamed:@"tabbarEssay-dark.png"] selectedImage:[UIImage imageNamed:@"tabbarEssayClick.png"]] autorelease];
    [second.viewArray addObject:textCream];
    [second.viewArray addObject:textVC];
    [second.viewArray addObject:textThough];
    
    
    third.tabBarItem = [[[UITabBarItem alloc] initWithTitle:@"影" image:[UIImage imageNamed:@"tabbarVideo-dark.png"] selectedImage:[UIImage imageNamed:@"tabbarVideoClick.png"]] autorelease];
    [third.viewArray addObject:videoVC];
    [third.viewArray addObject:videoCream];
    [third.viewArray addObject:videoThough];
    
    
    fourth.tabBarItem = [[[UITabBarItem alloc] initWithTitle:@"音" image:[UIImage imageNamed:@"tabbarVoice-dark.png"] selectedImage:[UIImage imageNamed:@"tabbarVoiceClick.png"]] autorelease];
    [fourth.viewArray addObject:voiceVC];
    [fourth.viewArray addObject:voiceCream];
    [fourth.viewArray addObject:voiceThough];
    
    
    navi1.tabBarItem.imageInsets = UIEdgeInsetsMake(2, 0, -2, 0);
    navi2.tabBarItem.imageInsets = UIEdgeInsetsMake(2, 0, -2, 0);
    navi3.tabBarItem.imageInsets = UIEdgeInsetsMake(2, 0, -2, 0);
    navi4.tabBarItem.imageInsets = UIEdgeInsetsMake(2, 0, -2, 0);
    self.viewControllers = [NSArray arrayWithObjects:navi1, navi2, navi3, navi4, nil];
   
   
    [pictureVC release];
    [videoVC release];
    [voiceVC release];
    [textVC release];
    
    [navi1 release];
    [navi2 release];
    [navi3 release];
    [navi4 release];
    
    
    
   
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
