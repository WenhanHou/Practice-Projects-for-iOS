//
//  CommentTableViewCell.h
//  Gongchengshi
//
//  Created by lanouhn on 14-10-31.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CommentTableViewCell : UITableViewCell

@property(nonatomic, retain)UIImageView *profile_image; // 用户头像
@property(nonatomic, retain)UILabel *userName; // 用户
@property(nonatomic, retain)UILabel *text; // 文本
@property(nonatomic, retain)UIButton *favorite;// 赞
@property(nonatomic, retain)UILabel *favoriteLabel;
@property(nonatomic, retain)UIImageView *favorityImage;

@end
