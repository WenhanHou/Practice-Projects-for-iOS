//
//  PictureDetailTableViewCell.m
//  Gongchengshi
//
//  Created by lanouhn on 14-10-29.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "PictureDetailTableViewCell.h"
#import "UIImageView+WebCache.h"

@implementation PictureDetailTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}



- (UIImageView *)UserAvatar{
    if (!_UserAvatar) {
        self.UserAvatar = [[[UIImageView alloc] initWithFrame:CGRectMake(10, 5, 50, 50)] autorelease];
        _UserAvatar.backgroundColor = [UIColor redColor];
        [self.contentView addSubview:_UserAvatar];
    }
    return _UserAvatar;
}

- (UILabel *)deNameLabel{
    if (!_deNameLabel) {
        self.deNameLabel = [[[UILabel alloc] initWithFrame:CGRectMake(70, 5, 100, 30)] autorelease];
        _deNameLabel.textAlignment = NSTextAlignmentLeft;
        _deNameLabel.adjustsFontSizeToFitWidth = YES;
        [self.contentView addSubview:_deNameLabel];
    }
    return _deNameLabel;
}

- (UILabel *)deTimeLabel{
    if (!_deTimeLabel) {
        self.deTimeLabel = [[[UILabel alloc] initWithFrame:CGRectMake(70, 40, 100, 20)] autorelease];
        _deTimeLabel.textAlignment = NSTextAlignmentLeft;
        _deTimeLabel.adjustsFontSizeToFitWidth = YES;
        [self.contentView addSubview:_deTimeLabel];
    }
    return _deTimeLabel;
}

- (UILabel *)commentContentLabel{
    if (!_commentContentLabel) {
        self.commentContentLabel = [[[UILabel alloc] initWithFrame:CGRectMake(10, 70, 300, 50)] autorelease];
        _commentContentLabel.textAlignment = NSTextAlignmentLeft;
        _commentContentLabel.adjustsFontSizeToFitWidth = YES;
        [self.contentView addSubview:_commentContentLabel];
    }
    return _commentContentLabel;
}

- (UIImageView *)videoImage{
    if (!_videoImage) {
        self.videoImage = [[[UIImageView alloc] initWithFrame:CGRectMake(10, 150, 300, 200)] autorelease];
        _videoImage.backgroundColor = [UIColor blackColor];
        [self.contentView addSubview:_videoImage];
    }
    return _videoImage;
}

//- (void)setContentForCellWithItemModel:(VideoModel *)itemModel{
//    
//    self.nameLabel.text = itemModel.name;
//    NSLog(@"%@", itemModel.name);
//    [self.userAvatar sd_setImageWithURL:[NSURL URLWithString:itemModel.profile_image] placeholderImage:[UIImage imageNamed:@"ding_back.png"]];
//    self.timeLabel.text = itemModel.created_at;
//    [self.userAvatar sd_setImageWithURL:[NSURL URLWithString:itemModel.profile_image] placeholderImage:[UIImage imageNamed:@"aliAvatar"]];
//    self.nameLabel.text = itemModel.name;
//    self.timeLabel.text = itemModel.created_at;
//    self.Label.text = itemModel.text;
//    [self.image0 sd_setImageWithURL:[NSURL URLWithString:itemModel.image1]];
//    [self.loveButton setImage:[UIImage imageNamed:@"ding_red.png"] forState:UIControlStateNormal];
//    self.loveLabel.text = itemModel.love;
//    [self.hateButton setImage:[UIImage imageNamed:@"cai_red.png"] forState:UIControlStateNormal];
//    self.hateLabel.text = itemModel.hate;
//    [self.forwardButton setImage:[UIImage imageNamed:@"mainCellShareClick.png"] forState:UIControlStateNormal];
//    self.forwardLabel.text = itemModel.forward;
//    [self.commentButton setImage:[UIImage imageNamed:@"pinglun.png"] forState:UIControlStateNormal];
//    self.commentLabel.text = itemModel.comment;
//    self.playcountLabel.text = [NSString stringWithFormat:@"%@次播放",itemModel.playcount];
//    
//}




- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
