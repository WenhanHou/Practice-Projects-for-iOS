//
//  CommentTableViewCell.m
//  Gongchengshi
//
//  Created by lanouhn on 14-10-31.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "CommentTableViewCell.h"

@implementation CommentTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        [self addSubview:_favorite];
        
    }
    return self;
}

- (UIImageView *)profile_image{

    if (!_profile_image) {
        self.profile_image = [[[UIImageView alloc] init] autorelease];
        _profile_image.userInteractionEnabled = YES;
        _profile_image.frame = CGRectMake(5, 5, 50, 50);
        [self.contentView addSubview:_profile_image];
    }
    return _profile_image;
}
- (UILabel *)userName{

    if (!_userName) {
        self.userName = [[[UILabel alloc] initWithFrame:CGRectMake(65, 5, 200, 25)] autorelease];
        _userName.font = [UIFont systemFontOfSize:13];
        _userName.textColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_userName];
    }
    return _userName;
}

- (UILabel *)text{

    if (!_text) {
        self.text = [[[UILabel alloc] initWithFrame:CGRectMake(60, 25 , 200, 60)] autorelease];
        _text.font = [UIFont systemFontOfSize:15];
        _text.numberOfLines = 0;
        [self.contentView addSubview:_text];
    }
    return _text;
}

- (UIButton *)favorite{

    if (!_favorite) {
        self.favorite = [UIButton buttonWithType:UIButtonTypeCustom];
        self.favorite.frame = CGRectMake(270, 15, 70, 70);
       
        [self.contentView addSubview:_favorite];
        
    }
    return _favorite;
}
- (UILabel *)favoriteLabel{

    if (!_favorite) {
        self.favoriteLabel = [[[UILabel alloc] initWithFrame:CGRectMake(0, 20, 20, 20)] autorelease];
        
        [_favorite addSubview:_favoriteLabel];
    }
    return _favoriteLabel;
}

- (UIImageView *)favorityImage{

    if (!_favorityImage) {
        self.favorityImage = [[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 20, 20)] autorelease];
        
        [_favorite addSubview:_favorityImage];
    }
    return _favorityImage;
}
- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
