//
//  PictureDetailTableViewCell.h
//  Gongchengshi
//
//  Created by lanouhn on 14-10-29.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseVideoTableViewCell.h"
#import "VideoModel.h"

@interface PictureDetailTableViewCell : BaseVideoTableViewCell
@property(nonatomic, retain) UIImageView *UserAvatar;
@property(nonatomic, retain) UILabel *deNameLabel;
@property(nonatomic, retain) UILabel *deTimeLabel;
@property(nonatomic, retain) UIImageView *videoImage;
@property(nonatomic, retain) UILabel *commentContentLabel;

//- (void)setContentForCellWithItemModel:(VideoModel *)itemModel;
@end
