//
//  BaseTableViewController.h
//  Gongchengshi
//
//  Created by lanouhn on 14-10-29.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VideoModel.h"
#import "duanziModels.h"
#import "GCSBaseModel.h"
#import "personalModel.h"
@class YScrollViewController;

@interface BaseTableViewController : UITableViewController
@property(nonatomic, assign) YScrollViewController *scrollViewController;
@property(nonatomic, retain) VideoModel *videoModel;
@property(nonatomic, retain) duanziModels *DuanziModel;
@property(nonatomic, retain) GCSBaseModel *voiceModel;
@property(nonatomic, retain) personalModel *perModel;


@end
