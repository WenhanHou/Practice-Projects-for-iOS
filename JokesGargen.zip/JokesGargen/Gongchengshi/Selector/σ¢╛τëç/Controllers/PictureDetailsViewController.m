//
//  PictureDetailsViewController.m
//  BigDragon
//
//  Created by 蓝欧科技 on 14-10-30.
//  Copyright (c) 2014年 www.lanou3g.com. All rights reserved.
//

#import "PictureDetailsViewController.h"

#import "UIImageView+WebCache.h"

@interface PictureDetailsViewController ()

@end

@implementation PictureDetailsViewController


-  (MyImageView *)image {
    if (!_image) {
        self.image = [[[MyImageView alloc]init] autorelease];
        
        _image.frame = CGRectMake(5, 0, 310,[self.height floatValue] * 310 / [self.width floatValue]);
        
        _image.backgroundColor = [UIColor blueColor];
        _image.contentMode = UIViewContentModeScaleAspectFit;

        
    }
    
    return _image;
    
    
}

- (void)dealloc {
    [_image release];
    [super dealloc];
    
    
}
- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}


- (void)viewWillAppear:(BOOL)animated{
    NSString *suffixString = @".jpg";
    if ([self.Picture hasSuffix:suffixString]) {
        self.navigationController.navigationBarHidden = YES;
    }
    self.navigationItem.title = @"查看图片";
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"转发" style:UIBarButtonItemStyleBordered target:self action:@selector(handelShareAction:)];
}
- (void)handelShareAction:(UIButton *)sender{


}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    
    [self.image addTarget:self action:@selector(handleAction)];
 
   //    self.view.backgroundColor = [UIColor blackColor];

    
    
//    UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
//    [button setTitle:@"返回" forState:UIControlStateNormal];
//    button.frame =CGRectMake(30, 0, 30, 44);
    
    
//    [button addTarget:self action:@selector(backAction:) forControlEvents:UIControlEventTouchUpInside];
//    [self.navigationController.navigationBar addSubview:button];
//    self.navigationItem.hidesBackButton = YES;
//    UIButton* backButton = [UIButton buttonWithType:101];//UIButtonType，其实101和系统返回按钮一样
//    [backButton addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
//    [backButton setTitle:@"返回" forState:UIControlStateNormal];
//    UIBarButtonItem *leftBtn = [[[UIBarButtonItem alloc] initWithCustomView:backButton] autorelease];
//    self.navigationItem.leftBarButtonItem = leftBtn;
    
    
  
    
}

- (void)handleAction{
    
    [[self navigationController] popViewControllerAnimated:YES];
    self.navigationController.navigationBarHidden = NO;
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if ([self.height floatValue] * 310 / [self.width floatValue] > self.view.frame.size.height) {
        return [self.height floatValue] * 310 / [self.width floatValue];
    }
    self.image.center = self.view.center;
    return self.view.frame.size.height;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    cell.backgroundColor = [UIColor darkGrayColor];
    cell.alpha = 0.9;
    // Configure the cell...
//    cell.backgroundColor = [UIColor redColor];
    [self.image sd_setImageWithURL:[NSURL URLWithString:self.Picture]];
    
    UIRotationGestureRecognizer *xuanzhuan = [[UIRotationGestureRecognizer alloc]initWithTarget:self action:@selector(handle:)];
    UIPinchGestureRecognizer *niehe = [[UIPinchGestureRecognizer alloc]initWithTarget:self action:@selector(handle1:)];
    
    [self.image addGestureRecognizer:niehe];
    [self.image addGestureRecognizer:xuanzhuan];
   

    [cell addSubview:self.image];
    
    
    return cell;
}

//旋转
- (void)handle:(UIRotationGestureRecognizer *)sender{
    self.image.transform = CGAffineTransformRotate(self.image.transform, sender.rotation);
    sender.rotation = 0;
}
//缩放
- (void)handle1:(UIPinchGestureRecognizer *)sender{
    self.image.transform = CGAffineTransformScale(self.image.transform, sender.scale, sender.scale) ;
    sender.scale = 1;
}
/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
