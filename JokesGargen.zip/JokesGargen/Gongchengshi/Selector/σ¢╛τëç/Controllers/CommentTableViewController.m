//
//  CommentTableViewController.m
//  Gongchengshi
//
//  Created by lanouhn on 14-10-31.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "CommentTableViewController.h"

#import "QiushiRequestManager.h"
#import "jinghuaModels.h"
#import "UIImageView+WebCache.h"
#import "CommentModels.h"
#import "jinghuaTableViewCell.h"
#import "CommentTableViewCell.h"
#import "PictureDetailsViewController.h"
#import "WriteDetailViewController.h"
#import "PictureDetailTableViewController.h"
#import "MJRefresh.h"
@interface CommentTableViewController ()<QiushiRequestManagerDelegate>

@property(nonatomic, retain)NSMutableArray *dataArray;
@property(nonatomic, retain)UILabel *label;
@property(nonatomic, assign)NSInteger count;
- (void)_beginRequest;
@end

@implementation CommentTableViewController

- (NSMutableArray *)dataArray{

    if (!_dataArray) {
        self.dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
- (void)request:(QiushiRequestManager *)request didFaildWithError:(NSError *)error{

    NSLog(@"%@", error);
}

- (void)request:(QiushiRequestManager *)request didFinishLoadingWithData:(NSData *)data{

  [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];

    if (![self.itemModel.comment isEqualToString:@"0"]) {
        NSMutableDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
        NSMutableArray *array = json[@"data"];
            for (id obj in array) {
                CommentModels *model = [[[CommentModels alloc] initWithDictionary:obj] autorelease];
                [self.dataArray addObject:model];
            }
            
        [self.tableView reloadData];
    }
    
    
}
- (void)_beginRequest{
    QiushiRequestManager *manager = [[QiushiRequestManager alloc] init];
    manager.delegate = self;
    manager.destinationURLString = [NSString stringWithFormat:@"http://api.budejie.com/api/api_open.php?a=dataList&c=comment&data_id=%@&hot=1&page=1&per=20", self.user_id];

    [manager startRequest];
}
- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (void)viewWillDisappear:(BOOL)animated{
    [self.label removeFromSuperview];
    
}

- (void)viewWillAppear:(BOOL)animated{
    
    self.label = [[[UILabel alloc] initWithFrame:CGRectMake(0, 0, 320, 49)] autorelease];
    self.label.backgroundColor = [UIColor cyanColor];
    //    label.backgroundColor = [UIColor whiteColor];
    self.label.userInteractionEnabled = YES;
    UIButton *commentButton = [UIButton buttonWithType:UIButtonTypeCustom];
    commentButton.frame = CGRectMake(5, 7, 220, 39);
    commentButton.backgroundColor = [UIColor whiteColor];
    [commentButton setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    [commentButton setTitle:@"写评论" forState:UIControlStateNormal];
    [commentButton addTarget:self action:@selector(handleCommentAction:) forControlEvents:UIControlEventTouchUpInside];
    UIButton *shareButton = [UIButton buttonWithType:UIButtonTypeCustom];
    shareButton.frame = CGRectMake(230, 7, 85/2, 39);
    UIImageView *shareImage = [[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 40, 39)] autorelease];
    shareImage.image = [UIImage imageNamed:@"icon_share@2x.png"];
    [shareButton addSubview:shareImage];
    
    UIButton *shoucangButton = [UIButton buttonWithType:UIButtonTypeCustom];
    shoucangButton.frame = CGRectMake(275, 7, 40, 39);
    UIImageView *shoucang = [[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 40, 39)] autorelease];
    shoucang.image = [UIImage imageNamed:@"comment-colletion-icon@2x.png"];
    [shoucangButton addSubview:shoucang];
    [self.label addSubview:shoucangButton];
    [self.label addSubview:shareButton];
    [self.label addSubview:commentButton];
    [self.tabBarController.tabBar addSubview:self.label];
}
- (void)handleCommentAction:(UIButton *)sender{
    
    WriteDetailViewController *write = [[[WriteDetailViewController alloc] init] autorelease];
    self.tabBarController.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:write animated:YES];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.title = @"评论";
//    UITextField *textFiled = [[UITextField alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height - 44, 320, 44)];
//    textFiled.backgroundColor = [UIColor purpleColor];
//    [self.view addSubview:textFiled];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    [self.tableView registerClass:[CommentTableViewCell class] forCellReuseIdentifier:@"Cell"];
    [self.tableView registerClass:[jinghuaTableViewCell class] forCellReuseIdentifier:@"Header"];
    [self _beginRequest];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    // Return the number of sections.
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    // Return the number of rows in the section.
    if (section == 0) {
        return 1;
    }
    return self.dataArray.count;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    if (indexPath.section == 0) {
        jinghuaModels *model = self.itemModel;
        jinghuaTableViewCell *modelCell = [[[jinghuaTableViewCell alloc] init] autorelease];
        return modelCell.text.frame.origin.y + model.contentSize.height + [model.height floatValue]*310/[model.width floatValue] + 50;
    }
    CommentModels *commentModel = self.dataArray[indexPath.row];
    CommentTableViewCell *tabelCell = [[[CommentTableViewCell alloc] init] autorelease];
    if ((tabelCell.text.frame.origin.y + commentModel.contentSize.height) > (tabelCell.profile_image.frame.origin.y + tabelCell.profile_image.frame.size.height)) {
        return tabelCell.text.frame.origin.y + commentModel.contentSize.height;
    }else{
    
        return tabelCell.profile_image.frame.origin.y + tabelCell.profile_image.frame.size.height;
    }
    
}
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{

    if (section == 0) {
        return @"";
    }
    return @"最新评论";
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    if (indexPath.section == 0) {
        jinghuaTableViewCell *Cell = [tableView dequeueReusableCellWithIdentifier:@"Header" forIndexPath:indexPath];
        jinghuaModels *model = self.itemModel;
        Cell.userNameLabel.text = self.itemModel.userName;

        Cell.created_timeLabel.text = self.itemModel.created_time;
        [Cell.profile_imageLabel sd_setImageWithURL:[NSURL URLWithString:self.itemModel.profil_image]];
        Cell.labelText.text = self.itemModel.text;
        Cell.labelText.frame = CGRectMake(Cell.labelText.frame.origin.x, Cell.labelText.frame.origin.y, Cell.labelText.frame.size.width, self.itemModel.contentSize.height);
        NSLog(@"self.itemModel.contentSize.height = %f", self.itemModel.contentSize.height);
        CGFloat VotesY = Cell.labelText.frame.origin.y + Cell.labelText.frame.size.height+70;
        
        // 添加响应方法
//        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handelDetailGesture:)];
//        tap.cancelsTouchesInView = NO;
//        tap.numberOfTapsRequired = 1;
//        tap.numberOfTouchesRequired = 1;
//        Cell.profile_image.userInteractionEnabled = YES;
//        [Cell.profile_image addGestureRecognizer:tap];
//        UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handelDetailGesture:)];
//        tap.cancelsTouchesInView = NO;
//        tap.numberOfTapsRequired = 1;
//        tap.numberOfTouchesRequired = 1;
//
//        [Cell.userName addGestureRecognizer:tap1];
        

        [Cell.imageImage sd_setImageWithURL:[NSURL URLWithString:self.itemModel.image]];
//        Cell.imageImage.contentMode = UIViewContentModeTop;
//        Cell.imageImage.clipsToBounds = YES;
        Cell.imageImage.frame = CGRectMake(Cell.imageImage.frame.origin.x, VotesY, 310, [model.height floatValue]*310/[model.width floatValue]);
        Cell.image.frame = CGRectMake(Cell.image.frame.origin.x, VotesY, 310, [model.height floatValue]*310/[model.width floatValue]);
        
        CGFloat Y = Cell.image.frame.origin.y + Cell.image.frame.size.height;
        Cell.favoriteCount.text = self.itemModel.love;
        Cell.favoriteImage.image = [UIImage imageNamed:@"ding_black.png"];
        Cell.favorite.frame = CGRectMake(Cell.favorite.frame.origin.x, Y+5, Cell.favorite.frame.size.width, Cell.favorite.frame.size.height);
        
        Cell.dislikeCount.text = self.itemModel.hate;
        Cell.dislikeImage.image = [UIImage imageNamed:@"cai_lightdark.png"];
        Cell.dislike.frame = CGRectMake(Cell.dislike.frame.origin.x, Y+5, Cell.dislike.frame.size.width, Cell.dislike.frame.size.height);
        
        Cell.commentCount.text = self.itemModel.comment;
        Cell.commentImage.image = [UIImage imageNamed:@"IconFreeCNCenterTopic@2x.png"];
        Cell.comment.frame = CGRectMake(Cell.comment.frame.origin.x, Y+5, Cell.comment.frame.size.width, Cell.comment.frame.size.height);
        
        Cell.shareCount.text = self.itemModel.share;
        Cell.shareImage.image = [UIImage imageNamed:@"icon_share@2x.png"];
        Cell.share.frame = CGRectMake(Cell.share.frame.origin.x, Y+5, Cell.share.frame.size.width, Cell.share.frame.size.height);
    
        
        
        
//        [Cell.userName addTarget:self action:@selector(handleButtonDetail:) forControlEvents:UIControlEventTouchUpInside];
        [Cell.profile_image addTarget:self action:@selector(handleButtonDetail:) forControlEvents:UIControlEventTouchUpInside];
        Cell.profile_image.tag = indexPath.row + 100;
//        [Cell.created_time addTarget:self action:@selector(handleButtonDetail:) forControlEvents:UIControlEventTouchUpInside];
       
        [Cell.image addTarget:self action:@selector(handleButtonImage:) forControlEvents:UIControlEventTouchUpInside];
        
        Cell.image.tag = 100 + indexPath.row;
        
    return Cell;
    }else{
    
        CommentTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
        CommentModels *commentModel = self.dataArray[indexPath.row];
        [cell.profile_image sd_setImageWithURL:[NSURL URLWithString:commentModel.model.profile_image]];
        UITapGestureRecognizer *tap2 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handeldetailGesture:)];
        tap2.cancelsTouchesInView = NO;
        tap2.numberOfTapsRequired = 1;
        tap2.numberOfTouchesRequired = 1;
        
        [cell.profile_image addGestureRecognizer:tap2];
        cell.profile_image.tag = indexPath.row + 200;
        cell.userName.text = commentModel.model.userName;
        cell.text.text = commentModel.text;
        cell.text.frame = CGRectMake(cell.text.frame.origin.x, cell.text.frame.origin.y, cell.text.frame.size.width, commentModel.contentSize.height);
        cell.favoriteLabel.text = commentModel.favoriteCount;
        cell.favorityImage.image = [UIImage imageNamed:@"ding_black.png"];
    
        return cell;

    }
        
}
- (void)handleButtonDetail:(UIButton *)sender{
    PictureDetailTableViewController *detail = [[[PictureDetailTableViewController alloc] init] autorelease];
    jinghuaModels *model = [self.dataArray objectAtIndex:sender.tag - 100];
    detail.userid = model.userId;
    detail.nameuser = model.userName;
    detail.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:detail animated:YES];
    

}
- (void)handleButtonImage:(UIButton *)sender{

    PictureDetailsViewController *picture = [[PictureDetailsViewController alloc] init];
    jinghuaModels *model = self.itemModel;
    picture.Picture = model.profil_image;
    
    picture.width = model.width;
    picture.height = model.height;
    picture.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:picture animated:YES];
    [picture release];
    
}

- (void)handeldetailGesture:(UIGestureRecognizer *)sender{

    PictureDetailTableViewController *Detail = [[[PictureDetailTableViewController alloc] init] autorelease];
    Detail.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:Detail animated:YES];
}
/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
