//
//  CommentTableViewController.h
//  Gongchengshi
//
//  Created by lanouhn on 14-10-31.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "jinghuaModels.h"
#import "duanziModels.h"
#import "SelfPhoto.h"
@interface CommentTableViewController : UITableViewController


@property(nonatomic, retain)jinghuaModels *itemModel;
@property(nonatomic, retain)NSString *user_id;
@property(nonatomic, retain)duanziModels *duanziModel;
@property(nonatomic, retain)SelfPhoto *selfPhoto;
@end
