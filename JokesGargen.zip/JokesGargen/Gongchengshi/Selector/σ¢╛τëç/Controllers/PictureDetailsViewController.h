//
//  PictureDetailsViewController.h
//  BigDragon
//
//  Created by 蓝欧科技 on 14-10-30.
//  Copyright (c) 2014年 www.lanou3g.com. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BaseTableViewController.h"
#import "MyImageView.h"
@interface PictureDetailsViewController : BaseTableViewController


@property (nonatomic,retain)NSString *Picture;//图片地址

@property (nonatomic, retain)MyImageView *image;//图片

@property (nonatomic, retain)NSString *height;//图片高度
@property (nonatomic, retain)NSString *width;//图片宽度

@end
