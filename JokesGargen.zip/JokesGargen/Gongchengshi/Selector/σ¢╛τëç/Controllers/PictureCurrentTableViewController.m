//
//  PictureCurrentTableViewController.m
//  Gongchengshi
//
//  Created by dqb on 14-10-29.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "PictureCurrentTableViewController.h"
#import "jinghuaModels.h"
#import "QiushiRequestManager.h"
#import "UIImage+WebP.h"
#import "UIImageView+WebCache.h"
#import "jinghuaTableViewCell.h"
#import "PictureDetailsViewController.h"
#import "CommentTableViewController.h"
#import "MJRefresh.h"
#import "WriteDetailViewController.h"
#import "PictureDetailTableViewController.h"
#import "UMViewController.h"
@interface PictureCurrentTableViewController ()<QiushiRequestManagerDelegate>

@property(nonatomic, retain)NSMutableArray *dataArray;
@property(nonatomic, assign) NSInteger count;

@end

@implementation PictureCurrentTableViewController

- (NSMutableArray *)dataArray{

    if (!_dataArray) {
        self.dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
- (void)request:(QiushiRequestManager *)request didFaildWithError:(NSError *)error{
    NSLog(@"%@", error);
}

- (void)request:(QiushiRequestManager *)request didFinishLoadingWithData:(NSData *)data{

    NSMutableDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    NSArray *array = json[@"list"];
    for (id obj in array) {
        jinghuaModels *model =[[jinghuaModels alloc] initWithDictionary:obj];
        [self.dataArray addObject:model];
        [model release];
        
    }
    [self.tableView reloadData];
}
- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    [self.tableView registerClass:[jinghuaTableViewCell class] forCellReuseIdentifier:@"Cell"];
    [self setupRefresh];

}
- (void)setupRefresh
{
    // 1.下拉刷新(进入刷新状态就会调用self的headerRereshing)
    [self.tableView addHeaderWithTarget:self action:@selector(headerRereshing)];
    
    [self.tableView headerBeginRefreshing];
    
    // 2.上拉加载更多(进入刷新状态就会调用self的footerRereshing)
    [self.tableView addFooterWithTarget:self action:@selector(footerRereshing)];
    
    // 设置文字(也可以不设置,默认的文字在MJRefreshConst中修改)
    self.tableView.headerPullToRefreshText = @"✨下拉可以✨刷新了✨";
    self.tableView.headerReleaseToRefreshText = @"✨松开✨马上刷新了✨";
    self.tableView.headerRefreshingText = @"✨正在刷新中✨";
    
    self.tableView.footerPullToRefreshText = @"✨上拉可以加载更多数据了✨";
    self.tableView.footerReleaseToRefreshText = @"✨松开马上加载更多数据了✨";
    self.tableView.footerRefreshingText = @"✨✨✨正在帮你加载中✨✨✨";
}


//合适时机刷新数据
- (void)headerRereshing
{
    // 1.添加数据
    QiushiRequestManager *manager = [[QiushiRequestManager alloc] init];
    manager.delegate = self;
    manager.destinationURLString = @"http://api.budejie.com/api/api_open.php?a=newlist&appname=baisibudejie&asid=8FE33EB2-39D7-4572-8D44-8F7DC91FFB0C&c=data&client=iphone&device=ios%20%E8%AE%BE%E5%A4%87&from=ios&jbk=0&mac=02%3A00%3A00%3A00%3A00%3A00&market=&openudid=8d759955a0af863ed9510d782ff53bb62cd0a126&page=0&per=20&type=10&udid=&ver=3.0";
    [manager startRequest];
    
    
    
    
    
    // 2.2秒后刷新表格UI(此处直接用,不用修改)
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        // 刷新表格
        [self.tableView reloadData];
        
        // (最好在刷新表格后调用)调用endRefreshing可以结束刷新状态
        [self.tableView headerEndRefreshing];
    });
}

- (void)footerRereshing
{
    
    QiushiRequestManager *manager = [[QiushiRequestManager alloc] init];
    manager.delegate = self;
    manager.destinationURLString = [NSString stringWithFormat:@"http://api.budejie.com/api/api_open.php?a=newlist&appname=baisibudejie&asid=8FE33EB2-39D7-4572-8D44-8F7DC91FFB0C&c=data&client=iphone&market=&openudid=8d759955a0af863ed9510d782ff53bb62cd0a126&page=%ld&per=20&type=10&udid=&ver=3.0", _count+2];
    [manager startRequest];
    
    // 2.2秒后刷新表格UI(此处直接用,不用修改)
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        // 刷新表格
        [self.tableView reloadData];
        
        // (最好在刷新表格后调用)调用endRefreshing可以结束刷新状态
        [self.tableView footerEndRefreshing];
        _count += 1;
    });
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    // Return the number of rows in the section.
    return self.dataArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    jinghuaTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    
    jinghuaModels *model = self.dataArray[indexPath.row];
    
    cell.userNameLabel.text = model.userName;
    cell.created_timeLabel.text = model.created_time;
    cell.labelText.text = model.text;
    
    cell.labelText.frame = CGRectMake(cell.labelText.frame.origin.x, cell.labelText.frame.origin.y, cell.labelText.frame.size.width, model.contentSize.height);
    
    [cell.profile_imageLabel sd_setImageWithURL:[NSURL URLWithString:model.profil_image]];
    cell.profile_image.tag = indexPath.row + 100;
    [cell.imageImage sd_setImageWithURL:[NSURL URLWithString:model.image]];
    CGFloat Y = cell.text.frame.origin.y + model.contentSize.height;
    cell.image.frame = CGRectMake(cell.imageImage.frame.origin.x, Y, 310, [model.height floatValue]*310/[model.width floatValue]);
    cell.imageImage.frame = CGRectMake(cell.imageImage.frame.origin.x, Y, 310, [model.height floatValue]*310/[model.width floatValue]);
    //    if (cell.imageImage.frame.size.height  > 320) {
    //        cell.imageImage.contentMode = UIViewContentModeTop;
    //        cell.imageImage.clipsToBounds = YES;
    //    }
    CGFloat VotesY = cell.imageImage.frame.origin.y + cell.imageImage.frame.size.height+10;
    
    
    
    
    cell.favoriteImage.image = [UIImage imageNamed:@"ding_black.png"];
    cell.favorite.frame = CGRectMake(cell.favorite.frame.origin.x, VotesY, cell.favorite.frame.size.width, cell.favorite.frame.size.height);
    cell.dislikeImage.image = [UIImage imageNamed:@"cai_lightdark.png"];
    cell.dislike.frame = CGRectMake(cell.dislike.frame.origin.x, VotesY, cell.dislike.frame.size.width, cell.dislike.frame.size.height);
    cell.commentImage.image = [UIImage imageNamed:@"IconFreeCNCenterTopic@2x.png"];
    cell.comment.frame = CGRectMake(cell.comment.frame.origin.x, VotesY, cell.comment.frame.size.width, cell.comment.frame.size.height);
    cell.shareImage.image = [UIImage imageNamed:@"icon_share@2x.png"];
    cell.share.frame = CGRectMake(cell.share.frame.origin.x, VotesY, cell.share.frame.size.width, cell.share.frame.size.height);
    cell.favoriteCount.text = model.love;
    cell.dislikeCount.text = model.hate;
    cell.commentCount.text = model.comment;
    cell.shareCount.text = model.share;

    
    [cell.userName addTarget:self action:@selector(handleButtonDetailAction:) forControlEvents:UIControlEventTouchUpInside];
    [cell.created_time addTarget:self action:@selector(handleButtonDetailAction:) forControlEvents:UIControlEventTouchUpInside];
    [cell.profile_image addTarget:self action:@selector(handleButtonDetailAction:) forControlEvents:UIControlEventTouchUpInside];
    
    [cell.comment addTarget:self action:@selector(handleCommenButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    cell.comment.tag = indexPath.row;
    [cell.image addTarget:self action:@selector(handelImageButton:) forControlEvents:UIControlEventTouchUpInside];
    cell.image.tag = indexPath.row;
    [cell.share addTarget:self action:@selector(handelShareAction:) forControlEvents:UIControlEventTouchUpInside];
    
    return cell;
}

- (void)handelShareAction:(UIButton *)sender{
    UMViewController *viewController = [[UMViewController alloc]init];
    [[UIApplication sharedApplication].keyWindow addSubview:viewController.view];
    [viewController release];
    
}
- (void)handleButtonDetailAction:(UIButton *)sender{
   
    PictureDetailTableViewController *picture = [[[PictureDetailTableViewController alloc] init] autorelease];
    jinghuaModels *model = [self.dataArray objectAtIndex:sender.tag - 100];
    picture.userid = model.userId;
    picture.nameuser = model.userName;
    picture.hidesBottomBarWhenPushed = YES;
    [[self.scrollViewController navigationController]pushViewController:picture animated:YES];
}
- (void)handelImageButton:(UIButton *)sender{
    NSLog(@"%@", sender);
    PictureDetailsViewController *picture = [[PictureDetailsViewController alloc] init];
    jinghuaModels *model = self.dataArray[sender.tag];
    picture.Picture = model.image;
    NSLog(@"model.image = %@", model.image);
    NSLog(@"model.profil_image = %@", model.profil_image);
    picture.height = model.height;
    picture.width = model.width;
//    picture.hidesBottomBarWhenPushed = YES;

    [[self.scrollViewController navigationController] pushViewController:picture animated:YES];
    [picture release];
}
- (void)handleCommenButtonAction:(UIButton *)sender{
    CommentTableViewController *comment = [[[CommentTableViewController alloc] init] autorelease];
    jinghuaModels *model =self.dataArray[sender.tag];
    comment.itemModel = model;
    comment.user_id = model.idString;
    
    [[self.scrollViewController navigationController]pushViewController:comment animated:YES];
   
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
   
    jinghuaModels *itemModel = [self.dataArray objectAtIndex:indexPath.row];
    jinghuaTableViewCell *tableModel = [[[jinghuaTableViewCell alloc] init] autorelease];

    return tableModel.text.frame.origin.y + itemModel.contentSize.height + [itemModel.height floatValue]*310/[itemModel.width floatValue] + 50;
}
/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
