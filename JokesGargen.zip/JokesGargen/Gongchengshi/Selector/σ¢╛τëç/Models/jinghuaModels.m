//
//  jinghuaModels.m
//  Gongchengshi
//
//  Created by lanouhn on 14-10-28.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "jinghuaModels.h"

@implementation jinghuaModels


- (id)initWithDictionary:(NSDictionary *)dict{

    if (self = [super init]) {
        self.userName = [dict objectForKey:@"name"];
        self.created_time = [dict objectForKey:@"created_at"];
        self.profil_image = [dict objectForKey:@"profile_image"];
        self.image = [dict objectForKey:@"image0"];
        self.text = [dict objectForKey:@"text"];
        self.hate = [dict objectForKey:@"hate"];
        self.love = [dict objectForKey:@"love"];
        self.share = [dict objectForKey:@"forward"];
        self.comment = [dict objectForKey:@"comment"];
        self.height = [dict objectForKey:@"height"];
        self.width = [dict objectForKey:@"width"];
        self.idString = [dict objectForKey:@"id"];
        self.userId = [dict objectForKey:@"user_id"];
    }
    return self;
}

- (CGSize)contentSize{

    CGSize size = [self.text boundingRectWithSize:CGSizeMake(310, 0) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:20]} context:nil].size;
    return size;
}
+ (id)modelWithDictionary:(NSDictionary *)dict{

    return [[[[self class]alloc]initWithDictionary:dict] autorelease];
}
- (void)dealloc{

    [_userName release];
    [_created_time release];
    [_profil_image release];
    [_image release];
    [_text release];
    [_hate release];
    [_love release];
    [_comment release];
    [_share release];
    [_userId release];
    [_idString release];
    [super dealloc];
}

@end
