//
//  CommentUserModels.h
//  Gongchengshi
//
//  Created by lanouhn on 14-10-31.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CommentUserModels : NSObject

@property(nonatomic, retain)NSString *idString; // data_id
@property(nonatomic, retain)NSString *profile_image; // 用户头像
@property(nonatomic, retain)NSString *gender; // 性别
@property(nonatomic, retain)NSString *userName; // 用户名
@property(nonatomic, retain)NSString *weiboID; //

- (id)initWithDictionary:(NSDictionary *)dict;
+ (id)modelWithDictionary:(NSDictionary *)dict;

@end
