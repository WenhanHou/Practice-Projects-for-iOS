//
//  CommentModels.m
//  Gongchengshi
//
//  Created by lanouhn on 14-10-31.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "CommentModels.h"

@implementation CommentModels

- (id)initWithDictionary:(NSDictionary *)dict{

    if (self = [super init]) {
        self.text = dict[@"content"];
        self.created_time = dict[@"ctime"];
        self.data_id = dict[@"data_id"];
        self.favoriteCount = dict[@"like_count"];
        self.model = [CommentUserModels modelWithDictionary:dict[@"user"]];
        
    }
    return self;
}
- (CGSize)contentSize{
    
    CGSize size = [self.text boundingRectWithSize:CGSizeMake(310, 0) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:20]} context:nil].size;
    return size;
}
+ (id)modelWithDictionary:(NSDictionary *)dict{
    return [[[[self class] alloc] initWithDictionary:dict] autorelease];
}

- (void)dealloc{

    [_text release];
    [_created_time release];
    [_data_id release];
    [_favoriteCount release];
    [_model release];
    [super dealloc];
}
@end
