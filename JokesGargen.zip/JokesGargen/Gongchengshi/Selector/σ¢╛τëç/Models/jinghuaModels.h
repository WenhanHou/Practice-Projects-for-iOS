//
//  jinghuaModels.h
//  Gongchengshi
//
//  Created by lanouhn on 14-10-28.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface jinghuaModels : NSObject

@property(nonatomic, retain)NSString *userName; // 用户名
@property(nonatomic, retain)NSString *created_time; // 发表时间
@property(nonatomic, retain)NSString *profil_image; // 头像图片
@property(nonatomic, retain)NSString *image; // 图片
@property(nonatomic, retain)NSString *text; // 文本
@property(nonatomic, retain)NSString *hate; // 讨厌
@property(nonatomic, retain)NSString *love; // 喜欢
@property(nonatomic, retain)NSString *share; // 分享
@property(nonatomic, retain)NSString *comment; // 评论
@property(nonatomic, assign)CGFloat finalHeight; // 最后高度
@property(nonatomic, assign)CGSize contentSize; // 内容的高度
@property(nonatomic, retain)NSString *height; // 图片高度
@property(nonatomic, retain)NSString *width; // 图片宽度
@property(nonatomic, retain)NSString *idString; // 用户ID
@property(nonatomic, retain)NSString *userId; // 

- (id)initWithDictionary:(NSDictionary *)dict;
+ (id)modelWithDictionary:(NSDictionary *)dict;


@end
