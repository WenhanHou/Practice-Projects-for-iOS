//
//  CommentUserModels.m
//  Gongchengshi
//
//  Created by lanouhn on 14-10-31.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "CommentUserModels.h"

@implementation CommentUserModels

- (id)initWithDictionary:(NSDictionary *)dict{

    if (self = [super init]) {
        self.idString = dict[@"id"];
        self.profile_image = dict[@"profile_image"];
        self.gender = dict[@"sex"];
        self.userName = dict[@"username"];
        self.weiboID = dict[@"weibo_uid"];
        
    }
    return self;
}

+ (id)modelWithDictionary:(NSDictionary *)dict{

    return [[[[self class] alloc] initWithDictionary:dict] autorelease];
}
- (void)dealloc{

    [_idString release];
    [_profile_image release];
    [_gender release];
    [_userName release];
    [_weiboID release];
    [super dealloc];
}
@end
