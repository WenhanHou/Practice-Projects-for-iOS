//
//  CommentModels.h
//  Gongchengshi
//
//  Created by lanouhn on 14-10-31.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CommentUserModels.h"
@interface CommentModels : NSObject

@property(nonatomic, retain)NSString *text; // 评论内容
@property(nonatomic, retain)NSString *created_time; // 发表评论时间
@property(nonatomic, retain)NSNumber *data_id; //
@property(nonatomic, retain)NSString *favoriteCount; // 喜欢人数
@property(nonatomic, retain)CommentUserModels *model;
@property(nonatomic, assign)CGFloat finalHeight; // 最后高度
@property(nonatomic, assign)CGSize contentSize; // 内容的高度


- (id)initWithDictionary:(NSDictionary *)dict;
+ (id)modelWithDictionary:(NSDictionary *)dict;

@end
