//
//  LogInViewController.m
//  Gongchengshi
//
//  Created by lanouhn on 14-11-6.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "LogInViewController.h"
#import "UMSocial.h"
#import "UIImageView+WebCache.h"

@interface LogInViewController ()
@property(nonatomic, retain) UIImageView *imageView;
@property(nonatomic, retain) UMSocialSnsPlatform *snsPlatform;
@property(nonatomic, retain) UMSocialAccountEntity *snsAccount;
@property(nonatomic, retain) UILabel *usernameLabel;
@property(nonatomic, retain) NSString *userName;
@property(nonatomic, retain) NSString *Avatar;

- (void)showUserInformation;

@end

@implementation LogInViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}




- (void)showUserInformation{
    self.imageView = [[[UIImageView alloc] initWithFrame:CGRectMake(110, 90, 100, 100)] autorelease];
    self.imageView.backgroundColor = [UIColor yellowColor];
    self.usernameLabel = [[[UILabel alloc] initWithFrame:CGRectMake(80, 210, 150, 30)] autorelease];
    self.usernameLabel.adjustsFontSizeToFitWidth = YES;
    self.usernameLabel.textAlignment = NSTextAlignmentCenter;

    [self.imageView sd_setImageWithURL:[NSURL URLWithString:self.snsAccount.iconURL] placeholderImage:[UIImage imageNamed:@"aliAvatar"]];
    self.usernameLabel.text = self.snsAccount.userName;
    NSLog(@"1111111111111111%@", self.snsAccount.userName);
    [self.view addSubview:self.usernameLabel];
    [self.view addSubview:self.imageView];

}

- (void)viewDidAppear:(BOOL)animated{
    [self showUserInformation];
    [super viewDidAppear:animated];
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    // Do any additional setup after loading the view.
        UILabel *tengxun = [[UILabel alloc] initWithFrame:CGRectMake(110, 250, 110, 30)];
    tengxun.text = @"腾讯微博账号登陆";
    tengxun.textAlignment = NSTextAlignmentCenter;
    tengxun.font = [UIFont systemFontOfSize:12];
    UITapGestureRecognizer *tengxunTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handletengxunButtonAction:)];
    tengxunTap.cancelsTouchesInView = NO;
    tengxunTap.numberOfTapsRequired = 1;
    tengxunTap.numberOfTouchesRequired = 1;
    tengxun.userInteractionEnabled = YES;
    [tengxun addGestureRecognizer:tengxunTap];
    
    UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(30, 290, 260, 1)];
    lineView.alpha = 0.3;
    lineView.backgroundColor = [UIColor lightGrayColor];
    UILabel *xinlang = [[UILabel alloc] initWithFrame:CGRectMake(110, 299, 100, 30)];
    xinlang.text = @"新浪微博账号登陆";
    xinlang.textAlignment = NSTextAlignmentCenter;
    xinlang.font = [UIFont systemFontOfSize:12];
    UITapGestureRecognizer *xinlangTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handlexinlangButtonAction:)];
    xinlangTap.cancelsTouchesInView = NO;
    xinlangTap.numberOfTapsRequired = 1;
   xinlangTap.numberOfTouchesRequired = 1;
    xinlang.userInteractionEnabled = YES;
    [xinlang addGestureRecognizer:xinlangTap];
    UIView *lineView1 = [[UIView alloc] initWithFrame:CGRectMake(30, 340, 260, 1)];
    lineView1.alpha = 0.3;
    lineView1.backgroundColor = [UIColor lightGrayColor];


       [self.view addSubview:tengxun];
    [self.view addSubview:xinlang];
    [self.view addSubview:lineView];
    [self.view addSubview:lineView1];
    [tengxun release];
    [xinlang release];
    [lineView1 release];
    [lineView release];
    
}

- (void)handletengxunButtonAction:(UIGestureRecognizer *)tengxun{
    self.snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToTencent];
    self.snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response)
                                  {
                                      if (response.responseCode == UMSResponseCodeSuccess) {
                                          self.snsAccount = [[UMSocialAccountManager socialAccountDictionary] valueForKey:UMShareToTencent];
                                          NSLog(@"username is %@, uid is %@, token is %@",self.snsAccount.userName,self.snsAccount.usid,self.snsAccount.iconURL);
                                              self.userName = self.snsAccount.userName;
                                              self.Avatar = self.snsAccount.iconURL;
                                          NSLog(@"%@", self.userName);

                                          
                                          
                                      }

                                  });
    
}


- (void)handlexinlangButtonAction:(UIGestureRecognizer *)xinlang{
    self.snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:UMShareToSina];
    self.snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response)
                                       {
                                           if (response.responseCode == UMSResponseCodeSuccess) {
                                               self.snsAccount = [[UMSocialAccountManager socialAccountDictionary] valueForKey:UMShareToSina];
                                               NSLog(@"username is %@, uid is %@, token is %@",self.snsAccount.userName,self.snsAccount.usid,self.snsAccount.iconURL);
                                           }
                                           
                                           
                                       });

}





- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
