//
//  WriteDetailViewController.h
//  Gongchengshi
//
//  Created by lanouhn on 14-11-3.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WriteDetailViewController : UIViewController

@end
