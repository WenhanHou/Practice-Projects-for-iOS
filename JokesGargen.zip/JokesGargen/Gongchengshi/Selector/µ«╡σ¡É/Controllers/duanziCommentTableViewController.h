//
//  duanziCommentTableViewController.h
//  Gongchengshi
//
//  Created by lanouhn on 14-11-2.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "duanziModels.h"
@interface duanziCommentTableViewController : UITableViewController

@property(nonatomic,retain)duanziModels *duanziModel;
@property(nonatomic, retain)NSString *user_id;
@end
