//
//  WriteDetailViewController.m
//  Gongchengshi
//
//  Created by lanouhn on 14-11-3.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "WriteDetailViewController.h"
#import "duanziCommentTableViewController.h"
@interface WriteDetailViewController ()<UIAlertViewDelegate>

@property(nonatomic, retain)UITextView *text;
@end

@implementation WriteDetailViewController

- (UITextView *)text{

    if (!_text) {
        self.text = [[[UITextView alloc] initWithFrame:self.view.frame] autorelease];
//        self.text.placeholder = @"请输入文字";
        self.text.backgroundColor = [UIColor whiteColor];
        [self.view addSubview:_text];
    }
    return _text;
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
//    self.view.backgroundColor = [UIColor whiteColor];
//    UITextField *text = [[UITextField alloc] initWithFrame:self.view.frame];
//    text.textColor = [UIColor blackColor];
//    text.font = [UIFont systemFontOfSize:15];
//    [text becomeFirstResponder];
     [self.text becomeFirstResponder];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(handelButtonAction:)];
}

- (void)handelButtonAction:(UIButton *)sender{
    if (![self.text.text isEqualToString:@""]) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"评论完成" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
        [alert show];
        [alert release];
    }else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"评论不能为空" delegate:self cancelButtonTitle:nil otherButtonTitles:@"确定", nil];
        [alert show];
        [alert release];
    }
    
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (1 == buttonIndex) {
    
    [self.navigationController popViewControllerAnimated:YES];
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
