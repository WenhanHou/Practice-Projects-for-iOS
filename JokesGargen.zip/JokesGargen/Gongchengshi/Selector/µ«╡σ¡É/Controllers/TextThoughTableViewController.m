//
//  TextThoughTableViewController.m
//  Gongchengshi
//
//  Created by dqb on 14-10-29.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "TextThoughTableViewController.h"
#import "QiushiRequestManager.h"
#import "duanziTableViewCell.h"
#import "UIImageView+WebCache.h"
#import "MJRefresh.h"
#import "CommentModels.h"
#import "PictureDetailTableViewController.h"
#import "duanziCommentTableViewController.h"
#import "UMViewController.h"
@interface TextThoughTableViewController ()<QiushiRequestManagerDelegate>

@property(nonatomic, retain)NSMutableArray *dataArray;
@property(nonatomic, assign)NSInteger count;

@end

@implementation TextThoughTableViewController
- (NSMutableArray *)dataArray{

    if (!_dataArray) {
        self.dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
-(void)request:(QiushiRequestManager *)request didFaildWithError:(NSError *)error{

    NSLog(@"%@", error);
    
}

- (void)request:(QiushiRequestManager *)request didFinishLoadingWithData:(NSData *)data{

    NSMutableDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    NSMutableArray *array = json[@"list"];
    for (id obj in array) {
        duanziModels *model = [[duanziModels alloc] initWithDictionary:obj];
        [self.dataArray addObject:model];
        [model release];
        [self.tableView reloadData];
    }
}


//- (void)_begainRequest{
//
//    QiushiRequestManager *manager = [[QiushiRequestManager alloc] init];
//    manager.delegate = self;
//    manager.destinationURLString = @"http://api.budejie.com/api/api_open.php?a=list&appname=baisibudejie&asid=8FE33EB2-39D7-4572-8D44-8F7DC91FFB0C&c=data&client=iphone&device=ios%20%E8%AE%BE%E5%A4%87&from=ios&jbk=0&mac=02%3A00%3A00%3A00%3A00%3A00&market=&openudid=8d759955a0af863ed9510d782ff53bb62cd0a126&order=timewarp&page=0&per=20&type=29&udid=&ver=3.0";
//    [manager startRequest];
//}
- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    [self.tableView registerClass:[duanziTableViewCell class] forCellReuseIdentifier:@"cell"];
    [self setupRefresh];
}
- (void)setupRefresh
{
    // 1.下拉刷新(进入刷新状态就会调用self的headerRereshing)
    [self.tableView addHeaderWithTarget:self action:@selector(headerRereshing)];
    
    [self.tableView headerBeginRefreshing];
    
    // 2.上拉加载更多(进入刷新状态就会调用self的footerRereshing)
    [self.tableView addFooterWithTarget:self action:@selector(footerRereshing)];
    
    // 设置文字(也可以不设置,默认的文字在MJRefreshConst中修改)
    self.tableView.headerPullToRefreshText = @"✨✨✨下拉可以刷新了✨✨✨";
    self.tableView.headerReleaseToRefreshText = @"✨✨松开马上刷新了✨✨";
    self.tableView.headerRefreshingText = @"✨✨✨正在刷新中✨✨✨";
    
    self.tableView.footerPullToRefreshText = @"✨上拉可以加载更多数据了✨";
    self.tableView.footerReleaseToRefreshText = @"✨松开马上加载更多数据了✨";
    self.tableView.footerRefreshingText = @"✨正在帮你加载中✨";
}


//合适时机刷新数据
- (void)headerRereshing
{
    // 1.添加数据
    QiushiRequestManager *manager = [[QiushiRequestManager alloc] init];
    manager.delegate = self;
    manager.destinationURLString = @"http://api.budejie.com/api/api_open.php?a=list&appname=baisibudejie&asid=8FE33EB2-39D7-4572-8D44-8F7DC91FFB0C&c=data&client=iphone&device=ios%20%E8%AE%BE%E5%A4%87&from=ios&jbk=0&mac=02%3A00%3A00%3A00%3A00%3A00&market=&openudid=8d759955a0af863ed9510d782ff53bb62cd0a126&order=timewarp&page=0&per=20&type=29&udid=&ver=3.0";
    [manager startRequest];
    
    
    
    
    
    // 2.2秒后刷新表格UI(此处直接用,不用修改)
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        // 刷新表格
        [self.tableView reloadData];
        
        // (最好在刷新表格后调用)调用endRefreshing可以结束刷新状态
        [self.tableView headerEndRefreshing];
    });
}

- (void)footerRereshing
{
    
    QiushiRequestManager *manager = [[QiushiRequestManager alloc] init];
    manager.delegate = self;
    manager.destinationURLString = [NSString stringWithFormat:@"http://api.budejie.com/api/api_open.php?a=list&appname=baisibudejie&asid=8FE33EB2-39D7-4572-8D44-8F7DC91FFB0C&c=data&client=iphone&openudid=8d759955a0af863ed9510d782ff53bb62cd0a126&order=timewarp&page=%ld&per=20&type=29&udid=&ver=3.0", _count+2];
    [manager startRequest];
    
    // 2.2秒后刷新表格UI(此处直接用,不用修改)
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        // 刷新表格
        [self.tableView reloadData];
        
        // (最好在刷新表格后调用)调用endRefreshing可以结束刷新状态
        [self.tableView footerEndRefreshing];
        _count += 1;
    });
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

    // Return the number of rows in the section.
    return self.dataArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    duanziTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
    // Configure the cell...
    self.duanziModel = [self.dataArray objectAtIndex:indexPath.row];

    duanziModels *model = [self.dataArray objectAtIndex:indexPath.row];
    cell.username.text = model.username;
    
    [cell.profile_image_view sd_setImageWithURL:[NSURL URLWithString:model.profile_image]];
    [cell.profile_image addSubview:cell.profile_image_view];
    
    cell.profile_image.tag = indexPath.row + 100;

    
    cell.created_time.text = model.created_time;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handelDetailGesture:)];
    tap.numberOfTouchesRequired = 1;
    tap.numberOfTapsRequired = 1;
    tap.cancelsTouchesInView = NO;
    [cell.username addGestureRecognizer:tap];
    UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handelDetailGesture:)];
    tap1.numberOfTapsRequired = 1;
    tap1.numberOfTouchesRequired = 1;
    tap1.cancelsTouchesInView = NO;
    [cell.created_time addGestureRecognizer:tap1];
    UITapGestureRecognizer *tap3 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handelDetailGesture:)];
    tap3.numberOfTouchesRequired = 1;
    tap3.numberOfTapsRequired = 1;
    tap3.cancelsTouchesInView = NO;
    [cell.profile_image addGestureRecognizer:tap3];
    
    cell.text.text = model.text;
    cell.text.frame = CGRectMake(cell.text.frame.origin.x, cell.text.frame.origin.y, cell.text.frame.size.width, model.contentSize.height);
//    CGFloat VotesY = cell.text.frame.origin.y + cell.text.frame.size.height;
    
    cell.favoriteImage.image = [UIImage imageNamed:@"ding_black.png"];
    [cell.favorite addSubview:cell.favoriteImage];
    cell.dislikeImage.image = [UIImage imageNamed:@"cai_lightdark.png"];
    [cell.dislike addSubview:cell.dislikeImage];
    cell.commentImage.image = [UIImage imageNamed:@"IconFreeCNCenterTopic@2x.png"];
    [cell.comment addSubview:cell.commentImage];
    cell.shareImage.image = [UIImage imageNamed:@"icon_share@2x.png"];
    [cell.share addSubview:cell.shareImage];
    
    cell.favoriteCount.text = model.favorite;
    [cell.favorite addSubview:cell.favoriteCount];
    cell.dislikeCount.text = model.dislike;
    [cell.dislike addSubview:cell.dislikeCount];
    cell.commentCount.text = model.comment;
    [cell.comment addSubview:cell.commentCount];
    cell.shareCount.text = model.share;
    [cell.share addSubview:cell.shareCount];
    
    [cell setContentForCellWithItemModel:model];
    UITapGestureRecognizer *tap4 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handelCommentGesture:)];
    tap4.numberOfTapsRequired = 1;
    tap4.numberOfTouchesRequired = 1;
    tap4.cancelsTouchesInView = NO;
    cell.text.tag = indexPath.row;
    [cell.text addGestureRecognizer:tap4];
    UITapGestureRecognizer *tap5 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handelCommentGesture:)];
    tap5.numberOfTouchesRequired = 1;
    tap5.numberOfTapsRequired = 1;
    tap5.cancelsTouchesInView = NO;
    [cell.comment addGestureRecognizer:tap5];
    cell.comment.tag = indexPath.row;
    
    [cell.share addTarget:self action:@selector(handelShareAction:) forControlEvents:UIControlEventTouchUpInside];

    return cell;
}

- (void)handelShareAction:(UIButton *)sender{
    UMViewController *viewController = [[UMViewController alloc]init];
    [[UIApplication sharedApplication].keyWindow addSubview:viewController.view];
    [viewController release];
    
}
- (void)handelDetailGesture:(UIGestureRecognizer *)sender{

    PictureDetailTableViewController *pic = [[[PictureDetailTableViewController alloc] init] autorelease];
    UIButton *imagevi = (UIButton *)sender.view;
    duanziModels *model = [self.dataArray objectAtIndex:imagevi.tag - 100];
    pic.userid = model.userID;
    pic.nameuser = model.username;
    
    pic.hidesBottomBarWhenPushed = YES;
    [[self.scrollViewController navigationController]pushViewController:pic animated:YES];
}
- (void)handelCommentGesture:(UIGestureRecognizer *)sender{

    duanziCommentTableViewController *comment = [[[duanziCommentTableViewController alloc] init] autorelease];
    UILabel *commentLabel = (UILabel *)sender.view;
    duanziModels *model = [self.dataArray objectAtIndex:commentLabel.tag];
    
    comment.user_id = model.idString;
    comment.duanziModel = model;
    [[self.scrollViewController navigationController]pushViewController:comment animated:YES];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    duanziModels *itemModel = [self.dataArray objectAtIndex:indexPath.row];
    
    CGFloat heights = itemModel.contentSize.height;
    return heights + 130;
    
    
    
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
