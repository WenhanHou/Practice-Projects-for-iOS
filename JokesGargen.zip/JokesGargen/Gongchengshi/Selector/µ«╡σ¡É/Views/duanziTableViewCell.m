//
//  duanziTableViewCell.m
//  Gongchengshi
//
//  Created by lanouhn on 14-10-30.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "duanziTableViewCell.h"

@implementation duanziTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}
//- (UIButton *)usernameButton{
//
//    if (!_usernameButton) {
//        self.usernameButton = [UIButton buttonWithType:UIButtonTypeCustom];
//        self.usernameButton.frame = CGRectMake(60, 15, 150, 25);
//        [self.contentView addSubview:_usernameButton];
//        [self.usernameButton addSubview:self.username];
//    
//    }
//    return _usernameButton;
//}
- (UILabel *)username{

    if (!_username) {
        self.username = [[[UILabel alloc] initWithFrame:CGRectMake(60, 15, 150, 25)] autorelease];
        self.username.userInteractionEnabled = YES;
        self.username.font = [UIFont systemFontOfSize:15];
        self.username.textAlignment = NSTextAlignmentLeft;
        [self.contentView addSubview:_username];
    }
    return _username;
}
//- (UIButton *)created_timeButton{
//
//    if (!_created_timeButton) {
//        self.created_timeButton = [UIButton buttonWithType:UIButtonTypeCustom];
//        self.created_timeButton.frame = CGRectMake(60, 35, 150, 25);
//        [self.contentView addSubview:_created_timeButton];
//        [self.created_timeButton addSubview:self.created_time];
//        self.created_timeButton.backgroundColor = [UIColor purpleColor];
//    }
//    return _created_timeButton;
//}

- (UILabel *)created_time{

    if (!_created_time) {
        self.created_time = [[[UILabel alloc] initWithFrame:CGRectMake(60, 35, 150, 25)] autorelease];
        self.created_time.userInteractionEnabled = YES;
        self.created_time.font = [UIFont systemFontOfSize:15];
        self.created_time.textAlignment = NSTextAlignmentLeft;
        self.created_time.textColor = [UIColor blackColor];
        [self.contentView addSubview:_created_time];
    }
    return _created_time;
}
- (UIButton *)profile_image{

    if (!_profile_image) {
        self.profile_image = [UIButton buttonWithType:UIButtonTypeCustom];
        self.profile_image.frame = CGRectMake(0, 10, 50, 50);
        [self.profile_image addSubview:_profile_image_view];
        [self.contentView addSubview:_profile_image];
    }
    return _profile_image;
}

- (UIImageView *)profile_image_view{

    if (!_profile_image_view) {
        self.profile_image_view = [[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 50, 50)] autorelease];
        
    }
    return _profile_image_view;
}
//- (UIButton *)textButton{
//
//    if (!_textButton) {
//        self.textButton = [UIButton buttonWithType:UIButtonTypeCustom];
//        self.textButton.frame = CGRectMake(0, 65, 310, 150);
//        [self.contentView addSubview:_textButton];
//        [self.textButton addSubview:_text];
//    }
//    return _textButton;
//}
- (UILabel *)text{

    if (!_text) {
        self.text = [[[UILabel alloc] initWithFrame:CGRectMake(0, 75, 310, 150)] autorelease];
        self.text.font = [UIFont systemFontOfSize:20];
        self.text.userInteractionEnabled = YES;
        self.text.numberOfLines = 0;
        [self.contentView addSubview:_text];
    }
    return _text;
}
- (UIButton *)favorite{
    
    if (!_favorite) {
        self.favorite = [UIButton buttonWithType:UIButtonTypeCustom];
        _favorite.frame = CGRectMake(0, 275, 310/4, 30);
        
        
        [self.contentView addSubview:_favorite];
    }
    return _favorite;
}
- (UIImageView *)favoriteImage{
    
    if (!_favoriteImage) {
        self.favoriteImage = [[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 310/8 - 10, 30)] autorelease];
    }
    return _favoriteImage;
}
- (UILabel *)favoriteCount{
    if (!_favoriteCount) {
        self.favoriteCount = [[[UILabel alloc] initWithFrame:CGRectMake(310/8, 0, 310/8 + 10, 30)] autorelease];
        _favoriteCount.textAlignment = NSTextAlignmentLeft;
        _favoriteCount.font = [UIFont systemFontOfSize:15];
    }
    return _favoriteCount;
}
- (UIButton *)dislike{
    
    if (!_dislike) {
        self.dislike = [UIButton buttonWithType:UIButtonTypeCustom];
        self.dislike.frame = CGRectMake(310/4, 275, 310/4, 30);
       
     [self.contentView addSubview:self.dislike];
    }
    return _dislike;
}
- (UIImageView *)dislikeImage{
    
    if (!_dislikeImage) {
        self.dislikeImage = [[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 310/8 - 10, 30)] autorelease];
    }
    return _dislikeImage;
}

- (UILabel *)dislikeCount{
    
    if (!_dislikeCount) {
        self.dislikeCount = [[[UILabel alloc] initWithFrame:CGRectMake(310/8, 0, 310/8 + 10, 30)] autorelease];
        _dislikeCount.textAlignment = NSTextAlignmentLeft;
        _dislikeCount.font = [UIFont systemFontOfSize:15];
        _dislikeCount.textColor = [UIColor blackColor];
    }
    return _dislikeCount;
}

- (UIButton *)share{
    
    if (!_share) {
        self.share = [UIButton buttonWithType:UIButtonTypeCustom];
        self.share.frame = CGRectMake(310/2, 275, 310/4, 30);
        [self.contentView addSubview:_share];
    }
    return _share;
}

- (UIImageView *)shareImage{
    
    if (!_shareImage) {
        self.shareImage = [[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 310/8, 30)] autorelease];
        
    }
    return _shareImage;
}

- (UILabel *)shareCount{
    
    if (!_shareCount) {
        self.shareCount = [[[UILabel alloc] initWithFrame:CGRectMake(310/8, 0, 310/8, 30)] autorelease];
        self.shareCount.textAlignment = NSTextAlignmentLeft;
        self.shareCount.font = [UIFont systemFontOfSize:15];
    }
    return _shareCount;
}
- (UIButton *)comment{
    
    if (!_comment) {
        self.comment = [UIButton buttonWithType:UIButtonTypeCustom];
        self.comment.frame = CGRectMake(310/4*3, 275, 310/4, 30);
        [self.contentView addSubview:_comment];
    }
    return _comment;
}
- (UIImageView *)commentImage{
    
    if (!_commentImage) {
        self.commentImage = [[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 310/8, 30)] autorelease];
    }
    return _commentImage;
}
- (UILabel *)commentCount{
    
    if (!_commentCount) {
        self.commentCount = [[[UILabel alloc] initWithFrame:CGRectMake(310/8, 0, 310/8, 30)] autorelease];
        self.commentCount.textAlignment = NSTextAlignmentLeft;
        self.commentCount.font = [UIFont systemFontOfSize:15];
        
    }
    return _commentCount;
}

- (void)dealloc{

    [_username release];
    [_created_time release];
    [_profile_image_view release];
    [_profile_image release];
    [_text release];
    [_favorite release];
    [_favoriteCount release];
    [_favoriteImage release];
    [_dislike release];
    [_dislikeCount release];
    [_dislikeImage release];
    [_comment release];
    [_commentCount release];
    [_commentImage release];
    [_share release];
    [_shareCount release];
    [_shareImage release];
    [super dealloc];
}
- (void)setFrame:(CGRect)frame{
    
    frame.origin.x += 5;
    frame.size.width -= 10;
    frame.size.height -= 5;
    [super setFrame:frame];
}
- (void)setContentForCellWithItemModel:(duanziModels *)duanziMadel{

    self.username.text = duanziMadel.username;
    self.text.text = duanziMadel.text;
//    self.favoriteCount.text = [NSString stringWithFormat:@"zan"];
//    self.favoriteImage.image = [UIImage imageNamed:@"ding_black.png"];
//    
    self.text.frame = CGRectMake(self.text.frame.origin.x, self.text.frame.origin.y, self.text.frame.size.width, duanziMadel.contentSize.height);
    
    CGFloat votesY = self.text.frame.origin.y + duanziMadel.contentSize.height;
    //NSLog(@"------------%@",NSStringFromCGRect(self.favorite.frame));
    self.favorite.frame = CGRectMake(self.favorite.frame.origin.x, votesY+5, self.favorite.frame.size.width, self.favorite.frame.size.height);
    self.dislike.frame = CGRectMake(self.dislike.frame.origin.x, votesY+5, self.dislike.frame.size.width, self.dislike.frame.size.height);
    self.comment.frame = CGRectMake(self.comment.frame.origin.x, votesY+5, self.comment.frame.size.width, self.comment.frame.size.height);
    self.share.frame = CGRectMake(self.share.frame.origin.x, votesY+5, self.share.frame.size.width, self.share.frame.size.height);
    duanziMadel.finalHeight = votesY + self.favorite.frame.size.height + 10;
    //NSLog(@"------------------------------------%f", duanziMadel.finalHeight);
}
- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
