//
//  duanziModels.h
//  Gongchengshi
//
//  Created by lanouhn on 14-10-30.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface duanziModels : NSObject

@property(nonatomic, retain)NSString *username; // 用户名
@property(nonatomic, retain)NSString *created_time; // 发布时间
@property(nonatomic, retain)NSString *profile_image; // 头像
@property(nonatomic, retain)NSString *text;
@property(nonatomic, retain)NSString *favorite; // 喜欢
@property(nonatomic, retain)NSString *dislike; // 不喜欢
@property(nonatomic, retain)NSString *comment; // 评论
@property(nonatomic, retain)NSString *share; // 分享
@property(nonatomic, assign)CGFloat finalHeight; // 最后高度
@property(nonatomic, assign)CGSize contentSize; // 内容的高度
@property(nonatomic, retain)NSString *idString; // 用户ID
@property(nonatomic, retain)NSString *userID; //

- (id)initWithDictionary:(NSDictionary *)dict;
+ (id)modelWithDictionary:(NSDictionary *)dict;
@end
