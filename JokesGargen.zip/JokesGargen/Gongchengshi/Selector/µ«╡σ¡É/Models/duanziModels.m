//
//  duanziModels.m
//  Gongchengshi
//
//  Created by lanouhn on 14-10-30.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "duanziModels.h"

@implementation duanziModels

- (id)initWithDictionary:(NSDictionary *)dict{

    if (self = [super init]) {
        self.username = dict[@"name"];
        self.created_time = dict[@"created_at"];
        self.profile_image = dict[@"profile_image"];
        self.favorite = dict[@"love"];
        self.dislike = dict[@"hate"];
        self.comment = dict[@"comment"];
        self.share = dict[@"forward"];
        self.text = dict[@"text"];
        self.idString = dict[@"id"];
        self.userID = dict[@"user_id"];
    }
    return self;
}

- (CGSize)contentSize{
    
    CGSize size = [self.text boundingRectWithSize:CGSizeMake(310, 0) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:20]} context:nil].size;
    return size;
}

+ (id)modelWithDictionary:(NSDictionary *)dict{

    return [[[[self class]alloc]initWithDictionary:dict] autorelease];
}

- (void)dealloc{

    [_username release];
    [_comment release];
    [_created_time release];
    [_favorite release];
    [_dislike release];
    [_profile_image release];
    [_share release];
    [_text release];
    [_userID release];
    [_idString release];
    [super dealloc];
}
@end
