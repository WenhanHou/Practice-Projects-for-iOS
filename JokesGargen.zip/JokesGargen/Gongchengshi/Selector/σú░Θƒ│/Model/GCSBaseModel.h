//
//  GCSBaseModel.h
//  Gongchengshi
//
//  Created by 杨庭仪 on 14-10-29.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "GCSModel.h"

@interface GCSBaseModel : GCSModel

@property (nonatomic, retain) NSString *name;//用户名
@property (nonatomic, retain) NSString *profile_image;//用户头像,URL
@property (nonatomic, retain) NSString *user_id;//用户ID
@property (nonatomic ,retain) NSString *idid;//用户ID
@property (nonatomic, retain) NSString *created_at;//帖子通过时间
@property (nonatomic, retain) NSString *like;//喜欢(顶)
@property (nonatomic, retain) NSString *hate;//不喜欢(踩)
@property (nonatomic, retain) NSString *comment;//评论数量
@property (nonatomic, retain) NSString *forward;//分享次数
@property (nonatomic, retain) NSString *image0;//帖子配图,URL
@property (nonatomic, retain) NSString *text;//文本内容;
@property (nonatomic, retain) NSNumber *playcount;//播放次数
@property (nonatomic, retain) NSString *voiceuri;//音频地址,URL
@property (nonatomic, retain) NSNumber *imageHeight;
@property (nonatomic, retain) NSNumber *imageWidth;

@property (nonatomic, retain) NSString *data_id;

- (CGSize)contentSize;

@end
