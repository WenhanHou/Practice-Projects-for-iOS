//
//  GCSBaseModel.m
//  Gongchengshi
//
//  Created by 杨庭仪 on 14-10-29.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "GCSBaseModel.h"

@implementation GCSBaseModel

- (id)initWithDictionary:(NSDictionary *)dict{
    if (self = [super init]) {
        self.name = [dict objectForKey:@"name"];//用户名
        self.profile_image = [dict objectForKey:@"profile_image"];//用户头像地址
        self.user_id = [dict objectForKey:@"user_id"];//用户id
        self.idid = [dict objectForKey:@"id"];
        self.created_at = [dict objectForKey:@"created_at"];//帖子通过时间
        self.like = [dict objectForKey:@"love"];//顶
        self.hate = [dict objectForKey:@"cai"];//踩
        self.comment = [dict objectForKey:@"comment"];//评论数
        self.forward = [dict objectForKey:@"forward"];//转发数
        self.image0 = [dict objectForKey:@"image0"];//帖子配图地址
        self.text = [dict objectForKey:@"text"];//帖子正文
        self.playcount = [dict objectForKey:@"playcount"];//播放次数
        self.voiceuri = [dict objectForKey:@"voiceuri"];//音频地址
        self.data_id = [dict objectForKey:@"data_id"];
        self.imageHeight = [dict objectForKey:@"height"];//图片高度
        self.imageWidth = [dict objectForKey:@"width"];
    }
    return self;
}


- (CGSize)contentSize{
    CGSize size = [self.text boundingRectWithSize:CGSizeMake(300, 0) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : [UIFont systemFontOfSize:12]} context:nil].size;
    
    return size;
}

- (void)dealloc{
    [_name release];
    [_profile_image release];
    [_user_id release];
    [_created_at release];
    [_like release];
    [_hate release];
    [_comment release];
    [_forward release];
    [_image0 release];
    [_text release];
    [_playcount release];
    [super dealloc];
}

@end
