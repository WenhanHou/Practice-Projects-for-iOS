//
//  GCSModel.h
//  Gongchengshi
//
//  Created by 杨庭仪 on 14-10-29.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GCSModel : NSObject

- (id)initWithDictionary:(NSDictionary *)dict;
+ (id)modelWithDictionary:(NSDictionary *)dict;

@end
