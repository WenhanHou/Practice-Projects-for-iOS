//
//  GCSModel.m
//  Gongchengshi
//
//  Created by 杨庭仪 on 14-10-29.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "GCSModel.h"

@implementation GCSModel

- (id)initWithDictionary:(NSDictionary *)dict{
    if (self = [super init]) {
        
    }
    return self;
}

+ (id)modelWithDictionary:(NSDictionary *)dict{
    return [[[[self class] alloc] initWithDictionary:dict] autorelease];
}

@end

