//
//  VoiceBestTableViewController.h
//  Gongchengshi
//
//  Created by dqb on 14-10-28.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseTableViewController.h"
#import <AVFoundation/AVFoundation.h>
#import "GCSBaseModel.h"

@class AudioPlayer;


@interface VoiceBestTableViewController : BaseTableViewController<AVAudioPlayerDelegate>

//@property (nonatomic, retain)AVAudioPlayer * audioPlayer;//播放器属性
//@property (nonatomic, retain)UIProgressView * progress;//进度条
//@property (nonatomic, retain)UISlider * volumSlider;//音量滑杆
//@property (nonatomic, retain)NSTimer * timer;//定时器
@property (nonatomic, retain)GCSBaseModel *model;

@property (nonatomic, retain)AudioPlayer *audioplayer;
@property (nonatomic, assign) CGFloat height;
@property (nonatomic, assign) CGRect imageHeight;


+ (id)sharedVoicePlay;

@end
