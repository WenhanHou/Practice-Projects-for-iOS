//
//  VoiceCreamTableViewController.m
//  Gongchengshi
//
//  Created by dqb on 14-10-29.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "VoiceCreamTableViewController.h"
#import "GCSBaseModel.h"
#import "GCSBaseViewCell.h"
#import "QiushiRequestManager.h"
#import "UIImageView+WebCache.h"
#import "MJRefresh.h"
#import "VoiceCommentTableViewController.h"
#import "AudioButton.h"
#import "AudioPlayer.h"
#import "PictureDetailTableViewController.h"
#import "UMViewController.h"

@interface VoiceCreamTableViewController ()<QiushiRequestManagerDelegate>

@property (nonatomic, retain) NSMutableArray *dataArray;
//- (void)_begainRequest;

@end

@implementation VoiceCreamTableViewController

- (NSMutableArray *)dataArray{
    if (!_dataArray) {
        self.dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (void)dealloc{
    [_dataArray release];
    [super dealloc];
}

- (void)request:(QiushiRequestManager *)request didFaildWithError:(NSError *)error{
    NSLog(@"%@", error);
}

- (void)_begainRequest{
    QiushiRequestManager *manager = [[QiushiRequestManager alloc] init];
    manager.destinationURLString = [NSString stringWithFormat:@"http://api.budejie.com/api/api_open.php?a=newlist&appname=baisibudejie&c=voice&client=iphone&page=0&per=20&type=31&udid=&ver=3.0"];
    manager.delegate = self;
    [manager startRequest];
}

- (void)request:(QiushiRequestManager *)request didFinishLoadingWithData:(NSData *)data{
    NSMutableDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    
    NSArray *array = json[@"list"];
    for (id object in array) {
        GCSBaseModel *model = [[GCSBaseModel alloc] initWithDictionary:object];
        
        [self.dataArray addObject:model];
        [model release];
        [self.tableView reloadData];
    }
}

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    //注册单元格
    [self.tableView registerClass:[GCSBaseViewCell class] forCellReuseIdentifier:@"Cell"];
    [self _begainRequest];
    
//    self.refreshControl = [[[UIRefreshControl alloc] initWithFrame:CGRectZero] autorelease];
//    [self.refreshControl addTarget:self action:@selector(handelRefreshAction:) forControlEvents:UIControlEventValueChanged];
    [self setupRefresh];
}

//=========================================================================================
//该方法不用考虑直接用
- (void)setupRefresh
{
    // 1.下拉刷新(进入刷新状态就会调用self的headerRereshing)
    [self.tableView addHeaderWithTarget:self action:@selector(headerRereshing)];
//#warning 自动刷新(一进入程序就下拉刷新)
    [self.tableView headerBeginRefreshing];
    
    // 2.上拉加载更多(进入刷新状态就会调用self的footerRereshing)
    [self.tableView addFooterWithTarget:self action:@selector(footerRereshing)];
    
    // 设置文字(也可以不设置,默认的文字在MJRefreshConst中修改)
    self.tableView.headerPullToRefreshText = @"✨下拉可以刷新了✨";
    self.tableView.headerReleaseToRefreshText = @"✨松开马上刷新了✨";
    self.tableView.headerRefreshingText = @"✨正在帮你刷新中✨";
    
    self.tableView.footerPullToRefreshText = @"✨上拉可以加载更多数据了✨";
    self.tableView.footerReleaseToRefreshText = @"✨松开马上加载更多数据了✨";
    self.tableView.footerRefreshingText = @"✨正在帮你加载中✨";
}

#pragma mark 开始进入刷新状态
//合适时机刷新数据
- (void)headerRereshing
{
    // 1.添加数据
    //    [[PersonDataHelper sharePersonDataHelper].allPersonArray removeAllObjects];
    //    [PersonDataHelper sharePersonDataHelper].count = 1;
    //    [[PersonDataHelper sharePersonDataHelper] getPersonMessage];
    QiushiRequestManager *manager = [QiushiRequestManager sharedManager];
    manager.destinationURLString = [NSString stringWithFormat:@"http://api.budejie.com/api/api_open.php?a=list&c=voice&page=0&per=20&type=31"];
    //    manager.paramsDictionary[@"a"] = @"list";
    //    manager.paramsDictionary[@"c"] = @"voice";
    //    manager.paramsDictionary[@"page"] = @"0";
    //    manager.paramsDictionary[@"per"] = @"20";
    //    manager.paramsDictionary[@"type"] = @"31";
    manager.delegate = self;
    [manager startRequest];
    
    // 2.2秒后刷新表格UI(此处直接用,不用修改)
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        // 刷新表格
        [self.tableView reloadData];
        
        // (最好在刷新表格后调用)调用endRefreshing可以结束刷新状态
        [self.tableView headerEndRefreshing];
    });
}

- (void)footerRereshing
{
    QiushiRequestManager *manager = [QiushiRequestManager sharedManager];
    manager.destinationURLString = [NSString stringWithFormat:@"http://api.budejie.com/api/api_open.php?a=list&c=voice&page=0&per=20&type=31"];
    //    manager.paramsDictionary[@"a"] = @"list";
    //    manager.paramsDictionary[@"c"] = @"voice";
    //    manager.paramsDictionary[@"page"] = @"0";
    //    manager.paramsDictionary[@"per"] = @"20";
    //    manager.paramsDictionary[@"type"] = @"31";
    manager.delegate = self;
    [manager startRequest];
    
    // 2.2秒后刷新表格UI(此处直接用,不用修改)
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        // 刷新表格
        [self.tableView reloadData];
        
        // (最好在刷新表格后调用)调用endRefreshing可以结束刷新状态
        [self.tableView footerEndRefreshing];
    });
}



//============================================================================================



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return self.dataArray.count;
    
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    // Configure the cell...
    GCSBaseViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    GCSBaseModel *model = self.dataArray[indexPath.row];
    cell.userNameLabel.text = model.name;
    cell.userNameLabel.font = [UIFont systemFontOfSize:15];
    
    cell.thisTextLabel.frame = CGRectMake(cell.thisTextLabel.frame.origin.x, cell.thisTextLabel.frame.origin.y, cell.thisTextLabel.frame.size.width, model.contentSize.height);
    cell.thisTextLabel.numberOfLines = 0;
    CGFloat Y = cell.thisTextLabel.frame.origin.y + cell.thisTextLabel.frame.size.height+15;
    cell.thisTieziImage.frame = CGRectMake(cell.thisTieziImage.frame.origin.x, Y, 300, [model.imageHeight floatValue]*310/[model.imageWidth floatValue]);
    CGFloat VotesY = cell.thisTieziImage.frame.origin.y + cell.thisTieziImage.frame.size.height+10;
    
    cell.thisTextLabel.text = model.text;
    cell.thisTextLabel.font = [UIFont systemFontOfSize:15];
    [cell.thisTieziImage sd_setImageWithURL:[NSURL URLWithString:model.image0]];
    [cell.userIconImage sd_setImageWithURL:[NSURL URLWithString:model.profile_image]];
    cell.dingLabel.text = model.like;
    cell.dingLabel.font = [UIFont systemFontOfSize:15];
    cell.ding.frame = CGRectMake(cell.ding.frame.origin.x, VotesY, cell.ding.frame.size.width, cell.ding.frame.size.height);
    
    
    cell.caiLabel.text = model.hate;
    cell.caiLabel.font = [UIFont systemFontOfSize:15];
    cell.cai.frame = CGRectMake(cell.cai.frame.origin.x, VotesY, cell.cai.frame.size.width, cell.cai.frame.size.height);
    
    
    cell.zhuanfaLabel.text = model.forward;
    cell.zhuanfaLabel.font = [UIFont systemFontOfSize:15];
    cell.zhuanfa.frame = CGRectMake(cell.zhuanfa.frame.origin.x, VotesY, cell.zhuanfa.frame.size.width, cell.zhuanfa.frame.size.height);
    
    
    cell.pinglunLabel.text = model.comment;
    cell.pinglunLabel.font = [UIFont systemFontOfSize:15];
    cell.pinglunNumber.frame = CGRectMake(cell.pinglunNumber.frame.origin.x, VotesY, cell.pinglunNumber.frame.size.width, cell.pinglunNumber.frame.size.height);
    
    //头像 名字按钮
    [cell.userIconButton addTarget:self action:@selector(handleToDetailButton:) forControlEvents:UIControlEventTouchUpInside];
    [cell.userNameButton addTarget:self action:@selector(handleToDetailButton:) forControlEvents:UIControlEventTouchUpInside];
    
    //帖子正文  评论按钮
//    [cell.textButton addTarget:self action:@selector(handleToCommentButton:) forControlEvents:UIControlEventTouchUpInside];
    [cell.pinglunNumber addTarget:self action:@selector(handleToCommentButton:) forControlEvents:UIControlEventTouchUpInside];
//    cell.textButton.tag = indexPath.row + 999;
    cell.pinglunNumber.tag = indexPath.row + 999;
    cell.thisTextLabel.tag = indexPath.row + 999;
    
    UITapGestureRecognizer *textButton = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleToCommentButtonTap:)];
    textButton.numberOfTapsRequired = 1;
    textButton.numberOfTouchesRequired = 1;
    textButton.cancelsTouchesInView = NO;
    [cell.thisTextLabel addGestureRecognizer:textButton];
    cell.thisTextLabel.userInteractionEnabled = YES;
    [cell.pinglunNumber addTarget:self action:@selector(handleToCommentButton:) forControlEvents:UIControlEventTouchUpInside];
    
    [cell configurePlayerButton];
    [cell.voiceButton addTarget:self action:@selector(handlePlayVoiceButton:) forControlEvents:UIControlEventTouchUpInside];
    cell.voiceButton.tag = 200 + (indexPath.row);
    cell.userIconButton.tag = indexPath.row + 100;
     [cell.zhuanfa addTarget:self action:@selector(handleForwardButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    return cell;
}

- (void)handleForwardButtonAction:(UIButton *)forwardButton{
    UMViewController *viewController = [[UMViewController alloc]init];
    [[UIApplication sharedApplication].keyWindow addSubview:viewController.view];
    [viewController release];
    
}

//跳转到评论
- (void)handleToCommentButton:(UIButton *)sender{
    VoiceCommentTableViewController *commentVC = [[[VoiceCommentTableViewController alloc] init] autorelease];
    GCSBaseModel *model = self.dataArray[sender.tag - 999];
    commentVC.itemModel = model;
    commentVC.itemModel.data_id = model.idid;
    //    NSLog(@"12311231\n\n\n\n\n\n\nn\n\n\n\nn\-.-.-.-.-%@", commentVC.GCModel.comment);
    //    NSLog(@"%@54545454544444----------", model.idid);
    [[self.scrollViewController navigationController] pushViewController:commentVC animated:YES];
}
- (void)handleToCommentButtonTap:(UITapGestureRecognizer *)sender{
    VoiceCommentTableViewController *commentVC = [[[VoiceCommentTableViewController alloc] init] autorelease];
    UIButton *imagevi = (UIButton *)sender.view;
    GCSBaseModel *model = [self.dataArray objectAtIndex:imagevi.tag - 999];
    commentVC.itemModel = model;
    commentVC.itemModel.data_id = model.idid;
    [[self.scrollViewController navigationController] pushViewController:commentVC animated:YES];
}

- (void)handlePlayVoiceButton:(AudioButton *)sender{
    
    GCSBaseModel *item = self.dataArray[sender.tag - 200];
    
    if (self.audioplayer == nil) {
        self.audioplayer = [[[AudioPlayer alloc] init] autorelease];
    }
    
    if ([self.audioplayer.button isEqual:sender]) {
        [self.audioplayer play];
    } else {
        [self.audioplayer stop];
        
        self.audioplayer.button = sender;
        self.audioplayer.url = [NSURL URLWithString:item.voiceuri];
        NSLog(@"-----------%@",item.voiceuri);
        
        [self.audioplayer play];
    }
}

//跳转到用户信息详情
- (void)handleToDetailButton:(UIButton *)sender{
    PictureDetailTableViewController *detailView = [[[PictureDetailTableViewController alloc] init] autorelease];
    GCSBaseModel *model = [self.dataArray objectAtIndex:sender.tag - 100];
    
    detailView.userid = model.user_id;
    detailView.nameuser = model.name;
    
    [[self.scrollViewController navigationController] pushViewController:detailView animated:YES];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    GCSBaseModel * model = self.dataArray[indexPath.row];
    GCSBaseViewCell *modelCell = [[[GCSBaseViewCell alloc] init] autorelease];
    return modelCell.textLabel.frame.origin.y + model.contentSize.height + modelCell.thisTieziImage.frame.size.height + modelCell.ding.frame.size.height + 150;
}

//- (void)acquireDataSucceed{
//    [self.tableView reloadData];
//    [self.refreshControl endRefreshing];
//}


/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */

/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
 {
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
 } else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }
 }
 */

/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
 {
 }
 */

/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
 {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
