//
//  DetailTableViewController.h
//  Gongchengshi
//
//  Created by 杨庭仪 on 14-10-30.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailTableViewController : UITableViewController

@end
