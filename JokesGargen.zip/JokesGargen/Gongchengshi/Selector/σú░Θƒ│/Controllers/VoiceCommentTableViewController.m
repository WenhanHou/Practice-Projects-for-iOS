//
//  VoiceCommentTableViewController.m
//  Gongchengshi
//
//  Created by 杨庭仪 on 14-11-3.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "VoiceCommentTableViewController.h"
#import "QiushiRequestManager.h"
#import "GCSBaseModel.h"
#import "UIImageView+WebCache.h"
#import "CommentTableViewCell.h"
#import "jinghuaTableViewCell.h"
#import "CommentModels.h"
#import "PictureDetailsViewController.h"
#import "GCSBaseViewCell.h"
#import "VoiceCommentViewController.h"
#import "GCSBaseViewCell.h"
#import "AudioPlayer.h"
#import "AudioButton.h"
#import "WriteDetailViewController.h"
@interface VoiceCommentTableViewController ()<QiushiRequestManagerDelegate>

@property (nonatomic, retain)NSMutableArray *dataArray;
@property (nonatomic, retain)UILabel *label;
- (void)_beginRequest;

@end

@implementation VoiceCommentTableViewController

- (NSMutableArray *)dataArray{
    if (!_dataArray) {
        self.dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (void)request:(QiushiRequestManager *)request didFaildWithError:(NSError *)error{
    NSLog(@"%@", error);
}

- (void)request:(QiushiRequestManager *)request didFinishLoadingWithData:(NSData *)data{
    if (![self.itemModel.comment isEqualToString:@"0"]) {
        NSMutableDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
        
        NSMutableArray *array = json[@"data"];
//        NSLog(@"%@", [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]);
        for (id obj in array) {
            CommentModels *model = [[[CommentModels alloc] initWithDictionary:obj] autorelease];
            [self.dataArray addObject:model];
        }
        [self.tableView reloadData];
    }
}

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)_beginRequest{
    QiushiRequestManager *manager = [[QiushiRequestManager alloc] init];
    manager.delegate = self;
    manager.destinationURLString = [NSString stringWithFormat:@"http://api.budejie.com/api/api_open.php?a=dataList&c=comment&data_id=%@&hot=1&page=1&per=20", self.itemModel.data_id];
    [manager startRequest];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.navigationItem.title = @"评论";
    
    [self.tableView registerClass:[CommentTableViewCell class] forCellReuseIdentifier:@"Cell"];
    [self.tableView registerClass:[GCSBaseViewCell class] forCellReuseIdentifier:@"Header"];
    [self _beginRequest];
}

- (void)viewWillDisappear:(BOOL)animated{
    [self.label removeFromSuperview];
}

- (void)viewWillAppear:(BOOL)animated{
    self.label = [[[UILabel alloc] initWithFrame:CGRectMake(0, 0, 320, 49)] autorelease];
    self.label.backgroundColor = [UIColor cyanColor];
    //    label.backgroundColor = [UIColor whiteColor];
    self.label.userInteractionEnabled = YES;
    UIButton *commentButton = [UIButton buttonWithType:UIButtonTypeCustom];
    commentButton.frame = CGRectMake(5, 7, 220, 39);
    commentButton.backgroundColor = [UIColor whiteColor];
    [commentButton setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    [commentButton setTitle:@"写评论" forState:UIControlStateNormal];
    [commentButton addTarget:self action:@selector(handleChangeCommentButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    UIButton *shareButton = [UIButton buttonWithType:UIButtonTypeCustom];
    shareButton.frame = CGRectMake(230, 7, 85/2, 39);
    UIImageView *shareImage = [[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 40, 39)] autorelease];
    shareImage.image = [UIImage imageNamed:@"icon_share@2x.png"];
    [shareButton addSubview:shareImage];
    
    UIButton *shoucangButton = [UIButton buttonWithType:UIButtonTypeCustom];
    shoucangButton.frame = CGRectMake(275, 7, 40, 39);
    UIImageView *shoucang = [[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 40, 39)] autorelease];
    shoucang.image = [UIImage imageNamed:@"comment-colletion-icon@2x.png"];
    [shoucangButton addSubview:shoucang];
    [self.label addSubview:shoucangButton];
    [self.label addSubview:shareButton];
    [self.label addSubview:commentButton];
    [self.tabBarController.tabBar addSubview:self.label];
}

- (void)handleChangeCommentButtonAction:(UIButton *)sender{
    WriteDetailViewController *commentVC = [[[WriteDetailViewController alloc] init] autorelease];
    [self.navigationController pushViewController:commentVC animated:YES];
    commentVC.hidesBottomBarWhenPushed = YES;
}

- (void)handleSendButtonAction:(UIButton *)sender{
//    if (sender.selected) {
//        UITextField *textField = [[UITextField alloc] initWithFrame:CGRectMake(70, 150, 40, 30)];
//        [self.tabBarLabel addSubview:textField];
//    } else {
//        UIButton *voiceButton = [UIButton buttonWithType:UIButtonTypeCustom];
//        voiceButton.frame = CGRectMake(70, 150, 40, 30);
//        [voiceButton setTitle:@"现在开始录音" forState:UIControlStateNormal];
//        [self.tabBarLabel addSubview:voiceButton];
//    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    if (section == 0) {
        return 1;
    }
    return self.dataArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        return 400;
    }
    return 90;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return @"";
    }
    return @"最新评论";
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
    GCSBaseViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Header" forIndexPath:indexPath];
    
    cell.userNameLabel.text = self.itemModel.name;
    cell.createdTime.text = self.itemModel.created_at;
    [cell.userIconImage sd_setImageWithURL:[NSURL URLWithString:self.itemModel.profile_image]];
    cell.thisTextLabel.text = self.itemModel.text;
        cell.thisTextLabel.font = [UIFont systemFontOfSize:12];
        
   cell.thisTextLabel.frame = CGRectMake(cell.thisTextLabel.frame.origin.x, cell.thisTextLabel.frame.origin.y, cell.thisTextLabel.frame.size.width, cell.thisTextLabel.frame.size.height);
    //响应方法
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handelDetailGesture:)];
        tap.cancelsTouchesInView = NO;
        tap.numberOfTapsRequired = 1;
        tap.numberOfTouchesRequired = 1;
        cell.userIconImage.userInteractionEnabled = YES;
        [cell.userIconImage addGestureRecognizer:tap];
        
        UITapGestureRecognizer *tap1 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handelDetailGesture:)];
        tap1.cancelsTouchesInView = NO;
        tap1.numberOfTapsRequired = 1;
        tap1.numberOfTouchesRequired = 1;
        
        [cell.userNameLabel addGestureRecognizer:tap1];
        
        [cell.thisTieziImage sd_setImageWithURL:[NSURL URLWithString:self.itemModel.image0]];
//        cell.thisTieziImage.contentMode = UIViewContentModeTop;
//        cell.thisTieziImage.clipsToBounds = YES;
        
        cell.dingLabel.text = self.itemModel.like;
        
        cell.caiLabel.text = self.itemModel.hate;
        
        cell.pinglunLabel.text = self.itemModel.comment;
        
        cell.zhuanfaLabel.text = self.itemModel.forward;
        
        [cell.voiceButton addTarget:self action:@selector(handlePlayVoiceButton:) forControlEvents:UIControlEventTouchUpInside];
        cell.voiceButton.tag = indexPath.row + 200;
        
    return cell;
    } else {
        CommentTableViewCell *Cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
        CommentModels *CommentModel = self.dataArray[indexPath.row];
        [Cell.profile_image sd_setImageWithURL:[NSURL URLWithString:CommentModel.model.profile_image]];
        Cell.userName.text = CommentModel.model.userName;
        Cell.text.text = CommentModel.text;
        Cell.favoriteLabel.text = CommentModel.favoriteCount;
    
        
        return Cell;
    }
}

//- (void)handelDetailGesture:(UIGestureRecognizer *)sender{
//    
//    PictureDetailsViewController *detail = [[[PictureDetailsViewController alloc] init] autorelease];
//    [self.navigationController pushViewController:detail animated:YES];
//}


- (void)handlePlayVoiceButton:(AudioButton *)sender{
    
    GCSBaseModel *item = self.dataArray[sender.tag - 200];
    
    if (self.audioplayer == nil) {
        self.audioplayer = [[[AudioPlayer alloc] init] autorelease];
    }
    
    if ([self.audioplayer.button isEqual:sender]) {
        [self.audioplayer play];
    } else {
        [self.audioplayer stop];
        
        self.audioplayer.button = sender;
        self.audioplayer.url = [NSURL URLWithString:item.voiceuri];
        NSLog(@"-----------%@",item.voiceuri);
        
        [self.audioplayer play];
    }
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
