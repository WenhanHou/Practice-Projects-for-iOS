//
//  VoiceCommentTableViewController.h
//  Gongchengshi
//
//  Created by 杨庭仪 on 14-11-3.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GCSBaseModel.h"
#import "AudioPlayer.h"

@interface VoiceCommentTableViewController : UITableViewController

@property (nonatomic, retain) GCSBaseModel *itemModel;
@property (nonatomic, retain) NSString *user_id;

@property (nonatomic, retain)AudioPlayer *audioplayer;

+ (id)sharedVoicePlay;



@end
