//
//  VoiceCreamTableViewController.h
//  Gongchengshi
//
//  Created by dqb on 14-10-29.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseTableViewController.h"
#import "AudioPlayer.h"

@interface VoiceCreamTableViewController : BaseTableViewController

@property (nonatomic, retain)AudioPlayer *audioplayer;

@property (nonatomic, assign) CGFloat height;
@property (nonatomic, assign) CGRect imageHeight;

+ (id)sharedVoicePlay;


@end
