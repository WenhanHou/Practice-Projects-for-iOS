//
//  GCSBaseViewCell.m
//  Gongchengshi
//
//  Created by 杨庭仪 on 14-10-29.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "GCSBaseViewCell.h"

@implementation GCSBaseViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        
        [self addSubview:self.userNameButton];
        [self addSubview:self.userIconButton];
        [self addSubview:self.createdTime];
//        [self addSubview:self.textButton];
        [self addSubview:self.thisTieziImage];
        [self.userIconButton addSubview:self.userIconImage];
        [self.userNameButton addSubview:self.userNameLabel];
        [self addSubview:self.thisTextLabel];
        
        [self addSubview:self.ding];
        [self addSubview:self.cai];
        [self addSubview:self.zhuanfa];
        [self addSubview:self.pinglunNumber];
        
        [self.ding addSubview:self.dingLabel];
        [self.cai addSubview:self.caiLabel];
        [self.zhuanfa addSubview:self.zhuanfaLabel];
        [self.pinglunNumber addSubview:self.pinglunLabel];
        
        [self.ding addSubview:self.dingImage];
        [self.cai addSubview:self.caiImage];
        [self.zhuanfa addSubview:self.zhuanfaImage];
        [self.pinglunNumber addSubview:self.pinglunImage];
        
        
    }
    return self;
}
//用户头像按钮-------------------------------------------------
- (UIButton *)userIconButton{
    if (!_userIconButton) {
        self.userIconButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _userIconButton.frame = CGRectMake(10, 10, 40, 40);
//        _userIconButton.backgroundColor = [UIColor redColor];
        
    }
    return _userIconButton;
}
- (UIImageView *)userIconImage{
    if (!_userIconImage) {
        self.userIconImage = [[[UIImageView alloc] init] autorelease];
        _userIconImage.frame = CGRectMake(0, 0, 40, 40);
        //        _userIconImage.backgroundColor = [UIColor greenColor];
        
    }
    return _userIconImage;
}



//用户名字按钮-------------------------------------------------
- (UIButton *)userNameButton{
    if (!_userNameButton) {
        self.userNameButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _userNameButton.frame = CGRectMake(60, 10, 100, 18);
//        _userNameButton.backgroundColor = [UIColor greenColor];
    }
    return _userNameButton;
}
- (UILabel *)userNameLabel{
    if (!_userNameLabel) {
        self.userNameLabel = [[[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 18)] autorelease];
        //        _userNameLabel.backgroundColor = [UIColor yellowColor];
    }
    return _userNameLabel;
}



//通过审核时间-------------------------------------------------
- (UILabel *)createdTime{
    if (!_createdTime) {
        self.createdTime = [[[UILabel alloc] initWithFrame:CGRectMake(60, 32, 100, 18)] autorelease];
//        _createdTime.backgroundColor = [UIColor yellowColor];
    }
    return _createdTime;
}



//帖子正文按钮-------------------------------------------------
//- (UIButton *)textButton{
//    if (!_textButton) {
//        self.textButton = [UIButton buttonWithType:UIButtonTypeCustom];
//        _textButton.frame = CGRectMake(10, 60, 300, 50);
//        _textButton.backgroundColor = [UIColor cyanColor];
//    }
//    return _textButton;
//}
- (UILabel *)thisTextLabel{
    if (!_thisTextLabel) {
        self.thisTextLabel = [[[UILabel alloc] initWithFrame:CGRectMake(10, 60, 300, 50)] autorelease];
        //        _thisTextLabel.backgroundColor = [UIColor redColor];
        _thisTextLabel.numberOfLines = 0;
    }
    return _thisTextLabel;
}





//帖子图片-------------------------------------------------
- (UIImageView *)thisTieziImage{
    if (!_thisTieziImage) {
        self.thisTieziImage = [[[UIImageView alloc] init] autorelease];
        _thisTieziImage.frame = CGRectMake(10, 120, 300, 250);
//        _thisTieziImage.backgroundColor = [UIColor brownColor];
        _thisTieziImage.userInteractionEnabled = YES;
    }
    return _thisTieziImage;
}






//顶按钮-------------------------------------------------
- (UIButton *)ding{
    if (!_ding) {
        self.ding = [UIButton buttonWithType:UIButtonTypeCustom];
//        _ding.backgroundColor = [UIColor redColor];
        _ding.frame = CGRectMake(10, 375, 270 / 4, 20);
    }
    return _ding;
}
- (UILabel *)dingLabel{
    if (!_dingLabel) {
        self.dingLabel = [[[UILabel alloc] initWithFrame:CGRectMake(30, 0, 37.5, 20)] autorelease];
        //        _dingLabel.backgroundColor = [UIColor yellowColor];
    }
    return _dingLabel;
}
- (UIImageView *)dingImage{
    if (!_dingImage) {
        self.dingImage = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ding_black"]] autorelease];
        _dingImage.frame = CGRectMake(5, 0, 20, 20);
    }
    return _dingImage;
}




//踩按钮-------------------------------------------------
- (UIButton *)cai{
    if (!_cai) {
        self.cai = [UIButton buttonWithType:UIButtonTypeCustom];
//        _cai.backgroundColor = [UIColor greenColor];
        _cai.frame = CGRectMake(270 / 4 + 20, 375, 270 / 4, 20);
    }
    return _cai;
}
- (UILabel *)caiLabel{
    if (!_caiLabel) {
        self.caiLabel = [[[UILabel alloc] initWithFrame:CGRectMake(30, 0, 37.5, 20)] autorelease];
        //        _caiLabel.backgroundColor = [UIColor redColor];
    }
    return _caiLabel;
}
- (UIImageView *)caiImage{
    if (!_caiImage) {
        self.caiImage = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"cai_lightdark"]] autorelease];
        _caiImage.frame = CGRectMake(5, 0, 20, 20);
    }
    return _caiImage;
}



//转发按钮-------------------------------------------------
- (UIButton *)zhuanfa{
    if (!_zhuanfa) {
        self.zhuanfa = [UIButton buttonWithType:UIButtonTypeCustom];
//        _zhuanfa.backgroundColor = [UIColor yellowColor];
        _zhuanfa.frame = CGRectMake(270 / 2 + 30, 375, 270 / 4, 20);
    }
    return _zhuanfa;
}
- (UILabel *)zhuanfaLabel{
    if (!_zhuanfaLabel) {
        self.zhuanfaLabel = [[[UILabel alloc] initWithFrame:CGRectMake(30, 0, 37.5, 20)] autorelease];
        //        _zhuanfaLabel.backgroundColor = [UIColor greenColor];
    }
    return _zhuanfaLabel;
}
- (UIImageView *)zhuanfaImage{
    if (!_zhuanfaImage) {
        self.zhuanfaImage = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"comment-repost-icon"]] autorelease];
        _zhuanfaImage.frame = CGRectMake(5, 0, 20, 20);
    }
    return _zhuanfaImage;
}



//评论按钮-------------------------------------------------
- (UIButton *)pinglunNumber{
    if (!_pinglunNumber) {
        self.pinglunNumber = [UIButton buttonWithType:UIButtonTypeCustom];
//        _pinglunNumber.backgroundColor = [UIColor cyanColor];
        _pinglunNumber.frame = CGRectMake(270 - 30, 375, 270 / 4, 20);
    }
    return _pinglunNumber;
}
- (UILabel *)pinglunLabel{
    if (!_pinglunLabel) {
        self.pinglunLabel = [[[UILabel alloc] initWithFrame:CGRectMake(30, 0, 37.5, 20)] autorelease];
        //        _pinglunLabel.backgroundColor = [UIColor redColor];
    }
    return _pinglunLabel;
}
- (UIImageView *)pinglunImage{
    if (!_pinglunImage) {
        self.pinglunImage = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"IconFreeCNCenterTopic@2x.png"]] autorelease];
        _pinglunImage.frame = CGRectMake(5, 0, 20, 20);
    }
    return _pinglunImage;
}



//播放按键-------------------------------------------------
//- (UIButton *)voiceButton{
//    if (!_voiceButton) {
//        self.voiceButton = [UIButton buttonWithType:UIButtonTypeCustom];
////        [_voiceButton setImage:[UIImage imageNamed:@"movie_voice_play"] forState:UIControlStateNormal];
//        _voiceButton.frame = CGRectMake(20, 325, 40, 40);
//    }
//    return _voiceButton;
//}
//

- (void)configurePlayerButton{
    
    self.voiceButton = [[[AudioButton alloc] initWithFrame:CGRectMake(0, 200, 50, 50)] autorelease];
//    _voiceButton.backgroundColor = [UIColor purpleColor];
      [self.thisTieziImage addSubview:self.voiceButton];

    
}
- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc{
    [_userIconButton release];
    [_userNameButton release];
    [_createdTime release];
    [_textButton release];
    [_userIconImage release];
    [_userNameLabel release];
    [_thisTextLabel release];
    [super dealloc];
}

- (CGFloat)cellHeight{
    return 300;
}

- (void)setContentForCellWithModel:(GCSModel *)itemModel{
    
}

@end
