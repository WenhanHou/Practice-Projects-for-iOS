//
//  GCSBaseViewCell.h
//  Gongchengshi
//
//  Created by 杨庭仪 on 14-10-29.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GCSModel.h"
#import <AVFoundation/AVFoundation.h>

#import "AudioButton.h"

@interface GCSBaseViewCell : UITableViewCell

//用户界面
@property (nonatomic, retain) UIButton *userIconButton;//用户头像按钮
@property (nonatomic, retain) UIButton *userNameButton;//用户名字按钮
@property (nonatomic, retain) UILabel *createdTime;//通过审核时间
@property (nonatomic, retain) UIButton *textButton;//帖子正文按钮
@property (nonatomic, retain) UIImageView *thisTieziImage;//帖子图片

@property (nonatomic, retain) UIImageView *userIconImage;//用户头像
@property (nonatomic, retain) UILabel *userNameLabel;//用户名字
@property (nonatomic, retain) UILabel *thisTextLabel;//帖子正文


//最下面的
@property (nonatomic, retain) UIButton *ding;//顶
@property (nonatomic, retain) UIButton *cai;//踩
@property (nonatomic, retain) UIButton *zhuanfa;//转发
@property (nonatomic, retain) UIButton *pinglunNumber;//评论数

@property (nonatomic, retain) UIImageView *dingImage;
@property (nonatomic, retain) UIImageView *caiImage;
@property (nonatomic, retain) UIImageView *zhuanfaImage;
@property (nonatomic, retain) UIImageView *pinglunImage;

@property (nonatomic, retain) UILabel *dingLabel;
@property (nonatomic, retain) UILabel *caiLabel;
@property (nonatomic, retain) UILabel *zhuanfaLabel;
@property (nonatomic, retain) UILabel *pinglunLabel;


//播放器系列
@property (nonatomic, retain) AudioButton *voiceButton;


- (CGFloat)cellHeight;//设置单元格高度
- (void)setContentForCellWithModel:(GCSModel *)itemModel;//为单元格设置内容,同时重新布局单元格的子视图
- (void)configurePlayerButton;

@end
