//
//  GCSUserDetailViewCell.m
//  Gongchengshi
//
//  Created by 杨庭仪 on 14-10-30.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "GCSUserDetailViewCell.h"

@interface GCSUserDetailViewCell ()

@property (nonatomic, retain) UIImageView *backImage;//背景图

@end

@implementation GCSUserDetailViewCell

- (UIImageView *)backImage{
    if (!_backImage) {
        self.backImage = [[[UIImageView alloc] init] autorelease];
        _backImage.frame = CGRectMake(0, 0, 320, 200);
        _backImage.backgroundColor = [UIColor greenColor];
    }
    return _backImage;
}

- (void)dealloc{
    [_backImage release];
    [super dealloc];
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self addSubview:_backImage];
    }
    return self;
}



/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
