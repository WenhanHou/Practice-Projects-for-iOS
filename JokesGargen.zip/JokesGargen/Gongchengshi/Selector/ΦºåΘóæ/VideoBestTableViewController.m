//
//  VideoBestTableViewController.m
//  Gongchengshi
//
//  Created by dqb on 14-10-28.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "VideoBestTableViewController.h"
#import "BaseVideoTableViewCell.h"
#import "UIImageView+WebCache.h"
#import "QiushiRequestManager.h"
#import <MediaPlayer/MediaPlayer.h>
#import "PictureDetailTableViewController.h"
#import "MyLabel.h"
#import "PlayVideoViewController.h"
#import "Micro.h"
#import "MJRefresh.h"
#import "VideoCommentTableViewController.h"
#import "UMViewController.h"
#import "TYDotIndicatorView.h"

@interface VideoBestTableViewController ()< QiushiRequestManagerDelegate,UITableViewDataSource,UIWebViewDelegate>
@property(nonatomic, retain) NSMutableArray *dataSource;
@property(nonatomic, assign) NSInteger count;
@property(nonatomic, retain) UILabel *label;
@property(nonatomic, retain) TYDotIndicatorView *circleDot;

//- (void)startRequestData;

@end

@implementation VideoBestTableViewController
- (NSMutableArray *)dataSource{
    if (!_dataSource) {
        self.dataSource = [NSMutableArray array];
    
    }
    return _dataSource;
}

- (void)dealloc{
    [_dataSource release];
    [super dealloc];
}

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
        _count = 0;
        
    }
    return self;
}



- (void)viewDidLoad
{
    [super viewDidLoad];
        // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
//     self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    [self.tableView registerClass:[BaseVideoTableViewCell class] forCellReuseIdentifier:@"video"];
    
    [self setupRefresh];
    
}




- (void)request:(QiushiRequestManager *)request didFaildWithError:(NSError *)error{
    NSLog(@"%@", error);
    
}


- (void)request:(QiushiRequestManager *)request didFinishLoadingWithData:(NSData *)data{
    [[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]autorelease];
    NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    for (NSDictionary *dict in jsonDict[@"list"]) {
        VideoModel *videoModel = [VideoModel modelWithDictionary:dict];
        [self.dataSource addObject:videoModel];

     }
    
    [self.tableView reloadData];

}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
//    return[[QiushiRequestManager sharedManager] numberOfVideoItem];
    if (self.dataSource.count == 0) {
        return 1;
    }
        return self.dataSource.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    BaseVideoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"video" forIndexPath:indexPath];
    if (self.dataSource.count == 0) {
        self.label = [[UILabel alloc] initWithFrame:CGRectMake(100, 100, 100, 50)];
        self.label.text = @"加载中";
        self.label.textColor = [UIColor blueColor];
        [cell.contentView addSubview:self.label];
        self.circleDot = [[TYDotIndicatorView alloc] initWithFrame:CGRectMake(60, 100, 260, 50) dotStyle:TYDotIndicatorViewStyleCircle dotColor:[UIColor blueColor] dotSize:CGSizeMake(8, 8)];
        self.circleDot.layer.cornerRadius = 5.0f;
        [self.circleDot startAnimating];
        [self.view addSubview:self.circleDot];
        
    }else{
        [self.circleDot stopAnimating];
        [self.circleDot removeFromSuperview];
        self.label.text = @"";
    
        self.videoModel = [self.dataSource objectAtIndex:indexPath.row];
        [cell setVideoContentForCellWithItemModel:self.videoModel];
        //添加手势方法
        UITapGestureRecognizer *Avatartap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleAvatarAction:)];
        Avatartap.cancelsTouchesInView = NO;
        Avatartap.numberOfTapsRequired = 1;
        Avatartap.numberOfTouchesRequired = 1;
        cell.userAvatar.tag = indexPath.row + 200;
        cell.userAvatar.userInteractionEnabled = YES;
        [cell.userAvatar addGestureRecognizer:Avatartap];
        [cell.playButton addTarget:self action:@selector(handlePlayVideoAction:) forControlEvents:UIControlEventTouchUpInside];
        cell.playButton.tag = 111 + indexPath.row;
        [cell.forwardButton addTarget:self action:@selector(handleForwardButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        [cell.commentButton addTarget:self action:@selector(handleCommentButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        cell.commentButton.tag = indexPath.row + 100;
    }

    return cell;
}

- (void)handleForwardButtonAction:(UIButton *)forwardButton{
    UMViewController *viewController = [[UMViewController alloc]init];
    [[UIApplication sharedApplication].keyWindow addSubview:viewController.view];
    [viewController release];
    
    
}

- (void)handleCommentButtonAction:(UIButton *)commentButton{
    
    VideoCommentTableViewController *comment = [[[VideoCommentTableViewController alloc] init] autorelease];
    VideoModel *videomodel = self.dataSource[commentButton.tag - 100];
    comment.videomodel = videomodel;
    comment.user_id = videomodel.idString;
    
    [[self.scrollViewController navigationController]pushViewController:comment animated:YES];
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.dataSource.count == 0) {
        return 502;
    }

    return 380;

}

- (void)handleAvatarAction:(UITapGestureRecognizer *)sender{
    PictureDetailTableViewController *detailVC = [[[PictureDetailTableViewController alloc] init] autorelease];
    UIImageView *imagevi = (UIImageView *)sender.view;
    VideoModel *model = [self.dataSource objectAtIndex:imagevi.tag - 200];
    
    detailVC.hidesBottomBarWhenPushed = YES;
    detailVC.nameuser = model.name;
    detailVC.userid = model.user_id;
    [[self.scrollViewController navigationController] pushViewController:detailVC animated:YES];

}


- (void)handlePlayVideoAction:(UIButton *)sender {
    PlayVideoViewController *playView = [[[PlayVideoViewController alloc] init] autorelease];
    VideoModel *model = self.dataSource[sender.tag - 111];
    playView.PalyURl = model.videouri;
    [[self.scrollViewController navigationController] pushViewController:playView animated:YES];

    
}

//合适时机刷新数据
- (void)setupRefresh
{
    // 1.下拉刷新(进入刷新状态就会调用self的headerRereshing)
    [self.tableView addHeaderWithTarget:self action:@selector(headerRereshing)];
    
    [self.tableView headerBeginRefreshing];
    
    // 2.上拉加载更多(进入刷新状态就会调用self的footerRereshing)
    [self.tableView addFooterWithTarget:self action:@selector(footerRereshing)];
    
    // 设置文字(也可以不设置,默认的文字在MJRefreshConst中修改)
    self.tableView.headerPullToRefreshText = @"✨✨✨下拉可以刷新了✨✨✨";
    self.tableView.headerReleaseToRefreshText = @"✨✨松开马上刷新了✨✨";
    self.tableView.headerRefreshingText = @"✨正✨在✨刷✨新✨中✨";
    
    self.tableView.footerPullToRefreshText = @"上拉可以加载更多数据了✨";
    self.tableView.footerReleaseToRefreshText = @"松开马上加载更多数据了✨";
    self.tableView.footerRefreshingText = @"✨正✨在✨帮✨你✨加✨载✨中✨";
}


//合适时机刷新数据
- (void)headerRereshing
{
    // 1.添加数据
    QiushiRequestManager *manager = [[QiushiRequestManager alloc] init];
    manager.delegate = self;
    manager.destinationURLString = kVideoBestUrl;
    [manager startRequest];
    
    
    
    
    
    // 2.2秒后刷新表格UI(此处直接用,不用修改)
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        // 刷新表格
        [self.tableView reloadData];
        
        // (最好在刷新表格后调用)调用endRefreshing可以结束刷新状态
        [self.tableView headerEndRefreshing];
    });
}

- (void)footerRereshing
{
    
    QiushiRequestManager *manager = [[QiushiRequestManager alloc] init];
    manager.delegate = self;
    _count += 1;
    manager.destinationURLString = [NSString stringWithFormat:@"http://api.budejie.com/api/api_open.php?a=newlist&appname=baisibudejie&asid=8FE33EB2-39D7-4572-8D44-8F7DC91FFB0C&c=video&jbk=0&market=&openudid=8d759955a0af863ed9510d782ff53bb62cd0a126&page=%ld&per=20&type=41&udid=&ver=3.0", _count];
    [manager startRequest];
    
    // 2.2秒后刷新表格UI(此处直接用,不用修改)
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        // 刷新表格
        [self.tableView reloadData];
        
        // (最好在刷新表格后调用)调用endRefreshing可以结束刷新状态
        [self.tableView footerEndRefreshing];
        _count += 1;
    });
}








/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/



@end
