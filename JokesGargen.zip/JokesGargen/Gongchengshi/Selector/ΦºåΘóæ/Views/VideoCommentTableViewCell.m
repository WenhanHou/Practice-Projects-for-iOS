//
//  VideoCommentTableViewCell.m
//  Gongchengshi
//
//  Created by dqb on 14-11-5.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "VideoCommentTableViewCell.h"
#import "UIImageView+WebCache.h"

@implementation VideoCommentTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code

    }
    return self;
}

- (void)awakeFromNib
{
    // Initialization code
}

- (UIImageView *)profile_image{
    if (!_profile_image) {
        self.profile_image = [[[UIImageView alloc] initWithFrame:CGRectMake(10, 10, 40, 40)] autorelease];
        self.profile_image.userInteractionEnabled = YES;
        [self addSubview:_profile_image];
    }
    return _profile_image;
}
- (UILabel *)userName{
    
    if (!_userName) {
        self.userName = [[[UILabel alloc] initWithFrame:CGRectMake(60, 15, 150, 30)] autorelease];
        self.userName.font = [UIFont systemFontOfSize:13];
        self.userName.backgroundColor = [UIColor clearColor];
        _userName.adjustsFontSizeToFitWidth = YES;
        self.userName.textColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_userName]; 
    }
    return _userName;
}

- (UILabel *)text{
    
    if (!_text) {
        self.text = [[[UILabel alloc] initWithFrame:CGRectMake(20, 60 , 280, 60)] autorelease];
        _text.font = [UIFont systemFontOfSize:15];
        _text.adjustsFontSizeToFitWidth = YES;
        _text.numberOfLines = 0;
        [self.contentView addSubview:_text];
    }
    return _text;
}

- (UIButton *)favorite{
    
    if (!_favorite) {
        self.favorite = [UIButton buttonWithType:UIButtonTypeCustom];
        self.favorite.frame = CGRectMake(260, 18, 25, 25);
        [_favorite setImage:[UIImage imageNamed:@"ding_black.png"] forState:UIControlStateNormal];
        [self.contentView addSubview:_favorite];
        
    }
    return _favorite;
}

- (UILabel *)favoriteLabel{
    
    if (!_favorite) {
        self.favoriteLabel = [[[UILabel alloc] initWithFrame:CGRectMake(290, 20, 20, 20)] autorelease];
        
        [self.contentView addSubview:_favoriteLabel];
    }
    return _favoriteLabel;
}


- (void)setCommentContentWithModel:(CommentModels *)commentModel{
    [self.profile_image sd_setImageWithURL:[NSURL URLWithString:commentModel.model.profile_image]];
    self.userName.text = commentModel.model.userName;
    self.text.text = commentModel.text;
    self.favoriteLabel.text = commentModel.favoriteCount;
    self.text.frame = CGRectMake(20, 60, 280, commentModel.contentSize.height);
    commentModel.finalHeight = commentModel.contentSize.height + 70;
    
    
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
