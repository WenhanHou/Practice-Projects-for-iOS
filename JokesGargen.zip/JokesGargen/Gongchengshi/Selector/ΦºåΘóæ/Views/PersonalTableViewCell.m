//
//  PersonalTableViewCell.m
//  Gongchengshi
//
//  Created by dqb on 14-11-4.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "PersonalTableViewCell.h"
#import "UIImageView+WebCache.h"

@implementation PersonalTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (MPMoviePlayerViewController *)playerVC{
    if (!_playerVC) {
        self.playerVC = [[[MPMoviePlayerViewController alloc] init] autorelease];
        _playerVC.view.frame = CGRectMake(10, 130, 300, 200);
        
        [self addSubview:_playerVC.view];
    }
    return _playerVC;
    
}

- (UIImageView *)image0{
    if (!_image0) {
        self.image0 = [[[UIImageView alloc] initWithFrame:CGRectMake(10, 130, 300, 200)] autorelease];
        _image0.backgroundColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_image0];
    }
    return _image0;
    
}

- (UILabel *)Label{
    if (!_Label) {
        self.Label = [[[UILabel alloc] initWithFrame:CGRectMake(10, 70, 300, 50)] autorelease];
        _Label.textAlignment = NSTextAlignmentLeft;
        _Label.adjustsFontSizeToFitWidth = YES;
        _Label.numberOfLines = 0;
        _Label.font = [UIFont systemFontOfSize:15];
        
        [self.contentView addSubview:_Label];
    }
    return _Label;
}

- (UIImageView *)userAvatar{
    if (!_userAvatar) {
        self.userAvatar = [[[UIImageView alloc]initWithFrame:CGRectMake(10, 5, 50, 50)] autorelease];
        [self.contentView addSubview:_userAvatar];
        
    }
    return _userAvatar;
}

- (UILabel *)timeLabel{
    if (!_timeLabel) {
        self.timeLabel = [[[UILabel alloc]initWithFrame:CGRectMake(70, 32, 200, 30)] autorelease];
        _timeLabel.textAlignment = NSTextAlignmentLeft;
        _timeLabel.adjustsFontSizeToFitWidth = YES;
        [self.contentView addSubview:_timeLabel];
    }
    return _timeLabel;
}

- (UILabel *)nameLabel{
    if (!_nameLabel) {
        self.nameLabel = [[[UILabel alloc] initWithFrame:CGRectMake(70, 5, 150, 30)] autorelease];
        _nameLabel.textAlignment = NSTextAlignmentLeft;
        _nameLabel.adjustsFontSizeToFitWidth = YES;
        [self.contentView addSubview:_nameLabel];
    }
    return _nameLabel;
}

- (UIButton *)loveButton{
    if (!_loveButton) {
        self.loveButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _loveButton.frame = CGRectMake(20, 340, 30, 30);
        [self.contentView addSubview:_loveButton];
        
    }
    return _loveButton;
}

- (UILabel *)loveLabel{
    if (!_loveLabel) {
        self.loveLabel = [[[UILabel alloc]initWithFrame:CGRectMake(52, 340, 30, 30)]autorelease];
        _loveLabel.textAlignment = NSTextAlignmentLeft;
        _loveLabel.font = [UIFont systemFontOfSize:13];
        [self.contentView addSubview:_loveLabel];
    }
    return _loveLabel;
    
}

- (UIButton *)hateButton{
    if (!_hateButton) {
        self.hateButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _hateButton.frame = CGRectMake(82, 340, 30, 30);
        [self.contentView addSubview:_hateButton];
    }
    return _hateButton;
}

- (UILabel *)hateLabel{
    if (!_hateLabel) {
        self.hateLabel = [[[UILabel alloc] initWithFrame:CGRectMake(114, 340, 30, 30)] autorelease];
        _hateLabel.textAlignment = NSTextAlignmentLeft;
        _hateLabel.font = [UIFont systemFontOfSize:13];
        [self.contentView addSubview:_hateLabel];
    }
    return _hateLabel;
}

- (UIButton *)forwardButton{
    if (!_forwardButton) {
        self.forwardButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _forwardButton.frame = CGRectMake(194, 340, 30, 30);
        [self.contentView addSubview:_forwardButton];
    }
    return _forwardButton;
}

- (UILabel *)forwardLabel{
    if (!_forwardLabel) {
        self.forwardLabel = [[[UILabel alloc] initWithFrame:CGRectMake(226, 340,30, 30)] autorelease];
        _forwardLabel.textAlignment = NSTextAlignmentLeft;
        _forwardLabel.font = [UIFont systemFontOfSize:13];
        [self.contentView addSubview:_forwardLabel];
    }
    return _forwardLabel;
}

- (UIButton *)commentButton{
    if (!_commentButton) {
        self.commentButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _commentButton.frame = CGRectMake(248, 340, 30, 30);
        [self.contentView addSubview:_commentButton];
    }
    return _commentButton;
}

- (UILabel *)commentLabel{
    if (!_commentLabel) {
        self.commentLabel = [[[UILabel alloc]initWithFrame:CGRectMake(280, 340, 30, 30)]autorelease];
        _commentLabel.textAlignment = NSTextAlignmentLeft;
        _commentLabel.font = [UIFont systemFontOfSize:13];
        [self.contentView addSubview:_commentLabel];
    }
    return _commentLabel;
}

- (UILabel *)playcountLabel{
    if (!_playcountLabel) {
        self.playcountLabel = [[[UILabel alloc] initWithFrame:CGRectMake(0, 0, 100, 30)] autorelease];
        _playcountLabel.font = [UIFont systemFontOfSize:13];
        _playcountLabel.textAlignment = NSTextAlignmentLeft;
        _playcountLabel.textColor = [UIColor whiteColor];
        [_image0 addSubview:_playcountLabel];
    }
    return _playcountLabel;
}

- (UIButton *)playButton{
    if (!_playButton) {
        self.playButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _playButton.frame = CGRectMake(self.image0.center.x - 20, self.image0.center.y - 20, 40, 40);
        [_playButton setImage:[UIImage imageNamed:@"details_big_play.png"] forState:UIControlStateNormal];
        [self addSubview:_playButton];
    }
    return _playButton;
    
}

- (UIImageView *)thisTieziImage{
    if (!_thisTieziImage) {
        self.thisTieziImage = [[[UIImageView alloc] init] autorelease];
        _thisTieziImage.frame = CGRectMake(10, 120, 300, 250);
        //        _thisTieziImage.backgroundColor = [UIColor brownColor];
        _thisTieziImage.userInteractionEnabled = YES;
        [self addSubview:_thisTieziImage];
    }
    return _thisTieziImage;
}


- (void)configurePlayerButton{
    
    self.voiceButton = [[[AudioButton alloc] initWithFrame:CGRectMake(0, 200, 50, 50)] autorelease];
    //    _voiceButton.backgroundColor = [UIColor purpleColor];
    [self.thisTieziImage addSubview:self.voiceButton];
    
    
}



- (void)dealloc{
    [_Label release];
    [_image0 release];
    [_userAvatar release];
    [_timeLabel release];
    [_nameLabel release];
    [_loveButton release];
    [_loveLabel release];
    [_hateLabel release];
    [_hateButton release];
    [_forwardLabel release];
    [_forwardButton release];
    [_commentButton release];
    [_commentLabel release];
    [_playcountLabel release];
    [_playButton release];
    [super dealloc];
}

- (void)setContentForCellWithItemModel:(personalModel *)itemModel{
    
    self.nameLabel.text = itemModel.name;
    NSLog(@"%@", itemModel.name);
    [self.userAvatar sd_setImageWithURL:[NSURL URLWithString:itemModel.profile_image] placeholderImage:[UIImage imageNamed:@"ding_back.png"]];
    self.timeLabel.text = itemModel.created_at;
    [self.userAvatar sd_setImageWithURL:[NSURL URLWithString:itemModel.profile_image] placeholderImage:[UIImage imageNamed:@"aliAvatar"]];
    self.nameLabel.text = itemModel.name;
    self.timeLabel.text = itemModel.created_at;
    self.Label.text = itemModel.text;
    [self.loveButton setImage:[UIImage imageNamed:@"ding_red.png"] forState:UIControlStateNormal];
    self.loveLabel.text = itemModel.love;
    [self.hateButton setImage:[UIImage imageNamed:@"cai_red.png"] forState:UIControlStateNormal];
    self.hateLabel.text = itemModel.hate;
    [self.forwardButton setImage:[UIImage imageNamed:@"mainCellShareClick.png"] forState:UIControlStateNormal];
    self.forwardLabel.text = itemModel.forward;
    [self.commentButton setImage:[UIImage imageNamed:@"pinglun.png"] forState:UIControlStateNormal];
    self.commentLabel.text = itemModel.comment;
    self.playcountLabel.text = [NSString stringWithFormat:@"%@次播放",itemModel.playcount];

}




- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
