//
//  VideoCommentTableViewCell.h
//  Gongchengshi
//
//  Created by dqb on 14-11-5.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CommentModels.h"

@interface VideoCommentTableViewCell : UITableViewCell
@property(nonatomic, retain)UIImageView *profile_image; // 用户头像
@property(nonatomic, retain)UILabel *userName; // 用户
@property(nonatomic, retain)UILabel *text; // 文本
@property(nonatomic, retain)UIButton *favorite;// 赞
@property(nonatomic, retain)UILabel *favoriteLabel;


- (void)setCommentContentWithModel:(CommentModels *)commentModel;
@end
