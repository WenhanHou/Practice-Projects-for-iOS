//
//  HeaderViewController.m
//  Gongchengshi
//
//  Created by dqb on 14-11-5.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "HeaderViewController.h"
#import "Micro.h"

@interface HeaderViewController ()

@end

@implementation HeaderViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        [self.view addSubview:_hView];

    }
    return self;
}
- (UIImageView *)backGround{
    if (!_backGround) {
        self.backGround = [[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 180)] autorelease];
        [self.hView addSubview:_backGround];
    }
    return _backGround;
}


- (UIImageView *)AvatarView{
    if (!_AvatarView) {
        self.AvatarView = [[[UIImageView alloc]initWithFrame:CGRectMake(20, 120, 80, 80)] autorelease];
        _AvatarView.layer.cornerRadius = 40;
        _AvatarView.layer.borderWidth = 2;
        _AvatarView.layer.masksToBounds = YES;
        _AvatarView.layer.borderColor = [UIColor(256, 256, 256) CGColor];
        [self.hView addSubview:_AvatarView];
    }
    return _AvatarView;
}


- (UILabel *)praiselabel{
    if (!_praiselabel) {
        
    
    self.praiselabel = [[[UILabel alloc] initWithFrame:CGRectMake(260, 55, 50, 20)] autorelease];
    _praiselabel.textColor = [UIColor lightGrayColor];
    _praiselabel.textAlignment = NSTextAlignmentLeft;
    _praiselabel.font = [UIFont systemFontOfSize:15];
    [self.hView addSubview:_praiselabel];
    }
    return _praiselabel;
}

- (UIButton *)praisebutton{
    if (!_praisebutton) {
        self.praisebutton = [UIButton buttonWithType:UIButtonTypeCustom];
        _praisebutton.frame = CGRectMake(230, 55, 20, 20);
        [self.hView addSubview:_praisebutton];
    }
    return _praisebutton;
}

- (UILabel *)introLabel{
    if (!_introLabel) {
    self.introLabel = [[[UILabel alloc] initWithFrame:CGRectMake(10, 220, 300, 30)] autorelease];
    _introLabel.adjustsFontSizeToFitWidth = YES;
    _introLabel.textColor = [UIColor darkGrayColor];
        [self.hView addSubview:_introLabel];
    }
    return _introLabel;
}

- (UILabel *)nameLabel{
    if (!_nameLabel) {
        self.nameLabel = [[[UILabel alloc] initWithFrame:CGRectMake(10, 200, 180, 20)] autorelease];
        _nameLabel.adjustsFontSizeToFitWidth = YES;
        _nameLabel.textColor = [UIColor lightGrayColor];
        [self.hView addSubview:_nameLabel];
    }
    return _nameLabel;
}

- (UIView *)hView{
    if (!_hView) {
        self.hView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 300)] autorelease];
//        _hView.backgroundColor = [UIColor whiteColor];
    }
    return _hView;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
