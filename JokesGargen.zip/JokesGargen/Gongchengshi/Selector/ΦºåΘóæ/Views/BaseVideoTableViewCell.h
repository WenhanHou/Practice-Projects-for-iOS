//
//  BaseVideoTableViewCell.h
//  Gongchengshi
//
//  Created by dqb on 14-10-28.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>

#import "VideoModel.h"
#import "personalModel.h"

@interface BaseVideoTableViewCell : UITableViewCell
@property (nonatomic, retain) UIImageView *image0;
@property (nonatomic, retain) UILabel *Label;//视频上方文字
@property (nonatomic, retain) UIImageView *userAvatar;
@property (nonatomic, retain) UILabel *timeLabel;
@property (nonatomic, retain) UILabel *nameLabel;
@property (nonatomic, retain) UIButton *loveButton;
@property (nonatomic, retain) UILabel *loveLabel;
@property (nonatomic, retain) UIButton *hateButton;
@property (nonatomic, retain) UILabel *hateLabel;
@property (nonatomic, retain) UIButton *forwardButton;//分享按钮
@property (nonatomic, retain) UILabel *forwardLabel;
@property (nonatomic, retain) UIButton *commentButton;//评论按钮
@property (nonatomic, retain) UILabel *commentLabel;
@property (nonatomic, retain) UILabel *playcountLabel;//播放次数
@property (nonatomic, retain) UIButton *playButton;//播放按钮
@property (nonatomic, retain) MPMoviePlayerViewController *playerVC;


- (void)setVideoContentForCellWithItemModel:(VideoModel *)itemModel;
@end
