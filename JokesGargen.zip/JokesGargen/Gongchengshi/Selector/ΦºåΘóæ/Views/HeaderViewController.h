//
//  HeaderViewController.h
//  Gongchengshi
//
//  Created by dqb on 14-11-5.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HeaderViewController : UIViewController
@property(nonatomic, retain) UIView *hView;
@property(nonatomic, retain) UIImageView *AvatarView;
@property(nonatomic, retain) UIImageView *backGround;
@property(nonatomic, retain) UILabel *praiselabel;
@property(nonatomic, retain) UIButton *praisebutton;
@property(nonatomic, retain) UILabel *nameLabel;
@property(nonatomic, retain) UILabel *introLabel;
@end
