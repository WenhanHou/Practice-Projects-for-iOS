//
//  QiushiRequestManager.m
//  QiuShiBaikeClient
//
//  Created by dqb on 14-10-13.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "QiushiRequestManager.h"

//网络请求一般用异步协议请求

@interface QiushiRequestManager ()<NSURLConnectionDataDelegate>
@property(nonatomic, retain) NSMutableData *receivedData;//用于暂存下载到得数据

- (void)_cleanCachedData;//清空暂存的数据

- (NSArray *)_packageParamsToArray;//将参数打包成数组
- (NSData *)_postBodyFormParamsArray;//将参数数组再转成post请求参数


@end

@implementation QiushiRequestManager


+ (id)sharedManager{
    static id manager = nil;
    if (manager == nil) {
        manager = [[[self class]alloc]init];
    }
    return manager;
}



- (NSMutableData *)receivedData{
    if (!_receivedData) {
        self.receivedData = [NSMutableData data];
    }
    return _receivedData;
}

- (NSMutableDictionary *)paramsDictionary{
    if (!_paramsDictionary) {
        self.paramsDictionary = [NSMutableDictionary dictionary];
    }
    return _paramsDictionary;
}


- (void)dealloc{
    [_receivedData release];
    [_paramsDictionary release];
    [_destinationURLString release];
    [super dealloc];
}


- (void)_cleanCachedData{
    [self.receivedData setData:nil];
    [self.paramsDictionary removeAllObjects];
    
    
}


- (void)startRequest{
    NSURL *url = [NSURL URLWithString:self.destinationURLString];
    //可变request请求
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    //判断如果字典的键值对个数不为零说明为post请求,否则为get请求
    if (self.paramsDictionary.count != 0) {
        [request setHTTPMethod:@"POST"];
        //设置请求参数
        [request setHTTPBody:[self _postBodyFormParamsArray]];
        
    }
    [NSURLConnection connectionWithRequest:request delegate:self];
}

- (NSArray *)_packageParamsToArray{
    NSMutableArray *params = [NSMutableArray array];
    for (NSString *key in self.paramsDictionary) {
        NSString *oneParam = [NSString stringWithFormat:@"%@=%@", key, self.paramsDictionary[key]];
        [params addObject:oneParam];
    }
    return params;
}

- (NSData *)_postBodyFormParamsArray{
    NSArray *params = [self _packageParamsToArray];
    NSString *postString = [params componentsJoinedByString:@"&"];
    NSLog(@"%@", postString);
    return [postString dataUsingEncoding:NSUTF8StringEncoding];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    [self.receivedData appendData:data];
}


- (void)connectionDidFinishLoading:(NSURLConnection *)connection{
    //完成下载
    if (self.delegate && [self.delegate respondsToSelector:@selector(request:didFinishLoadingWithData:)]) {
        [self.delegate request:self didFinishLoadingWithData:self.receivedData];
    }
    [self _cleanCachedData];
    
}



- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    
    //下载失败
    if (self.delegate && [self.delegate respondsToSelector:@selector(request:didFaildWithError:)]) {
        [self.delegate request:self didFaildWithError:error];
    }
    [self _cleanCachedData];
    
    
}

@end
