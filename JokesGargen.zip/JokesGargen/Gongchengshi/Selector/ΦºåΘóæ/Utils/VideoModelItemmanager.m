//
//  VideoModelItemmanager.m
//  Gongchengshi
//
//  Created by dqb on 14-10-28.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "VideoModelItemmanager.h"
#import "QiushiRequestManager.h"

@interface VideoModelItemmanager ()<QiushiRequestManagerDelegate>
@property(nonatomic, retain) NSMutableArray *itemModels;//可变数组,用于暂存网络请求数据
@property(nonatomic, assign) NSInteger currentPage;//当前的请求页码对应的网络请求的参数page = 1...
@property(nonatomic, assign) VideoModelItemmanagerModelType currentType;

//- (void)_cleanCachedData;//清空已有数据


@end

@implementation VideoModelItemmanager

+ (id)sharedManager{
    static id manager = nil;
    if (manager == nil) {
        manager = [[[self class] alloc] init];
    }
    return manager;
}

- (void)dealloc{
    [_itemModels release];
    [super dealloc];
}

- (NSMutableArray *)itemModels{
    if (!_itemModels) {
        self.itemModels = [NSMutableArray array];
    }
    return _itemModels;

}
- (id)init{
    if (self = [super init]) {
        self.currentPage = 1;//设置初始值
    }
    return self;
}


//- (void)_cleanCachedData{
//    [self.itemModels removeAllObjects];
//    self.currentPage = 1;
//}


- (void)acquireData{
//    switch (self.currentType) {
//        case VideoModelItemmanagerModelTypeRefreshData:
//            self.currentPage = 1;
//            
//            break;
//        case VideoModelItemmanagerModelTypeMoreData:
//            self.currentPage += 1;//要下载下一页数据
//            
//            
//        default:
//            break;
//    }
    
    QiushiRequestManager *requestManager = [QiushiRequestManager sharedManager];
    //设置
//    requestManager.destinationURLString = [NSString stringWithFormat:@"http://api.budejie.com/api/api_open.php?a=list&appname=baisibudejie&c=video&jbk=0&page=%ld&per=20&type=41&udid=&ver=3.0",self.currentPage];
    requestManager.destinationURLString = @"http://api.budejie.com/api/api_open.php?a=list&appname=baisibudejie&asid=8FE33EB2-39D7-4572-8D44-8F7DC91FFB0C&c=video&client=iphone&device=ios%20%E8%AE%BE%E5%A4%87&from=ios&jbk=0&mac=02%3A00%3A00%3A00%3A00%3A00&market=&openudid=8d759955a0af863ed9510d782ff53bb62cd0a126&page=0&per=20&type=41&udid=&ver=3.0";
    
    //设置代理
    requestManager.delegate = self;
    //开始请求网络数据
    [requestManager startRequest];
    
    
    
}

- (void)setDataType:(VideoModelItemmanagerModelType)type{
    self.currentType = type;
}



- (NSInteger)numberOfVideoItem{
    return self.itemModels.count;
    
}


- (VideoModel *)videoModelItemAtIndexPath:(NSIndexPath *)indexPath{
    VideoModel *model = [self.itemModels objectAtIndex:indexPath.row];
    NSLog(@"--------++++------%@========%ld",self.itemModels,(long)indexPath.row);
    return model;
    
}


- (void)request:(QiushiRequestManager *)request didFaildWithError:(NSError *)error{
    NSLog(@"%@", error);
    
    
}


- (void)request:(QiushiRequestManager *)request didFinishLoadingWithData:(NSData *)data{
//    if (self.currentType == VideoModelItemmanagerModelTypeRefreshData) {
//        //如果是刷新,则需要在保存下载到的数据之前先清空数组已有的数据
//        [self _cleanCachedData];
//    }
    NSLog(@"%@", [[[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding] autorelease]);
    //得到的数据需要解析
    NSDictionary *jsonDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    NSArray *itemsArray = [jsonDic objectForKey:@"list"];
    //通过快速遍历数组,将数组对象封装成model对象保存
    for (NSDictionary *dict in itemsArray) {
        VideoModel *itemModel = [VideoModel modelWithDictionary:dict];
        [self.itemModels addObject:itemModel];
        
    }
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(acquireDateSuccess)]) {
        [self.delegate acquireDateSuccess];
        
    }
    
}




@end
