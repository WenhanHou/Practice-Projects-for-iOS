//
//  QiushiRequestManager.h
//  QiuShiBaikeClient
//
//  Created by dqb on 14-10-13.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "QiushiBaseManager.h"

@class QiushiRequestManager;

@protocol QiushiRequestManagerDelegate <NSObject>

- (void)request:(QiushiRequestManager *)request didFinishLoadingWithData:(NSData *)data;
- (void)request:(QiushiRequestManager *)request didFaildWithError:(NSError *)error;

@end

//用于下载的类

@interface QiushiRequestManager : QiushiBaseManager

@property(nonatomic, retain) NSMutableDictionary *paramsDictionary;//请求的参数字典

@property(nonatomic, retain) NSString *destinationURLString;//目标地址
@property(nonatomic, assign) id<QiushiRequestManagerDelegate>delegate;

- (void)startRequest;//开始请求数据

@end
