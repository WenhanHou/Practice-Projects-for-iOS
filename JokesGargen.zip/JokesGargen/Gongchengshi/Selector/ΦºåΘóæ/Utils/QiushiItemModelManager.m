//
//  QiushiItemModelManager.m
//  QiuShiBaikeClient
//
//  Created by dqb on 14-10-13.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "QiushiItemModelManager.h"
#import "QiushiRequestManager.h"

@interface QiushiItemModelManager ()<QiushiRequestManagerDelegate>

@property(nonatomic, retain) NSMutableArray *itemModels;//可变数组,用于暂存网络请求数据
@property(nonatomic, assign) NSInteger currentPage;//当前的请求页码对应的网络请求的参数page = 1...

@property(nonatomic, assign) QiushiItemModelManagerModelType currentType;

- (void)_cleanCachedData;//清空已有数据

@end

@implementation QiushiItemModelManager


+ (id)sharedManager{
    static id manager = nil;
    if (manager == nil) {
        manager = [[[self class]alloc]init];
    }
    return manager;
}

- (void)dealloc{
    [_itemModels release];
    [super dealloc];
}




- (NSMutableArray *)itemModels{
    if (!_itemModels) {
        self.itemModels = [NSMutableArray array];
    }
    return _itemModels;
}

- (id)init{
    if (self = [super init]) {
        self.currentPage = 0;//设置初始值
    }
    return self;
}


- (void)_cleanCachedData{
    [self.itemModels removeAllObjects];
    self.currentPage = 1;
}

- (void)acquireData{
    switch (self.currentType) {
        case QiushiItemModelManagerModelTypeRefreshData:
            self.currentPage = 1;
            
            break;
            case QiushiItemModelManagerModelTypeMoreData:
            self.currentPage += 1;//要下载下一页数据
            
            
        default:
            break;
    }
    
    QiushiRequestManager *requestManager = [QiushiRequestManager sharedManager];
    //设置
    requestManager.destinationURLString = [NSString stringWithFormat:@"http://api.budejie.com/api/api_open.php?a=list&c=data&page=%ld&per=20&type=10",self.currentPage];
//    requestManager.paramsDictionary[@"count"] = @"30";
//    requestManager.paramsDictionary[@"page"]= [NSString stringWithFormat:@"%ld", self.currentPage];
    //设置代理
    requestManager.delegate = self;
    //开始请求网络数据
    [requestManager startRequest];
                                    
                                    
    
}


- (void)setDataType:(QiushiItemModelManagerModelType)type{
    self.currentType = type;
}



- (NSUInteger)numberOfQiushiItem{
    return self.itemModels.count;
    
}


- (jinghuaModels *)qiushiItemModelAtIndexPath:(NSIndexPath *)indexPath{
    
    return self.itemModels[indexPath.row];
    
}


- (void)request:(QiushiRequestManager *)request didFaildWithError:(NSError *)error{
    NSLog(@"%@", error);
    
    
}


- (void)request:(QiushiRequestManager *)request didFinishLoadingWithData:(NSData *)data{
    if (self.currentType == QiushiItemModelManagerModelTypeRefreshData) {
        //如果是刷新,则需要在保存下载到的数据之前先清空数组已有的数据
        [self _cleanCachedData];
    }
    NSLog(@"%@", [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding]);
    //得到的数据需要解析
    NSDictionary *jsonDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    NSArray *itemsArray = [jsonDic objectForKey:@"items"];
    //通过快速遍历数组,将数组对象封装成model对象保存
    for (NSDictionary *dict in itemsArray) {
        jinghuaModels *itemModel = [jinghuaModels modelWithDictionary:dict];
        [self.itemModels addObject:itemModel];
    }
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(acquireDataSuccess)]) {
        [self.delegate acquireDataSuccess];
        
    }
    
}










@end
