//
//  QiushiBaseManager.h
//  QiuShiBaikeClient
//
//  Created by dqb on 14-10-13.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QiushiBaseManager : NSObject

+ (id)sharedManager;

@end
