//
//  VideoModelItemmanager.h
//  Gongchengshi
//
//  Created by dqb on 14-10-28.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "QiushiBaseManager.h"
#import "VideoModel.h"

typedef enum {
    VideoModelItemmanagerModelTypeRefreshData,
    VideoModelItemmanagerModelTypeMoreData
    
}VideoModelItemmanagerModelType;

@protocol VideoModelItemManagerDelegate <NSObject>

- (void)acquireDateSuccess;

@end

@interface VideoModelItemmanager : QiushiBaseManager

@property(nonatomic, assign) id<VideoModelItemManagerDelegate>delegate;
- (NSInteger)numberOfVideoItem;

- (VideoModel *)videoModelItemAtIndexPath:(NSIndexPath *)indexPath;

- (void)setDataType:(VideoModelItemmanagerModelType)type;
- (void)acquireData;


@end
