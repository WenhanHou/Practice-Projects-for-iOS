//
//  QiushiItemModelManager.h
//  QiuShiBaikeClient
//
//  Created by dqb on 14-10-13.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "QiushiBaseManager.h"
#import "jinghuaModels.h"
typedef enum {
    QiushiItemModelManagerModelTypeRefreshData,//最新数据
    QiushiItemModelManagerModelTypeMoreData//更多数据
    
    
}QiushiItemModelManagerModelType;

@protocol QiushiItemModelManagerDelegate <NSObject>

- (void)acquireDataSuccess;//数据准备完成

@end

@interface QiushiItemModelManager : QiushiBaseManager

//返回当前所拥有的糗事条数
- (NSUInteger)numberOfQiushiItem;
//根据给定的行号返回对相应的糗事模型对象
- (jinghuaModels *)qiushiItemModelAtIndexPath:(NSIndexPath *)indexPath;

@property(nonatomic, assign) id<QiushiItemModelManagerDelegate>delegate;

//设置所需的数据的类型
- (void)setDataType:(QiushiItemModelManagerModelType)type;

- (void)acquireData;//让这个管理类准备数据(管理类会让网络请求类下载对应的数据)



@end
