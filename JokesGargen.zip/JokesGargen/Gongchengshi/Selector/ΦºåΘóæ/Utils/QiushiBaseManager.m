//
//  QiushiBaseManager.m
//  QiuShiBaikeClient
//
//  Created by dqb on 14-10-13.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "QiushiBaseManager.h"

@implementation QiushiBaseManager

+ (id)sharedManager{
    static id manager = nil;
    if (manager == nil) {
        manager = [[[self class]alloc]init];
    }
    return manager;
}

@end
