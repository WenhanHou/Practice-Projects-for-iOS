//
//  PictureDetailTableViewController.h
//  Gongchengshi
//
//  Created by lanouhn on 14-10-29.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseTableViewController.h"
#import <AVFoundation/AVFoundation.h>
@class AudioPlayer;

@interface PictureDetailTableViewController : BaseTableViewController<AVAudioPlayerDelegate>

@property(nonatomic, retain) UILabel *label;
@property(nonatomic, retain) NSString *userid;
@property(nonatomic, retain) NSString *nameuser;
@property(nonatomic, retain) AudioPlayer *audioplayer;

+ (id)sharedVoicePlay;

@end
