//
//  PlayVideoViewController.h
//  Gongchengshi
//
//  Created by dqb on 14-11-3.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlayVideoViewController : UIViewController

@property(nonatomic, retain) NSString *PalyURl;

@end
