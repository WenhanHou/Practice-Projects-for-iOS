//
//  VideoCommentTableViewController.h
//  Gongchengshi
//
//  Created by dqb on 14-11-5.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VideoModel.h"

@interface VideoCommentTableViewController : UITableViewController
@property(nonatomic, retain) VideoModel *videomodel;
@property (nonatomic, retain)NSString *user_id;

@end
