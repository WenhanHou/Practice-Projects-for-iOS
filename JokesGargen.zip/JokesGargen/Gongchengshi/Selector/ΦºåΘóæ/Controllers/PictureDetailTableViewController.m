//
//  PictureDetailTableViewController.m
//  Gongchengshi
//
//  Created by lanouhn on 14-10-29.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "PictureDetailTableViewController.h"
#import "PictureDetailTableViewCell.h"
#import "BaseVideoTableViewCell.h"
#import "QiushiRequestManager.h"
#import "UIImageView+WebCache.h"
#import "Micro.h"
#import "PlayVideoViewController.h"
#import "CommentItemmModel.h"
#import "GCSBaseModel.h"
#import "GCSBaseViewCell.h"
#import "PersonalTableViewCell.h"
#import "AudioPlayer.h"
#import "AudioButton.h"
#import "HeaderViewController.h"

@interface PictureDetailTableViewController ()<QiushiRequestManagerDelegate,UITableViewDelegate, UIAlertViewDelegate>

@property(nonatomic, retain) NSMutableArray *dataSource;
@property(nonatomic, retain) NSDictionary *datadic;
@property(nonatomic, retain) NSMutableArray *dataArray;
@property(nonatomic, retain) HeaderViewController *headerview;
@property(nonatomic, retain) NSString *tiezi;
@property(nonatomic, retain) NSString *comment;
@property(nonatomic, retain) UISegmentedControl *segment;

- (void)requestSource;
- (void)_loadingCommentData:(UISegmentedControl *)segment;

@end

@implementation PictureDetailTableViewController

+ (id)sharedVoicePlay{
    static id voicePlay;
    if (voicePlay == nil) {
        voicePlay = [[[self class] alloc] init];
    }
    return voicePlay;
}


- (NSMutableArray *)dataArray{
    if (!_dataArray) {
        self.dataArray = [NSMutableArray array];
    }
    return _dataArray;
}

- (NSMutableArray *)dataSource{
    if (!_dataSource) {
        self.dataSource = [NSMutableArray array];
    }
    return _dataSource;
}

- (NSDictionary *)datadic{
    if (!_datadic) {
        self.datadic = [NSDictionary dictionary];
    }
    return _datadic;
}



- (HeaderViewController *)headerview{
    if (!_headerview) {
        self.headerview = [[[HeaderViewController alloc] init] autorelease];
           }
    return _headerview;
}

- (void)dealloc{
    [_dataSource release];
    [_datadic release];
    [_dataArray release];
    [super dealloc];
}


- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
        
    }
    return self;
}

- (void)requestSource{
    QiushiRequestManager *request1 = [[[QiushiRequestManager alloc] init] autorelease];
    request1.destinationURLString = [NSString stringWithFormat:@"http://api.budejie.com/api/api_open.php?a=profile&appname=baisibudejie&asid=8FE33EB2-39D7-4572-8D44-8F7DC91FFB0C&c=user&client=iphone&market=&openudid=8d759955a0af863ed9510d782ff53bb62cd0a126&udid=&userid=%@&ver=3.0",self.userid];
    request1.delegate = self;
    [request1 startRequest];
    
    NSLog(@"%@555555555555555555-------------.",self.userid);
    QiushiRequestManager *request2 = [[[QiushiRequestManager alloc] init] autorelease];
    request2.destinationURLString = [NSString stringWithFormat:@"http://api.budejie.com/api/api_open.php?a=mytopic&appname=baisibudejie&asid=8FE33EB2-39D7-4572-8D44-8F7DC91FFB0C&c=topic&openudid=8d759955a0af863ed9510d782ff53bb62cd0a126&order_type=desc&type=1&udid=&uid=0&ver=3.0&visit_uid=%@",self.userid];

    request2.delegate = self;
    [request2 startRequest];
}


- (void)viewDidLoad
{
    [super viewDidLoad];


    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    self.headerview.view.frame = CGRectMake(0, 0, 320, 300);
    self.tableView.tableHeaderView = self.headerview.hView;

    [self.tableView registerClass:[PersonalTableViewCell class] forCellReuseIdentifier:@"cell"];
    [self.tableView registerClass:[PictureDetailTableViewCell class] forCellReuseIdentifier:@"detail"];
    [self.tableView registerClass:[GCSBaseViewCell class] forCellReuseIdentifier:@"voice"];
    
//    self.navigationController.navigationBarHidden = YES;
    UILabel * la = [[[UILabel alloc] initWithFrame:CGRectMake(0, 0, 60, 30)] autorelease];
    la.backgroundColor = [UIColor clearColor];
    la.text = self.nameuser;
    self.navigationItem.titleView = la;
    [self requestSource];
    self.segment = [[[UISegmentedControl alloc] initWithItems:[NSArray arrayWithObjects:@"帖子", @"评论", nil]]autorelease];
    self.segment.frame = CGRectMake(0, 250, 320, 30);
    self.segment.selectedSegmentIndex = 0;
    self.segment.backgroundColor = [UIColor lightGrayColor];
    [self.segment addTarget:self action:@selector(_loadingCommentData:) forControlEvents:UIControlEventValueChanged];
    [self.headerview.hView addSubview:self.segment];



    
}

- (void)_loadingCommentData:(UISegmentedControl *)segment{
    QiushiRequestManager *request3 = [[[QiushiRequestManager alloc] init] autorelease];
    self.segment.selectedSegmentIndex = segment.selectedSegmentIndex;
    switch (segment.selectedSegmentIndex) {
        case 0:
            [self.tableView reloadData];
            break;
            case 1:
            [self.dataSource removeAllObjects];
            request3.destinationURLString = [NSString stringWithFormat:@"http://api.budejie.com/api/api_open.php?a=mycomment&appname=baisibudejie&asid=8FE33EB2-39D7-4572-8D44-8F7DC91FFB0C&c=comment&client=iphone&lastcid=0&market=&openudid=8d759955a0af863ed9510d782ff53bb62cd0a126&page=1&per=20&udid=&uid=%@&ver=3.0&visiting=", self.userid];
            request3.delegate = self;
            [request3 startRequest];
            break;

        default:
            break;
    }
    

}

- (void)request:(QiushiRequestManager *)request didFaildWithError:(NSError *)error{
    NSLog(@"%@", error);
}

- (void)request:(QiushiRequestManager *)request didFinishLoadingWithData:(NSData *)data{
    if ([request.destinationURLString isEqualToString:[NSString stringWithFormat:@"http://api.budejie.com/api/api_open.php?a=profile&appname=baisibudejie&asid=8FE33EB2-39D7-4572-8D44-8F7DC91FFB0C&c=user&client=iphone&market=&openudid=8d759955a0af863ed9510d782ff53bb62cd0a126&udid=&userid=%@&ver=3.0", self.userid]]) {
        
//        [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
        self.datadic = [jsonDict objectForKey:@"data"];
    }
    
    if ([request.destinationURLString isEqualToString:[NSString stringWithFormat:@"http://api.budejie.com/api/api_open.php?a=mytopic&appname=baisibudejie&asid=8FE33EB2-39D7-4572-8D44-8F7DC91FFB0C&c=topic&openudid=8d759955a0af863ed9510d782ff53bb62cd0a126&order_type=desc&type=1&udid=&uid=0&ver=3.0&visit_uid=%@",self.userid]]) {
       [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];
        NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
        for (NSDictionary *dict in json[@"topics"]) {
//            VideoModel *model = [VideoModel modelWithDictionary:dict];
//            [self.dataArray addObject:model];
            personalModel *perModel = [personalModel modelWithDictionary:dict];
            [self.dataArray addObject:perModel];
        }
        
        
    }
    if ([request.destinationURLString isEqualToString:[NSString stringWithFormat:@"http://api.budejie.com/api/api_open.php?a=mycomment&appname=baisibudejie&asid=8FE33EB2-39D7-4572-8D44-8F7DC91FFB0C&c=comment&client=iphone&lastcid=0&market=&openudid=8d759955a0af863ed9510d782ff53bb62cd0a126&page=1&per=20&udid=&uid=%@&ver=3.0&visiting=", self.userid]]) {
        NSArray *jsonDict1 = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
                for (NSDictionary *dict1  in jsonDict1) {
            CommentItemmModel *commentModel = [CommentItemmModel modelWithDictionary:dict1];
            [self.dataSource addObject:commentModel];
        }
        if (self.dataSource.count == 0) {
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"暂时没有评论" delegate:self cancelButtonTitle:nil otherButtonTitles:@"好", nil];
            [alert show];
            [alert release];
            
        }


    }
    
    [self.tableView reloadData];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 0) {
        self.segment.selectedSegmentIndex = 0;
        [self.tableView reloadData];
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.segment.selectedSegmentIndex == 0) {
        return self.dataArray.count;
    }
    return self.dataSource.count;
    // Return the number of rows in the section.
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.segment.selectedSegmentIndex == 1) {
        CommentItemmModel *itemModel = [self.dataSource objectAtIndex:indexPath.row];
        PictureDetailTableViewCell *tableModel = [[[PictureDetailTableViewCell alloc] init] autorelease];
        
        return tableModel.Label.frame.origin.y + itemModel.contentSize + [itemModel.pinfo.height floatValue]*310/[itemModel.pinfo.width floatValue] + 55;
    }
    
    return 400;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    PersonalTableViewCell *cell = nil;
    PictureDetailTableViewCell *cell1 = nil;
//    GCSBaseViewCell *cell2 = nil;
    [self.headerview.backGround sd_setImageWithURL:[NSURL URLWithString:self.datadic[@"background_image"]]placeholderImage:[UIImage imageNamed:@"background.jpg"]];
   
    [self.headerview.AvatarView sd_setImageWithURL:[NSURL URLWithString:self.datadic[@"profile_image_large"]] placeholderImage:[UIImage imageNamed:@"aliAvatar"]];
    //    avatarView.transform = CGAffineTransformMakeScale(0.5, 1);
    //详情赞美计数
    [self.headerview.praisebutton setImage:[UIImage imageNamed:@"xiaohongxin.png"] forState:UIControlStateNormal];
    self.headerview.praiselabel.text = self.datadic[@"praise_count"];
    self.headerview.nameLabel.text = self.datadic[@"username"];
    if (![self.datadic[@"introduction"] isEqualToString:@""]) {
        self.headerview.introLabel.text = self.datadic[@"introduction"];
    }else{
        self.headerview.introLabel.text = @"这家伙什么都么有写 ! ! !";

    }
    
    switch (self.segment.selectedSegmentIndex) {
        case 0:
//            self.videoModel = [self.dataArray objectAtIndex:indexPath.row];
            self.perModel = [self.dataArray objectAtIndex:indexPath.row];

            cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
            if (self.perModel.videouri.length != 0) {
                [cell setContentForCellWithItemModel:self.perModel];
                [cell.image0 sd_setImageWithURL:[NSURL URLWithString:self.perModel.image1]];

                [cell.playButton addTarget:self action:@selector(handlePlayVideoAction:) forControlEvents:UIControlEventTouchUpInside];
            }
            if (self.perModel.voiceuri.length != 0) {
                [cell.thisTieziImage sd_setImageWithURL:[NSURL URLWithString:self.perModel.image1]];
                
                [cell setContentForCellWithItemModel:self.perModel];
                [cell configurePlayerButton];
                [cell.voiceButton addTarget:self action:@selector(handlePlayVoiceButton:) forControlEvents:UIControlEventTouchUpInside];
                cell.voiceButton.tag = indexPath.row + 200;

            }
            if (self.perModel.videouri.length == 0 && self.perModel.voiceuri.length == 0 && self.perModel.image1.length != 0) {
                 
                [cell.image0 sd_setImageWithURL:[NSURL URLWithString:self.perModel.image1]];
                
                        cell.image0.contentMode = UIViewContentModeTop;
                        cell.image0.clipsToBounds = YES;
                

                [cell setContentForCellWithItemModel:self.perModel];
                
            }else if (self.perModel.videouri.length == 0 && self.perModel.voiceuri.length == 0 && self.perModel.image1.length == 0)
                cell.image0.contentMode = UIViewContentModeTop;
            cell.image0.clipsToBounds = YES;

            
                [cell setContentForCellWithItemModel:self.perModel];

            break;
            
            case 1:
           cell1 = [tableView dequeueReusableCellWithIdentifier:@"detail"];
            CommentItemmModel *commentModel = [self.dataSource objectAtIndex:indexPath.row];
            [cell1.UserAvatar sd_setImageWithURL:[NSURL URLWithString:commentModel.pinfo.profile_image] placeholderImage:[UIImage imageNamed:@"aliAvatar"]];
            cell1.deNameLabel.text = commentModel.pinfo.name;
            cell1.deTimeLabel.text = commentModel.pinfo.created_at;
            cell1.commentContentLabel.text = commentModel.cinfo.content;
            cell1.commentContentLabel.frame = CGRectMake(cell1.commentContentLabel.frame.origin.x, cell1.commentContentLabel.frame.origin.y, cell1.commentContentLabel.frame.size.width, commentModel.contentSize);
            CGFloat Y = cell1.commentContentLabel.frame.origin.y + commentModel.contentSize;
           
            
            cell1.videoImage.frame = CGRectMake(cell1.videoImage.frame.origin.x, Y, cell1.videoImage.frame.size.width, [commentModel.pinfo.height floatValue]*300/[commentModel.pinfo.width floatValue]);
            
            [cell1.videoImage sd_setImageWithURL:[NSURL URLWithString:commentModel.pinfo.image0]];

                return cell1;
            
            
        default:
            break;
    }
   

    
    return cell;
}

- (void)handlePlayVideoAction:(id)sender {
    PlayVideoViewController *playView = [[[PlayVideoViewController alloc] init] autorelease];
    playView.PalyURl = self.perModel.videouri;
    [self.navigationController pushViewController:playView animated:YES];
}




- (void)handlePlayVoiceButton:(AudioButton *)sender{
    
    personalModel *item = self.dataArray[sender.tag - 200];
    
    if (self.audioplayer == nil) {
        self.audioplayer = [[[AudioPlayer alloc] init] autorelease];
    }
    
    if ([self.audioplayer.button isEqual:sender]) {
        [self.audioplayer play];
    } else {
        [self.audioplayer stop];
        
        self.audioplayer.button = sender;
        self.audioplayer.url = [NSURL URLWithString:item.voiceuri];
        NSLog(@"-----------%@",item.voiceuri);
        
        [self.audioplayer play];
    }
}



/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
