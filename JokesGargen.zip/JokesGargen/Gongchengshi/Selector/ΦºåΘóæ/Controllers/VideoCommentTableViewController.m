//
//  VideoCommentTableViewController.m
//  Gongchengshi
//
//  Created by dqb on 14-11-5.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "VideoCommentTableViewController.h"
#import "MJRefresh.h"
#import "QiushiRequestManager.h"
#import "VideoModel.h"
#import "VideoCommentTableViewCell.h"
#import "CommentModels.h"
#import "WriteDetailViewController.h"
#import "BaseVideoTableViewCell.h"
#import "UIImageView+WebCache.h"

@interface VideoCommentTableViewController ()<QiushiRequestManagerDelegate>
@property(nonatomic, retain)NSMutableArray *dataArray;
@property(nonatomic, retain)UILabel *label;
@property(nonatomic, assign)NSInteger count;
- (void)_beginRequest;

@end

@implementation VideoCommentTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (NSMutableArray *)dataArray{
    
    if (!_dataArray) {
        self.dataArray = [NSMutableArray array];
    }
    return _dataArray;
}
- (void)request:(QiushiRequestManager *)request didFaildWithError:(NSError *)error{
    
    NSLog(@"%@", error);
}

- (void)request:(QiushiRequestManager *)request didFinishLoadingWithData:(NSData *)data{
    
   [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];
    
    if (![self.videomodel.comment isEqualToString:@"0"]) {
        NSMutableDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
        NSMutableArray *array = json[@"data"];
        for (id obj in array) {
            CommentModels *model = [[[CommentModels alloc] initWithDictionary:obj] autorelease];
            [self.dataArray addObject:model];
        }
        
        [self.tableView reloadData];
    }
    
    
}
- (void)_beginRequest{
    QiushiRequestManager *manager = [[QiushiRequestManager alloc] init];
    manager.delegate = self;
    manager.destinationURLString = [NSString stringWithFormat:@"http://api.budejie.com/api/api_open.php?a=dataList&c=comment&data_id=%@&hot=1&page=1&per=20", self.user_id];

    [manager startRequest];
}


- (void)viewWillDisappear:(BOOL)animated{
    [self.label removeFromSuperview];
    
}

- (void)viewWillAppear:(BOOL)animated{
    
    self.label = [[[UILabel alloc] initWithFrame:CGRectMake(0, 0, 320, 49)] autorelease];
    self.label.backgroundColor = [UIColor lightGrayColor];
    //    label.backgroundColor = [UIColor whiteColor];
    self.label.userInteractionEnabled = YES;
    UIButton *commentButton = [UIButton buttonWithType:UIButtonTypeCustom];
    commentButton.frame = CGRectMake(5, 7, 220, 39);
    commentButton.backgroundColor = [UIColor whiteColor];
    [commentButton setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    [commentButton setTitle:@"写评论" forState:UIControlStateNormal];
    [commentButton addTarget:self action:@selector(handleCommentAction:) forControlEvents:UIControlEventTouchUpInside];
    UIButton *shareButton = [UIButton buttonWithType:UIButtonTypeCustom];
    shareButton.frame = CGRectMake(230, 7, 85/2, 39);
    UIImageView *shareImage = [[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 40, 39)] autorelease];
    shareImage.image = [UIImage imageNamed:@"mainCellShare.png"];
    [shareButton addSubview:shareImage];
    
    UIButton *shoucangButton = [UIButton buttonWithType:UIButtonTypeCustom];
    shoucangButton.frame = CGRectMake(275, 7, 40, 39);
    UIImageView *shoucang = [[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 40, 39)] autorelease];
    shoucang.image = [UIImage imageNamed:@"comment-colletion-icon@2x.png"];
    [shoucangButton addSubview:shoucang];
    [self.label addSubview:shoucangButton];
    [self.label addSubview:shareButton];
    [self.label addSubview:commentButton];
    [self.tabBarController.tabBar addSubview:self.label];
}
- (void)handleCommentAction:(UIButton *)sender{
    
    WriteDetailViewController *write = [[[WriteDetailViewController alloc] init] autorelease];
    self.tabBarController.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:write animated:YES];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.title = @"评论";
    self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    self.navigationController.navigationBar.translucent = NO;
    //    UITextField *textFiled = [[UITextField alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height - 44, 320, 44)];
    //    textFiled.backgroundColor = [UIColor purpleColor];
    //    [self.view addSubview:textFiled];
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    [self.tableView registerClass:[VideoCommentTableViewCell class] forCellReuseIdentifier:@"Cell"];
    [self.tableView registerClass:[BaseVideoTableViewCell class] forCellReuseIdentifier:@"Header"];
    [self _beginRequest];
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    if (section == 0) {
        return 1;
    }
    return self.dataArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section == 0) {
        
        return 400;
    }
    CommentModels *comment = [self.dataArray objectAtIndex:indexPath.row];
    CGFloat height = comment.contentSize.height;
    return height + 70;
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    
    if (section == 0) {
        return @"";
    }
    return @"最新评论";
}




- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    BaseVideoTableViewCell *cell = nil;
    VideoCommentTableViewCell *cell1 = nil;
    if (indexPath.section == 0) {
        cell = [tableView dequeueReusableCellWithIdentifier:@"Header" forIndexPath:indexPath];
        [cell setVideoContentForCellWithItemModel:self.videomodel];
        return cell;

    }else{
       cell1 = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
        CommentModels *commentModel = self.dataArray[indexPath.row];
        [cell1 setCommentContentWithModel:commentModel];
   
        return cell1;

        
    }
   
    
    // Configure the cell...
    
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
