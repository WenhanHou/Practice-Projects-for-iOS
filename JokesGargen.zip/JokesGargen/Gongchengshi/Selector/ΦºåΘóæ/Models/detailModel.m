//
//  detailModel.m
//  Gongchengshi
//
//  Created by dqb on 14-11-1.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "detailModel.h"

@implementation detailModel

- (id)initWithDictionary:(NSDictionary *)dict{
    if (self = [super init]) {
        self.sex = dict[@"sex"];
        self.introduction = dict[@"introduction"];
        self.profile_image_large = dict[@"profile_image_large"];
        self.background_image = dict[@"background_image"];
        self.fans_count = dict[@"fans_count"];
        self.follow_count = dict[@"follow_count"];
        self.praise_count = dict[@"praise_count"];
        self.tiezi_count = dict[@"tiezi_count"];

    }
    return self;
}

-(void)dealloc{
    [_background_image release];
    [_sex release];
    [_introduction release];
    [_praise_count release];
    [_profile_image_large release];
    [_fans_count release];
    [_follow_count release];
    [_tiezi_count release];
    [super dealloc];
}



@end
