//
//  UserComment.m
//  BigDragon
//
//  Created by 田傲 on 14-11-1.
//  Copyright (c) 2014年 www.lanou3g.com. All rights reserved.
//

#import "UserComment.h"

@implementation UserComment

- (id)initWithDictionary:(NSDictionary *)dict{
    
      if (self = [super init]) {
        self.name = [dict objectForKey:@"name"];
        self.text = [dict objectForKey:@"text"];
        self.profile_image = [dict objectForKey:@"profile_image"];
        self.width = [dict objectForKey:@"width"];
        self.height = [dict objectForKey:@"height"];
        self.image0  = [dict objectForKey:@"image0"];
          
    }
    return self;
    
    
}

+ (id)modelWithDictionary:(NSDictionary *)dict{
    
    return [[[[self class]alloc]initWithDictionary:dict] autorelease];
    
}

- (void)dealloc {
    [_image0 release];
    
    [_name release];
    [_text release];
    [_profile_image release];
    [_width release];
    [_height release];
    [super dealloc];
    
    
}
@end
