//
//  userModel.m
//  BigDragon
//
//  Created by 田傲 on 14-11-1.
//  Copyright (c) 2014年 www.lanou3g.com. All rights reserved.
//

#import "userModel.h"

@implementation userModel

- (id)initWithDictionary:(NSDictionary *)dict{
    if (self = [super init]) {
        self.username  = [dict objectForKey:@"username"];
        
    }
    return self;
    
 
}
+ (id)modelWithDictionary:(NSDictionary *)dict{
    
    return [[[[self class]alloc]initWithDictionary:dict] autorelease];
    
}

- (void)dealloc {
    
    [_username release];
    [super dealloc];
    
}
@end
