//
//  CommentModel.m
//  BigDragon
//
//  Created by 田傲 on 14-11-1.
//  Copyright (c) 2014年 www.lanou3g.com. All rights reserved.
//

#import "CommentModel.h"

@implementation CommentModel

- (id)initWithDictionary:(NSDictionary *)dict{
    if (self = [super init]) {
        
        //NSDictionary *div = [dict objectForKey:@"user"];
        self.usename = [userModel modelWithDictionary:[dict objectForKey:@"user"]];
        self.content = [dict objectForKey:@"content"];
        
    }
    
    return self;
    

}

+ (id)modelWithDictionary:(NSDictionary *)dict{
    
    return [[[[self class] alloc] initWithDictionary:dict] autorelease];
    
}

- (void)dealloc {
    [_usename release];
    [_content release];
    [super dealloc];
    
    
}

@end
