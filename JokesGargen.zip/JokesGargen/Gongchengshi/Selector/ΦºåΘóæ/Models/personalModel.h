//
//  personalModel.h
//  Gongchengshi
//
//  Created by dqb on 14-11-4.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseVideoModel.h"

@interface personalModel : BaseVideoModel
@property (nonatomic, retain) NSString *videouri;//视频地址
@property (nonatomic, retain) NSString *videotime;
@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSString *profile_image;//头像
@property (nonatomic, retain) NSString *created_at;
@property (nonatomic, retain) NSString *image1;//视频封面
@property (nonatomic, retain) NSString *videoWidth;
@property (nonatomic, retain) NSString *videoHeight;
@property (nonatomic, retain) NSString *text;//视频上方文字
@property (nonatomic, retain) NSString *love;//喜欢
@property (nonatomic, retain) NSString *hate;//不喜欢
@property (nonatomic, retain) NSString *forward;//分享
@property (nonatomic, retain) NSString *comment;//评论
@property (nonatomic, retain) NSString *playcount;//播放次数
@property (nonatomic, retain) NSString *user_id;//用户id
@property (nonatomic, retain) NSString *voiceuri;//音频地址,URL

@property (nonatomic, retain) NSString *data_id;

@end
