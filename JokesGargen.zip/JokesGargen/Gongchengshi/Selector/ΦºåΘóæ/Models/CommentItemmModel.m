//
//  CommentItemmModel.m
//  BigDragon
//
//  Created by 田傲 on 14-11-1.
//  Copyright (c) 2014年 www.lanou3g.com. All rights reserved.
//

#import "CommentItemmModel.h"

@implementation CommentItemmModel

- (id)initWithDictionary:(NSDictionary *)dict{
    
    if (self = [super init]) {
        self.cinfo = [CommentModel modelWithDictionary:[dict objectForKey:@"cinfo"]];
        self.pinfo = [UserComment modelWithDictionary:[dict objectForKey:@"pinfo"]];
        
    }
    return self;
    
    
}

+ (id)modelWithDictionary:(NSDictionary *)dict{
    
    return [[[[self class]alloc]initWithDictionary:dict] autorelease];
    
}

- (CGFloat )contentSize{

    CGSize size = [self.pinfo.text boundingRectWithSize:CGSizeMake(280, 0) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:15]} context:nil].size;
   
    return size.height;
    

    
 
    
}

- (void)dealloc{
    [_cinfo release];
    [_pinfo release];
    [super dealloc];
}
@end
