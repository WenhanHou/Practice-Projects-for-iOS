//
//  detailModel.h
//  Gongchengshi
//
//  Created by dqb on 14-11-1.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "VideoModel.h"

@interface detailModel : VideoModel
@property(nonatomic, retain) NSString *sex;
@property(nonatomic, retain) NSString *introduction;
@property(nonatomic, retain) NSString *profile_image_large;
@property(nonatomic, retain) NSString *background_image;
@property(nonatomic, retain) NSString *tiezi_count;
@property(nonatomic, retain) NSString *fans_count;
@property(nonatomic, retain) NSString *praise_count;
@property(nonatomic, retain) NSString *follow_count;
@end
