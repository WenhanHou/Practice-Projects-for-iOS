//
//  MyMainPageModel.m
//  Gongchengshi
//
//  Created by dqb on 14-11-3.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "MyMainPageModel.h"

@implementation MyMainPageModel

- (id)initWithDictionary:(NSDictionary *)dict{
    if (self = [super init]) {
        self.icon = dict[@"icon"];
        self.name = dict[@"name"];
        self.url = dict[@"url"];
        self.theme_id = dict[@"theme_id"];
        self.theme_name = dict[@"theme_name"];
    }
    return self;
}

- (void)dealloc{
    [_icon release];
    [_name release];
    [_url release];
    [_theme_id release];
    [_theme_name release];
    [super dealloc];
}


@end
