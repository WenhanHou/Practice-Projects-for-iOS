//
//  CommentModel.h
//  BigDragon
//
//  Created by 田傲 on 14-11-1.
//  Copyright (c) 2014年 www.lanou3g.com. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "userModel.h"

@interface CommentModel : NSObject

@property (nonatomic, retain)NSString *content;//用户评论的内容
@property (nonatomic, retain)userModel *usename;//用户名
- (id)initWithDictionary:(NSDictionary *)dict;
+ (id)modelWithDictionary:(NSDictionary *)dict;



@end
