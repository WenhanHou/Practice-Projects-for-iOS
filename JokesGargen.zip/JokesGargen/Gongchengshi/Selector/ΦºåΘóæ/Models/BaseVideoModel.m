//
//  BaseVideoModel.m
//  Gongchengshi
//
//  Created by dqb on 14-10-28.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "BaseVideoModel.h"

@implementation BaseVideoModel

- (id)initWithDictionary:(NSDictionary *)dict{
    if (self = [super init]) {
        
    }
    return self;
}


+ (id)modelWithDictionary:(NSDictionary *)dict{
    return [[[[self class] alloc] initWithDictionary:dict] autorelease];
}

@end
