//
//  UserComment.h
//  BigDragon
//
//  Created by 田傲 on 14-11-1.
//  Copyright (c) 2014年 www.lanou3g.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserComment : NSObject

- (id)initWithDictionary:(NSDictionary *)dict;
+ (id)modelWithDictionary:(NSDictionary *)dict;

@property (nonatomic, retain)NSString *text;//发表的内容
@property (nonatomic, retain)NSString *profile_image;//用户头像
@property (nonatomic, retain)NSString *created_at;//发表时间
@property (nonatomic, retain)NSString *name;//用户名
@property (nonatomic, retain)NSString *width;//图片宽度
@property (nonatomic, retain)NSString *height;//图片高度
@property (nonatomic, retain)NSString *image0;

@end
