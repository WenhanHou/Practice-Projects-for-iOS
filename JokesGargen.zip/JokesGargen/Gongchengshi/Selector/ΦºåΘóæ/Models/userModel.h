//
//  userModel.h
//  BigDragon
//
//  Created by 田傲 on 14-11-1.
//  Copyright (c) 2014年 www.lanou3g.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface userModel : NSObject

- (id)initWithDictionary:(NSDictionary *)dict;
+ (id)modelWithDictionary:(NSDictionary *)dict;

@property (nonatomic, retain)NSString *username;


@end
