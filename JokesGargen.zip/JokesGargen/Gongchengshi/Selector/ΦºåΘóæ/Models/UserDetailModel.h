//
//  UserDetailModel.h
//  BigDragon
//
//  Created by 田傲 on 14-10-31.
//  Copyright (c) 2014年 www.lanou3g.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserDetailModel : NSObject

- (id)initWithDictionary:(NSDictionary *)dict;
+ (id)modelWithDictionary:(NSDictionary *)dict;

@property (nonatomic, retain)NSString *background_image;
@property (nonatomic, retain)NSString *introuduction;//用户签名
@property (nonatomic, retain)NSString *profile_image;//用户头像
@property (nonatomic, retain)NSString *userid;//用户id;

@property (nonatomic, retain)NSString *username;//用户名;

@end
