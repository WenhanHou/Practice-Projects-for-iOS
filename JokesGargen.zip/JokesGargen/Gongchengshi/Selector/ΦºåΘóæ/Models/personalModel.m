//
//  personalModel.m
//  Gongchengshi
//
//  Created by dqb on 14-11-4.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "personalModel.h"

@implementation personalModel

- (id)initWithDictionary:(NSDictionary *)dict{
    if (self = [super init]) {
        self.videotime = [dict objectForKey:@"voicetime"];
        self.videouri = [dict objectForKey:@"videouri"];
        self.created_at = [dict objectForKey:@"created_at"];
        self.profile_image = [dict objectForKey:@"profile_image"];
        self.name = [dict objectForKey:@"name"];
        self.image1 = [dict objectForKey:@"image0"];
        self.videoHeight = [dict objectForKey:@"height"];
        self.videoWidth = [dict objectForKey:@"width"];
        self.text = [dict objectForKey:@"text"];
        self.love = [dict objectForKey:@"love"];
        self.comment = [dict objectForKey:@"comment"];
        self.playcount = [dict objectForKey:@"playcount"];
        self.hate = [dict objectForKey:@"hate"];
        self.forward = [dict objectForKey:@"forward"];
        self.user_id = [dict objectForKey:@"user_id"];
        self.voiceuri = dict[@"voiceuri"];
        self.data_id = [dict objectForKey:@"data_id"];
        
    }
    return self;
}

- (void)dealloc{
    [_videotime release];
    [_videouri release];
    [_created_at release];
    [_profile_image release];
    [_name release];
    [_image1 release];
    [_videoHeight release];
    [_videoWidth release];
    [_text release];
    [_comment release];
    [_playcount release];
    [_hate release];
    [_forward release];
    [_user_id release];
    [_voiceuri release];
    [_data_id release];
    
    [super dealloc];
}



@end
