//
//  CommentItemmModel.h
//  BigDragon
//
//  Created by 田傲 on 14-11-1.
//  Copyright (c) 2014年 www.lanou3g.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CommentModel.h"
#import "UserComment.h"

@interface CommentItemmModel : NSObject
- (id)initWithDictionary:(NSDictionary *)dict;
+ (id)modelWithDictionary:(NSDictionary *)dict;


@property (nonatomic, retain)CommentModel *cinfo;
@property (nonatomic, retain)UserComment *pinfo;
@property (nonatomic, assign)CGFloat contentSize;

@end
