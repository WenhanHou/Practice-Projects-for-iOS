//
//  BaseVideoModel.h
//  Gongchengshi
//
//  Created by dqb on 14-10-28.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseVideoModel : NSObject

- (id)initWithDictionary:(NSDictionary *)dict;

+ (id)modelWithDictionary:(NSDictionary *)dict;

@end
