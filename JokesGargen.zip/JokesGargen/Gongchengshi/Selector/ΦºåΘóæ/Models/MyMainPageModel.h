//
//  MyMainPageModel.h
//  Gongchengshi
//
//  Created by dqb on 14-11-3.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseVideoModel.h"

@interface MyMainPageModel : BaseVideoModel
@property(nonatomic, retain) NSString *icon;
@property(nonatomic, retain) NSString *name;
@property(nonatomic, retain) NSString *url;
@property(nonatomic, retain) NSString *theme_id;
@property(nonatomic, retain) NSString *theme_name;


@end
