//
//  UserDetailModel.m
//  BigDragon
//
//  Created by 田傲 on 14-10-31.
//  Copyright (c) 2014年 www.lanou3g.com. All rights reserved.
//

#import "UserDetailModel.h"

@implementation UserDetailModel

- (id)initWithDictionary:(NSDictionary *)dict{
    if (self = [super init]) {
        self.background_image = [dict objectForKey:@"background_image"];
        self.username = [dict objectForKey:@"username"];
        self.profile_image = [dict objectForKey:@"profile_image"];
        self.introuduction = [dict objectForKey:@"introduction"];
        self.userid = [dict objectForKey:@"id"];
        
    }
    
    return self;
    
    
    
}

+ (id)modelWithDictionary:(NSDictionary *)dict{
    
    return [[[[self class]alloc]initWithDictionary:dict] autorelease];
    
    
}

- (void)dealloc{
    [_background_image release];
    [_username release];
    [_introuduction release];
    [_userid release];
    [_profile_image release];
    [super dealloc];
    
    
}

@end
