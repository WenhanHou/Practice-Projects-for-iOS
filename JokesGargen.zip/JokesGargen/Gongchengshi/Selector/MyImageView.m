//
//  MyImageView.m
//  MyLabel
//
//  Created by yao on 14-10-29.
//  Copyright (c) 2014年 BigDrion. All rights reserved.
//

#import "MyImageView.h"

@implementation MyImageView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.userInteractionEnabled = YES;
    }
    return self;
}
- (void)addTarget:(id)target action:(SEL)action{
    self.target = target;
    self.action = action;
}
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    [self.target performSelector:self.action withObject:self];
}
- (void)dealloc{
    [_target release];
    [super dealloc];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
