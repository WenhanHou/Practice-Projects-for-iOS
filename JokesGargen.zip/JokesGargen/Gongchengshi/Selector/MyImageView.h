//
//  MyImageView.h
//  MyLabel
//
//  Created by yao on 14-10-29.
//  Copyright (c) 2014年 BigDrion. All rights reserved.
//
//自定义imageView
#import <UIKit/UIKit.h>

@interface MyImageView : UIImageView
@property (nonatomic, retain)id target;
@property (nonatomic, assign) SEL action;
- (void)addTarget:(id)target action:(SEL)action;
@end
