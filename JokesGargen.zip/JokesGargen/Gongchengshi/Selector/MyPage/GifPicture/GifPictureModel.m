//
//  GifPictureModel.m
//  Gongchengshi
//
//  Created by lanouhn on 14-11-6.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "GifPictureModel.h"

@implementation GifPictureModel

- (id)initWithDictionary:(NSDictionary *)dic{

    if (self = [super init]) {
        self.userName = dic[@"name"];
        self.create_time = dic[@"created_at"];
        self.profile_image = dic[@"profile_image"];
        self.text = dic[@"text"];
        self.image = dic[@"image0"];
        self.image_width = dic[@"width"];
        self.loveCount = dic[@"love"];
        self.forWard = dic[@"forward"];
        self.height = dic[@"height"];
        self.uid = dic[@"uid"];
        self.user_id = dic[@"user_id"];
        self.hate =dic[@"hate"];
        self.idString = dic[@"id"];
        self.comment = dic[@"comment"];
        
    }
    return self;
}
+ (id)modelWithDictionary:(NSDictionary *)dic{

    return [[[[self class]alloc] initWithDictionary:dic] autorelease];
}
- (CGSize)contentSize{
    CGSize size = [self.text boundingRectWithSize:CGSizeMake(310, 0) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:20]} context:nil].size;
    return size;
}
@end
