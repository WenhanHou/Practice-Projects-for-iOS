//
//  GifPictureTableViewCell.h
//  Gongchengshi
//
//  Created by lanouhn on 14-11-6.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GifPictureTableViewCell : UITableViewCell

@property(nonatomic, retain)UIButton *userName; // 用户名
@property(nonatomic, retain)UILabel *userNameLabel;
@property(nonatomic, retain)UIButton *created_time; // 发布时间
@property(nonatomic, retain)UILabel *created_timeLabel;
@property(nonatomic, retain)UIButton *profile_image; // 头像
@property(nonatomic, retain)UIImageView *profile_imageLabel;
@property(nonatomic, retain)UIButton *text; // 文本
@property(nonatomic, retain)UILabel *labelText;
@property(nonatomic, retain)UIButton *image; // 图片
@property(nonatomic, retain)UIImageView *imageImage;
@property(nonatomic, retain)UIButton *favorite; // 喜欢
@property(nonatomic, retain)UIImageView *favoriteImage;
@property(nonatomic, retain)UILabel *favoriteCount;
@property(nonatomic, retain)UIButton *dislike; // 讨厌
@property(nonatomic, retain)UIImageView *dislikeImage;
@property(nonatomic, retain)UILabel *dislikeCount;
@property(nonatomic, retain)UIButton *share; // 评论
@property(nonatomic, retain)UIImageView *shareImage;
@property(nonatomic, retain)UILabel *shareCount;
@property(nonatomic, retain)UIButton *comment; // 评论
@property(nonatomic, retain)UIImageView *commentImage;
@property(nonatomic, retain)UILabel *commentCount;

@end
