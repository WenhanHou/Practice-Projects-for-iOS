//
//  GifPictureModel.h
//  Gongchengshi
//
//  Created by lanouhn on 14-11-6.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GifPictureModel : NSObject

@property(nonatomic, retain)NSString *userName;
@property(nonatomic, retain)NSString *create_time;
@property(nonatomic, retain)NSString *profile_image;
@property(nonatomic, retain)NSString *text;
@property(nonatomic, retain)NSString *image;
@property(nonatomic, retain)NSString *image_width;
@property(nonatomic, retain)NSString *loveCount;
@property(nonatomic, retain)NSString *forWard;
@property(nonatomic, retain)NSString *height;
@property(nonatomic, retain)NSString *uid;
@property(nonatomic, retain)NSString *user_id;
@property(nonatomic, retain)NSString *hate;
@property(nonatomic, retain)NSString *idString;
@property(nonatomic, retain)NSString *comment;
@property(nonatomic, assign)CGSize   contentSize;

- (id)initWithDictionary:(NSDictionary *)dic;
+ (id)modelWithDictionary:(NSDictionary *)dic;

@end
