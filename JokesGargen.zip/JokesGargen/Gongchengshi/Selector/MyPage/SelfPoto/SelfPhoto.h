//
//  SelfPhoto.h
//  Gongchengshi
//
//  Created by lanouhn on 14-11-6.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SelfPhoto : NSObject

@property(nonatomic, retain)NSString *userName;
@property(nonatomic, retain)NSString *profile_image;
@property(nonatomic, retain)NSString *create_time;
@property(nonatomic, retain)NSString *text;
@property(nonatomic, retain)NSString *image;
@property(nonatomic, retain)NSString *idString;
@property(nonatomic, retain)NSString *uid;
@property(nonatomic, retain)NSString *use_id;
@property(nonatomic, retain)NSString *love;
@property(nonatomic, retain)NSString *hate;
@property(nonatomic, retain)NSString *comment;
@property(nonatomic, retain)NSString *forward;
@property(nonatomic, assign)CGSize contentSize;
@property(nonatomic, retain)NSString *width;
@property(nonatomic, retain)NSString *height;
- (id)initWithDictionary:(NSDictionary *)dic;
+ (id)modelWithDictionary:(NSDictionary *)dic;
@end
