//
//  SelfPhotoTableViewCell.m
//  Gongchengshi
//
//  Created by lanouhn on 14-11-6.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "SelfPhotoTableViewCell.h"

@implementation SelfPhotoTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        [self addSubview:self.userName];
        [self addSubview:self.profile_image];
        [self addSubview:self.created_time];
        [self addSubview:self.text];
        [self addSubview:self.image];
        [self addSubview:self.imageImage];
        [self addSubview:self.favorite];
        [self addSubview:self.dislike];
        [self addSubview:self.share];
        [self addSubview:self.comment];
    }
    return self;
}
- (UIButton *)userName{
    
    if (!_userName) {
        self.userName = [UIButton buttonWithType:UIButtonTypeCustom];
        _userName.frame = CGRectMake(60, 10, 150, 25);
        
        [self.userName addSubview:self.userNameLabel];
        
    }
    
    return _userName;
}
- (UILabel *)userNameLabel{
    
    if (!_userNameLabel) {
        self.userNameLabel = [[[UILabel alloc] initWithFrame:CGRectMake(0, 0, 150, 20)] autorelease];
        self.userNameLabel.textColor = [UIColor blackColor];
        self.userNameLabel.textAlignment = NSTextAlignmentLeft;
        self.userNameLabel.font = [UIFont systemFontOfSize:15];
    }
    return _userNameLabel;
}
- (UIButton *)created_time{
    
    if (!_created_time) {
        self.created_time = [UIButton buttonWithType:UIButtonTypeCustom];
        self.created_time.frame = CGRectMake(60, 30, 150, 25);
        [self addSubview:_created_timeLabel];
        
        [self.created_time addSubview:self.created_timeLabel];
    }
    return _created_time;
}

-(UILabel *)created_timeLabel{
    
    if (!_created_timeLabel) {
        
        self.created_timeLabel = [[[UILabel alloc] initWithFrame:CGRectMake(0, 0, 150, 25)]autorelease];
        
        self.created_timeLabel = [[[UILabel alloc] initWithFrame:CGRectMake(0, 0, 150, 25)] autorelease];
        
        _created_timeLabel.textAlignment = NSTextAlignmentLeft;
        _created_timeLabel.font = [UIFont systemFontOfSize:15];
        _created_timeLabel.numberOfLines = 0;
    }
    return _created_timeLabel;
}
- (UIButton *)profile_image{
    
    if (!_profile_image) {
        self.profile_image = [UIButton buttonWithType:UIButtonTypeCustom];
        self.profile_image.frame = CGRectMake(0, 10, 50, 50);
        
        [self.profile_image addSubview:self.profile_imageLabel];
    }
    return _profile_image;
}

- (UIImageView *)profile_imageLabel{
    
    if (!_profile_imageLabel) {
        self.profile_imageLabel = [[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 50, 50)] autorelease];
    }
    return _profile_imageLabel;
}
- (UIButton *)text{
    
    if (!_text) {
        self.text = [UIButton buttonWithType:UIButtonTypeCustom];
        self.text.frame = CGRectMake(0, 65,310, 60);
        [self addSubview:_labelText];
        [self.text addSubview:self.labelText];
    }
    return _text;
}

- (UILabel *)labelText{
    
    if (!_labelText) {
        self.labelText = [[[UILabel alloc] initWithFrame:CGRectMake(0, 0, 310, 60)] autorelease];
        _labelText.textAlignment = NSTextAlignmentLeft;
        _labelText.textColor = [UIColor blackColor];
        _labelText.numberOfLines = 0;
        _labelText.font = [UIFont systemFontOfSize:17];
    }
    return _labelText;
}
//- (UIButton *)image{
//
//    if (!_image) {
//        self.image = [UIButton buttonWithType:UIButtonTypeCustom];
//        _image.frame = CGRectMake(0, 135, 310, 180);
//
//        [self.image addSubview:self.imageImage];
//    }
//    return _image;
//}
- (UIButton *)image{
    if (!_image) {
        self.image = [UIButton buttonWithType:UIButtonTypeCustom];
        _image.frame = CGRectMake(0, 125, 310, 200);
    }
    return _image;
}
- (UIImageView *)imageImage{
    
    if (!_imageImage) {
        self.imageImage = [[[UIImageView alloc] initWithFrame:CGRectMake(0, 135, 310, 200)] autorelease];
        
    }
    _imageImage.userInteractionEnabled = NO;
    return _imageImage;
}

- (UIButton *)favorite{
    
    if (!_favorite) {
        self.favorite = [UIButton buttonWithType:UIButtonTypeCustom];
        _favorite.frame = CGRectMake(0, 340, 310/4, 30);
        
        [self.favorite addSubview:self.favoriteCount];
        [self.favorite addSubview:self.favoriteImage];
    }
    return _favorite;
}
- (UIImageView *)favoriteImage{
    
    if (!_favoriteImage) {
        self.favoriteImage = [[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 310/8, 30)] autorelease];
    }
    return _favoriteImage;
}
- (UILabel *)favoriteCount{
    if (!_favoriteCount) {
        self.favoriteCount = [[[UILabel alloc] initWithFrame:CGRectMake(310/8, 0, 310/8, 30)] autorelease];
        _favoriteCount.textAlignment = NSTextAlignmentLeft;
        _favoriteCount.font = [UIFont systemFontOfSize:13];
    }
    return _favoriteCount;
}
- (UIButton *)dislike{
    
    if (!_dislike) {
        self.dislike = [UIButton buttonWithType:UIButtonTypeCustom];
        self.dislike.frame = CGRectMake(310/4, 340, 310/4, 30);
        
        [self.dislike addSubview:self.dislikeCount];
        [self.dislike addSubview:self.dislikeImage];
    }
    return _dislike;
}
- (UIImageView *)dislikeImage{
    
    if (!_dislikeImage) {
        self.dislikeImage = [[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 310/8, 30)] autorelease];
    }
    return _dislikeImage;
}

- (UILabel *)dislikeCount{
    
    if (!_dislikeCount) {
        self.dislikeCount = [[[UILabel alloc] initWithFrame:CGRectMake(310/8, 0, 310/8, 30)] autorelease];
        _dislikeCount.textAlignment = NSTextAlignmentLeft;
        _dislikeCount.font = [UIFont systemFontOfSize:13];
        _dislikeCount.textColor = [UIColor blackColor];
    }
    return _dislikeCount;
}

- (UIButton *)share{
    
    if (!_share) {
        self.share = [UIButton buttonWithType:UIButtonTypeCustom];
        self.share.frame = CGRectMake(310/2, 340, 310/4, 30);
        [self.share addSubview:self.shareCount];
        [self.share addSubview:self.shareImage];
    }
    return _share;
}

- (UIImageView *)shareImage{
    
    if (!_shareImage) {
        self.shareImage = [[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 310/8, 30)] autorelease];
        
    }
    return _shareImage;
}

- (UILabel *)shareCount{
    
    if (!_shareCount) {
        self.shareCount = [[[UILabel alloc] initWithFrame:CGRectMake(310/8, 0, 310/8, 30)] autorelease];
        self.shareCount.textAlignment = NSTextAlignmentLeft;
        self.shareCount.font = [UIFont systemFontOfSize:13];
    }
    return _shareCount;
}
- (UIButton *)comment{
    
    if (!_comment) {
        self.comment = [UIButton buttonWithType:UIButtonTypeCustom];
        self.comment.frame = CGRectMake(310/4*3, 340, 310/4, 30);
        [self.comment addSubview:self.commentCount];
        [self.comment addSubview:self.commentImage];
    }
    return _comment;
}
- (UIImageView *)commentImage{
    
    if (!_commentImage) {
        self.commentImage = [[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 310/8, 30)] autorelease];
    }
    return _commentImage;
}
- (UILabel *)commentCount{
    
    if (!_commentCount) {
        self.commentCount = [[[UILabel alloc] initWithFrame:CGRectMake(310/8, 0, 310/8, 30)] autorelease];
        self.commentCount.textAlignment = NSTextAlignmentLeft;
        self.commentCount.font = [UIFont systemFontOfSize:13];
        
    }
    return _commentCount;
}
- (void)dealloc{
    [_userName release];
    [_userNameLabel release];
    [_created_time release];
    [_created_timeLabel release];
    [_profile_image release];
    [_profile_imageLabel release];
    [_text release];
    [_labelText release];
    [_image release];
    [_imageImage release];
    [_favorite release];
    [_favoriteCount release];
    [_favoriteImage release];
    [_dislike release];
    [_dislikeImage release];
    [_dislikeCount release];
    [_share release];
    [_shareImage release];
    [_shareCount release];
    [_comment release];
    [_commentImage release];
    [_commentCount release];
    [super dealloc];
}
- (void)setFrame:(CGRect)frame{
    
    frame.origin.x += 5;
    frame.size.width -= 10;
    frame.size.height -= 5;
    [super setFrame:frame];
}


- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
