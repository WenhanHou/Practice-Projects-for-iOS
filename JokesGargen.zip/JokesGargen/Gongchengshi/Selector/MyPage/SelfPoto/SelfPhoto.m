//
//  SelfPhoto.m
//  Gongchengshi
//
//  Created by lanouhn on 14-11-6.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import "SelfPhoto.h"

@implementation SelfPhoto

- (id)initWithDictionary:(NSDictionary *)dic{

    if (self = [super init]) {
        self.userName = dic[@"name"];
        self.profile_image = dic[@"profile_image"];
        self.create_time = dic[@"created_at"];
        self.text = dic[@"text"];
        self.image = dic[@"image0"];
        self.idString = dic[@"id"];
        self.uid = dic[@"uid"];
        self.use_id = dic[@"user_id"];
        self.love = dic[@"love"];
        self.hate = dic[@"hate"];
        self.comment = dic[@"comment"];
        self.forward = dic[@"forward"];
        self.width = dic[@"width"];
        self.height = dic[@"height"];
        
    }
    return self;
}
+ (id)modelWithDictionary:(NSDictionary *)dic{

    return [[[[self class]alloc]initWithDictionary:dic] autorelease];
}
- (CGSize)contentSize{

    CGSize size = [self.text boundingRectWithSize:CGSizeMake(310, 0) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName: [UIFont systemFontOfSize:20]} context:nil].size;
    return size;
}
@end
