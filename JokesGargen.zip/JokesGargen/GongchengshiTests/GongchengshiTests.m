//
//  GongchengshiTests.m
//  GongchengshiTests
//
//  Created by dqb on 14-10-27.
//  Copyright (c) 2014年 蓝鸥科技www.lanou3g.com. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface GongchengshiTests : XCTestCase

@end

@implementation GongchengshiTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
